/**
 * The design system's type roles (DESIGN.md › Typography): size, line height and weight together, so a 12px label
 * cannot pick up a 20px line or a 10px size. 12px is the smallest text and only 400, 500 and 600 exist.
 *
 * `@spfx-kit/ui-theme/styles.css` defines one custom property per role and property on Kit app roots and portal
 * hosts (`--spfx-ui-type-<role>-size`, `-line-height`, `-weight`), in its low `spfx-kit-ui-theme-defaults` layer.
 * `typeRole.<role>` reads those properties with the values below as fallbacks, so it also works without the
 * stylesheet. Spread a role into a style object and override only what a role leaves open (colour, wrapping):
 *
 * ```ts
 * import { typeRole } from '@spfx-kit/ui-theme/runtime';
 * const title = { ...typeRole.pageTitle, color: 'var(--spfx-ui-color-foreground)' };
 * ```
 */
/** A type role's name. */
export type SpfxTypeRoleName = 'pageTitle' | 'sectionTitle' | 'body' | 'rowTitle' | 'statLabel' | 'metadata' | 'eyebrow' | 'statValue';
/** The only weights the design system uses. */
export type SpfxTypeRoleWeight = 400 | 500 | 600;
/** A role's literal values: rem sizes (1rem = 16px) and a numeric weight. */
export interface SpfxTypeRoleValues {
    readonly fontSize: string;
    readonly lineHeight: string;
    readonly fontWeight: SpfxTypeRoleWeight;
}
/** A role as CSS: each property reads the role's custom property, with the literal value as its fallback. */
export interface SpfxTypeRoleStyle {
    readonly fontSize: string;
    readonly lineHeight: string;
    readonly fontWeight: string;
}
/**
 * The roles' literal values, in the order DESIGN.md lists them.
 *
 * | Role         | Size / line | Weight |
 * | ------------ | ----------- | ------ |
 * | pageTitle    | 24 / 32     | 600    |
 * | sectionTitle | 16 / 24     | 600    |
 * | body         | 14 / 20     | 400    |
 * | rowTitle     | 14 / 20     | 500    |
 * | statLabel    | 13 / 18     | 500    |
 * | metadata     | 12 / 16     | 400    |
 * | eyebrow      | 12 / 16     | 600    |
 * | statValue    | 28 / 32     | 600    |
 */
export declare const SPFX_TYPE_ROLE_VALUES: Readonly<Record<SpfxTypeRoleName, SpfxTypeRoleValues>>;
/** Every role name, in DESIGN.md order. */
export declare const SPFX_TYPE_ROLE_NAMES: readonly SpfxTypeRoleName[];
/** The custom property for one role property, e.g. `--spfx-ui-type-page-title-size`. */
export declare function typeRoleVariable(role: SpfxTypeRoleName, property: keyof SpfxTypeRoleValues): string;
/** Every role's custom properties and literal values, as `styles.css` declares them. */
export declare function typeRoleCustomProperties(): Readonly<Record<string, string>>;
/** The roles as CSS values for style objects (Griffel, inline styles): `...typeRole.sectionTitle`. */
export declare const typeRole: Readonly<Record<SpfxTypeRoleName, SpfxTypeRoleStyle>>;
