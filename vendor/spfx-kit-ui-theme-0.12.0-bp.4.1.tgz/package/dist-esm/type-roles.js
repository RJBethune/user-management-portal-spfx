/**
 * The design system's type roles (DESIGN.md › Typography): size, line height and weight together, so a 12px label
 * cannot pick up a 20px line or a 10px size. 12px is the smallest text and only 400, 500 and 600 exist.
 *
 * `@spfx-kit/ui-theme/styles.css` defines one custom property per role and property on Kit app roots and portal
 * hosts (`--spfx-ui-type-<role>-size`, `-line-height`, `-weight`), in its low `spfx-kit-ui-theme-defaults` layer.
 * `typeRole.<role>` reads those properties with the values below as fallbacks, so it also works without the
 * stylesheet. Spread a role into a style object and override only what a role leaves open (colour, wrapping):
 *
 * ```ts
 * import { typeRole } from '@spfx-kit/ui-theme/runtime';
 * const title = { ...typeRole.pageTitle, color: 'var(--spfx-ui-color-foreground)' };
 * ```
 */
const values = (fontSize, lineHeight, fontWeight) => Object.freeze({ fontSize, lineHeight, fontWeight });
/**
 * The roles' literal values, in the order DESIGN.md lists them.
 *
 * | Role         | Size / line | Weight |
 * | ------------ | ----------- | ------ |
 * | pageTitle    | 24 / 32     | 600    |
 * | sectionTitle | 16 / 24     | 600    |
 * | body         | 14 / 20     | 400    |
 * | rowTitle     | 14 / 20     | 500    |
 * | statLabel    | 13 / 18     | 500    |
 * | metadata     | 12 / 16     | 400    |
 * | eyebrow      | 12 / 16     | 600    |
 * | statValue    | 28 / 32     | 600    |
 */
export const SPFX_TYPE_ROLE_VALUES = Object.freeze({
    pageTitle: values('1.5rem', '2rem', 600),
    sectionTitle: values('1rem', '1.5rem', 600),
    body: values('0.875rem', '1.25rem', 400),
    rowTitle: values('0.875rem', '1.25rem', 500),
    statLabel: values('0.8125rem', '1.125rem', 500),
    metadata: values('0.75rem', '1rem', 400),
    eyebrow: values('0.75rem', '1rem', 600),
    statValue: values('1.75rem', '2rem', 600)
});
/** Every role name, in DESIGN.md order. */
export const SPFX_TYPE_ROLE_NAMES = Object.freeze(Object.keys(SPFX_TYPE_ROLE_VALUES));
const kebab = (name) => name.replace(/[A-Z]/gu, (letter) => `-${letter.toLowerCase()}`);
const SUFFIX = {
    fontSize: 'size',
    lineHeight: 'line-height',
    fontWeight: 'weight'
};
/** The custom property for one role property, e.g. `--spfx-ui-type-page-title-size`. */
export function typeRoleVariable(role, property) {
    return `--spfx-ui-type-${kebab(role)}-${SUFFIX[property]}`;
}
/** Every role's custom properties and literal values, as `styles.css` declares them. */
export function typeRoleCustomProperties() {
    const properties = {};
    for (const role of SPFX_TYPE_ROLE_NAMES) {
        const entry = SPFX_TYPE_ROLE_VALUES[role];
        properties[typeRoleVariable(role, 'fontSize')] = entry.fontSize;
        properties[typeRoleVariable(role, 'lineHeight')] = entry.lineHeight;
        properties[typeRoleVariable(role, 'fontWeight')] = String(entry.fontWeight);
    }
    return Object.freeze(properties);
}
const style = (role) => {
    const entry = SPFX_TYPE_ROLE_VALUES[role];
    return Object.freeze({
        fontSize: `var(${typeRoleVariable(role, 'fontSize')}, ${entry.fontSize})`,
        lineHeight: `var(${typeRoleVariable(role, 'lineHeight')}, ${entry.lineHeight})`,
        fontWeight: `var(${typeRoleVariable(role, 'fontWeight')}, ${entry.fontWeight})`
    });
};
/** The roles as CSS values for style objects (Griffel, inline styles): `...typeRole.sectionTitle`. */
export const typeRole = Object.freeze({
    pageTitle: style('pageTitle'),
    sectionTitle: style('sectionTitle'),
    body: style('body'),
    rowTitle: style('rowTitle'),
    statLabel: style('statLabel'),
    metadata: style('metadata'),
    eyebrow: style('eyebrow'),
    statValue: style('statValue')
});
