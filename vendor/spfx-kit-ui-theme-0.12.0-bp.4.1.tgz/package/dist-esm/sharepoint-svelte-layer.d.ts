import { type SharePointThemeLike, type SpfxUiHost, type SpfxUiThemeMode, type SpfxUiThemeTokens } from '@spfx-kit/ui-profile';
/**
 * The SharePoint theme over Svelte.
 *
 * Every Kit app builds on the Svelte style document (Luma). An app's SharePoint
 * theme is the thinnest data-only mapping on top of it: the site's palette and
 * font, Fluent-like corners and 32px control density. It is Kit tokens plus a few
 * CSS custom properties, never per-component CSS. Light and Dark stay plain Svelte.
 */
/** SharePoint's default type stack (Fluent's `fontFamilyBase`), used when the site sets no font. */
export declare const SHAREPOINT_FONT_STACK = "\"Segoe UI\", \"Segoe UI Web (West European)\", -apple-system, BlinkMacSystemFont, Roboto, \"Helvetica Neue\", sans-serif";
/** Fluent's control height. Luma's controls are nine spacing units (36px) tall. */
export declare const SHAREPOINT_CONTROL_HEIGHT_PX = 32;
/** Fluent's corner radius for buttons, fields, selects, tabs, badges and menu items. */
export declare const SHAREPOINT_CONTROL_RADIUS = "4px";
/** Fluent's dialog surface width. Luma sizes dialogs only with `--skui-container-md`. */
export declare const SHAREPOINT_DIALOG_WIDTH = "600px";
/**
 * CSS custom property carrying SharePoint's `inputBorder` stroke, at least 3:1 on the site surface. The
 * ui-theme stylesheet draws it as the resting border of Luma's fields (input, textarea, selects, input
 * groups, combobox chips, unchecked checkboxes, radios and switches), which are otherwise a faint fill
 * behind a transparent border. App stylesheets may read it too.
 */
export declare const SHAREPOINT_INPUT_BORDER_VARIABLE = "--spfx-ui-sharepoint-input-border";
/**
 * CSS custom property carrying the inner line a focused field draws inside its border, so focus stays
 * visible when the focused border (the ring) is the same colour as the resting stroke (SharePoint's
 * focusBorder and inputBorder are both neutralSecondary by default). It is the ring, moved only as far
 * as needed to reach 3:1 on the field fill. Set only with a site palette, like the stroke.
 */
export declare const SHAREPOINT_INPUT_FOCUS_BORDER_VARIABLE = "--spfx-ui-sharepoint-input-focus-border";
/** The primary held to4.5:1 on the page and cards when used as link text, preserving the fill. */
export declare const SHAREPOINT_LINK_VARIABLE = "--spfx-ui-sharepoint-link";
/** Info-tone text guarded on the actual OKLab tint used by ui-patterns. */
export declare const SHAREPOINT_INFO_FOREGROUND_VARIABLE = "--spfx-ui-sharepoint-info-foreground";
/**
 * CSS custom properties carrying the SharePoint app bar: an app's full-width
 * brand header (for example an expanded workspace header) in the SharePoint
 * theme. Light and Dark never set them, so an app reads them with its own
 * fallback, such as `var(--spfx-ui-sharepoint-app-bar, var(--spfx-ui-color-primary))`.
 */
export declare const SHAREPOINT_APP_BAR_VARIABLES: Readonly<{
    /** The bar: the site's `themeDarker`, darkened only if white text would fall below 4.5:1. */
    readonly background: "--spfx-ui-sharepoint-app-bar";
    /** Text and icons on the bar: white, at least 4.5:1 on the bar and both states. */
    readonly foreground: "--spfx-ui-sharepoint-app-bar-foreground";
    /** A hovered control on the bar. */
    readonly hover: "--spfx-ui-sharepoint-app-bar-hover";
    /** A pressed, open or on control on the bar. */
    readonly pressed: "--spfx-ui-sharepoint-app-bar-pressed";
}>;
/** The SharePoint app bar colours (see {@link SHAREPOINT_APP_BAR_VARIABLES}). */
export interface SharePointAppBar {
    readonly background: string;
    readonly foreground: string;
    readonly hover: string;
    readonly pressed: string;
}
/**
 * Accepted site themes: the SPFx theme object (`IReadonlyTheme` from
 * `ThemeProvider.tryGetTheme()` or `onThemeChanged`, read structurally), or the
 * tokens `mapSharePointTheme` returns for it.
 */
export type SharePointSiteThemeSource = SharePointThemeLike | SpfxUiThemeTokens;
/** A SharePoint site theme resolved into what the layer maps over Svelte. */
export interface SharePointSiteTheme {
    readonly kind: 'spfx-kit-sharepoint-site-theme';
    readonly mode: SpfxUiThemeMode;
    /**
     * The site's Kit palette (`mapSharePointTheme` over a contrast-completed site
     * theme). Undefined when the host supplied no palette: the layer then keeps the
     * Svelte colours and maps only font, corners, density and dialog width.
     */
    readonly palette?: SpfxUiThemeTokens;
    /** Luma's field fill: the site surface with 10% of the site text (15% on dark sites). */
    readonly inputFill?: string;
    /** SharePoint's input stroke (`semanticColors.inputBorder`), at least 3:1 on the surface. */
    readonly inputBorder?: string;
    /** The site font family, or SharePoint's Segoe UI stack. */
    readonly fontFamily: string;
    /**
     * The app bar with white text: a light site's `themeDarker`, an inverted site's `themeLighter`
     * (its dark brand tint). Undefined only when the host supplies no site colours at all (no
     * palette and no semantic colours). A site without those slots, or Kit tokens, take a colour
     * derived from the primary (SharePoint's default `#0078d4` when the palette names none).
     */
    readonly appBar?: SharePointAppBar;
}
/** Token overrides and CSS custom properties that turn Svelte into the SharePoint theme. */
export interface SharePointSvelteLayer {
    /** The mode to compile Svelte in: the site's mode, or the caller's when there is no site palette. */
    readonly mode?: SpfxUiThemeMode;
    /** Merge over the Svelte tokens for the same mode. Never includes `fontMono`. */
    readonly tokens: Readonly<Partial<SpfxUiThemeTokens>>;
    /** Set on the app root and portal host after the Svelte style is applied. */
    readonly cssVariables: Readonly<Record<string, string>>;
}
/** Only the info foreground changes; its authored tint and primary fill are retained. */
export declare function sharePointInfoForeground(primary: string, background: string, foreground: string, mode: SpfxUiThemeMode): string | undefined;
/**
 * The app bar for a site's `themeDarker` (`base`). The text is white. A bar too pale for white
 * text at 4.5:1 (an inverted ramp's themeDarker, a yellow site) is darkened toward black in 1%
 * steps, keeping its hue, until white reads on the rounded hex colour. Hover and pressed lighten
 * the bar toward its text when white still reads at 4.5:1 on the pressed state, so they stay
 * visible on a near-black bar; otherwise they darken it, which only raises the text contrast.
 * Either way hover is at least 1.15:1 against the bar, and pressed goes twice as far.
 *
 * A `base` the layer cannot parse (a CSS variable, a keyword, `color-mix()`) passes through as
 * is, with CSS `color-mix()` states toward black: there is no contrast guarantee for it.
 */
export declare function sharePointAppBar(base: string): SharePointAppBar;
/**
 * Resolve a SharePoint site theme for the layer. Accepts the SPFx theme object
 * (partial palettes are completed and contrast-checked) or `mapSharePointTheme`
 * output. A theme with no palette and no semantic colours resolves without a
 * palette, so the layer keeps the Svelte colours.
 */
export declare function resolveSharePointSiteTheme(source: SharePointSiteThemeSource | SharePointSiteTheme): SharePointSiteTheme;
/**
 * Svelte's colour roles: the shadcn CSS variables (`--primary`, `--muted-foreground`,
 * ...) that app styles and Kit components read next to the Kit tokens. The SharePoint
 * layer maps every one to the site palette. Svelte's chart colours are a data palette,
 * not a brand role, so they stay Svelte's.
 */
export declare const SVELTE_COLOR_ROLES: readonly ["background", "foreground", "card", "card-foreground", "popover", "popover-foreground", "primary", "primary-foreground", "secondary", "secondary-foreground", "muted", "muted-foreground", "accent", "accent-foreground", "destructive", "border", "input", "ring", "sidebar", "sidebar-foreground", "sidebar-primary", "sidebar-primary-foreground", "sidebar-accent", "sidebar-accent-foreground", "sidebar-border", "sidebar-ring"];
export type SvelteColorRole = (typeof SVELTE_COLOR_ROLES)[number];
/**
 * The SharePoint theme as data over Svelte: token overrides and CSS custom
 * properties. Pass the SPFx theme object, `mapSharePointTheme` output, or a
 * resolved site theme; omit it for the structure only (font, corners, density,
 * dialog width) over the Svelte colours.
 *
 * - palette: the site's colours through `mapSharePointTheme`, on the Kit tokens and on
 *   every Svelte colour role (`--primary`, `--muted-foreground`, `--ring`, ...), with
 *   text at 4.5:1 on its surface and the focus ring at 3:1 on the page;
 * - font: the site's font for body and headings (Segoe UI by default);
 * - radius: Fluent's 2 / 4 / 8 px scale and 4px control corners (`radiusControl`)
 *   instead of Luma's squircles and pills;
 * - density: 32px controls, by scaling the Kit spacing unit by 8/9 so Luma's
 *   nine-unit (36px) controls become 32px;
 * - fields: Luma's `input` fill becomes the site surface with 10% of the site
 *   text (15% on dark sites); SharePoint's `inputBorder` stays a stroke, exposed
 *   as `--spfx-ui-sharepoint-input-border` for app stylesheets;
 * - dialogs: 600px wide through `--skui-container-md`;
 * - app bar: the site's `themeDarker` with white text at 4.5:1 and visible hover and
 *   pressed states, as `--spfx-ui-sharepoint-app-bar*` (`SHAREPOINT_APP_BAR_VARIABLES`).
 */
export declare function sharePointSvelteLayer(site?: SharePointSiteThemeSource | SharePointSiteTheme): SharePointSvelteLayer;
/**
 * Apply a SharePoint layer after the Svelte style (`applyThemeArtifact` or
 * `applyCompiledThemeArtifact` in `layer.mode`). `base` is the Svelte tokens for
 * that mode, for example `artifact.compiled[mode].tokens`. Applying a style again
 * clears the layer, so Light and Dark are plain Svelte.
 */
export declare function applySharePointSvelteLayer(host: SpfxUiHost, base: SpfxUiThemeTokens, layer: SharePointSvelteLayer): void;
/** Remove the layer's CSS custom properties. Theme application calls this before applying a style. */
export declare function clearSharePointSvelteLayer(host: SpfxUiHost): void;
