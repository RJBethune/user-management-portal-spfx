/** No palette/compiler imports: consume validated build-time snapshots. */
export * from './compiled-artifact';
export { parseThemeArtifact } from './artifact-contract';
export { restoreLabUiTheme as resetThemeArtifact } from './runtime-theme';
export * from './sharepoint-svelte-layer';
/** The design system's type roles (size, line height, weight): constants, no theme data. */
export * from './type-roles';
