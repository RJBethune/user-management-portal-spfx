import { mapSharePointTheme } from '@spfx-kit/ui-profile';
/**
 * The SharePoint theme over Svelte.
 *
 * Every Kit app builds on the Svelte style document (Luma). An app's SharePoint
 * theme is the thinnest data-only mapping on top of it: the site's palette and
 * font, Fluent-like corners and 32px control density. It is Kit tokens plus a few
 * CSS custom properties, never per-component CSS. Light and Dark stay plain Svelte.
 */
/** SharePoint's default type stack (Fluent's `fontFamilyBase`), used when the site sets no font. */
export const SHAREPOINT_FONT_STACK = '"Segoe UI", "Segoe UI Web (West European)", -apple-system, BlinkMacSystemFont, Roboto, "Helvetica Neue", sans-serif';
/** Fluent's control height. Luma's controls are nine spacing units (36px) tall. */
export const SHAREPOINT_CONTROL_HEIGHT_PX = 32;
const LUMA_CONTROL_HEIGHT_UNITS = 9;
/** Fluent's corner radius for buttons, fields, selects, tabs, badges and menu items. */
export const SHAREPOINT_CONTROL_RADIUS = '4px';
/** Fluent's dialog surface width. Luma sizes dialogs only with `--skui-container-md`. */
export const SHAREPOINT_DIALOG_WIDTH = '600px';
/**
 * CSS custom property carrying SharePoint's `inputBorder` stroke, at least 3:1 on the site surface. The
 * ui-theme stylesheet draws it as the resting border of Luma's fields (input, textarea, selects, input
 * groups, combobox chips, unchecked checkboxes, radios and switches), which are otherwise a faint fill
 * behind a transparent border. App stylesheets may read it too.
 */
export const SHAREPOINT_INPUT_BORDER_VARIABLE = '--spfx-ui-sharepoint-input-border';
/**
 * CSS custom property carrying the inner line a focused field draws inside its border, so focus stays
 * visible when the focused border (the ring) is the same colour as the resting stroke (SharePoint's
 * focusBorder and inputBorder are both neutralSecondary by default). It is the ring, moved only as far
 * as needed to reach 3:1 on the field fill. Set only with a site palette, like the stroke.
 */
export const SHAREPOINT_INPUT_FOCUS_BORDER_VARIABLE = '--spfx-ui-sharepoint-input-focus-border';
/** The primary held to4.5:1 on the page and cards when used as link text, preserving the fill. */
export const SHAREPOINT_LINK_VARIABLE = '--spfx-ui-sharepoint-link';
/** Info-tone text guarded on the actual OKLab tint used by ui-patterns. */
export const SHAREPOINT_INFO_FOREGROUND_VARIABLE = '--spfx-ui-sharepoint-info-foreground';
/**
 * CSS custom properties carrying the SharePoint app bar: an app's full-width
 * brand header (for example an expanded workspace header) in the SharePoint
 * theme. Light and Dark never set them, so an app reads them with its own
 * fallback, such as `var(--spfx-ui-sharepoint-app-bar, var(--spfx-ui-color-primary))`.
 */
export const SHAREPOINT_APP_BAR_VARIABLES = Object.freeze({
    /** The bar: the site's `themeDarker`, darkened only if white text would fall below 4.5:1. */
    background: '--spfx-ui-sharepoint-app-bar',
    /** Text and icons on the bar: white, at least 4.5:1 on the bar and both states. */
    foreground: '--spfx-ui-sharepoint-app-bar-foreground',
    /** A hovered control on the bar. */
    hover: '--spfx-ui-sharepoint-app-bar-hover',
    /** A pressed, open or on control on the bar. */
    pressed: '--spfx-ui-sharepoint-app-bar-pressed'
});
function parseColor(color) {
    const value = color.trim();
    const hex = value.replace(/^#/u, '');
    if (value.startsWith('#') && /^[\da-f]{3}$/iu.test(hex))
        return hex.split('').map((c) => parseInt(c + c, 16));
    if (value.startsWith('#') && /^[\da-f]{6}$/iu.test(hex))
        return [0, 2, 4].map((i) => parseInt(hex.slice(i, i + 2), 16));
    const match = /^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/iu.exec(value);
    return match ? match.slice(1, 4).map(Number) : undefined;
}
function toHex(rgb) {
    return `#${rgb
        .map((c) => Math.round(Math.min(255, Math.max(0, c)))
        .toString(16)
        .padStart(2, '0'))
        .join('')}`;
}
function luminance(rgb) {
    const [r, g, b] = rgb.map((value) => {
        const c = value / 255;
        return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
    });
    return r * 0.2126 + g * 0.7152 + b * 0.0722;
}
function contrast(a, b) {
    const [high, low] = [luminance(a), luminance(b)].sort((x, y) => y - x);
    return (high + 0.05) / (low + 0.05);
}
/** `amount` of `foreground` over `background`, in hex when both parse, else as CSS `color-mix`. */
function mix(background, foreground, amount) {
    const from = parseColor(background);
    const to = parseColor(foreground);
    if (!from || !to)
        return `color-mix(in srgb, ${foreground} ${Math.round(amount * 100)}%, ${background})`;
    return toHex(from.map((c, i) => c + (to[i] - c) * amount));
}
const WHITE = [255, 255, 255];
const BLACK = [0, 0, 0];
/**
 * Move `color` toward black or white until it reaches `ratio` on every background.
 * The first background picks the direction. Unparseable colours pass through.
 */
function readable(color, background, ratio = 4.5) {
    const base = parseColor(color);
    const surfaces = (typeof background === 'string' ? [background] : background).map(parseColor);
    if (!base || surfaces.length === 0 || surfaces.some((surface) => !surface))
        return color;
    const parsed = surfaces;
    const target = contrast(WHITE, parsed[0]) >= contrast(BLACK, parsed[0]) ? WHITE : BLACK;
    for (let step = 0; step <= 20; step++) {
        const candidate = base.map((c, i) => c + (target[i] - c) * (step / 20));
        if (parsed.every((surface) => contrast(candidate, surface) >= ratio))
            return step === 0 ? color : toHex(candidate);
    }
    return toHex(target);
}
function toOklab(rgb) {
    const [r, g, b] = rgb.map((value) => {
        const c = value / 255;
        return c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
    });
    const [l, m, s] = [
        0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b,
        0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b,
        0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b
    ].map(Math.cbrt);
    return [
        0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s,
        1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s,
        0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s
    ];
}
/** OKLab to sRGB channels (0–255), clipped to the sRGB gamut per channel. */
function fromOklab([lightness, a, b]) {
    const [l, m, s] = [
        lightness + 0.3963377774 * a + 0.2158037573 * b,
        lightness - 0.1055613458 * a - 0.0638541728 * b,
        lightness - 0.0894841775 * a - 1.291485548 * b
    ].map((value) => value * value * value);
    return [
        4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
        -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
        -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s
    ].map((value) => {
        const c = Math.min(1, Math.max(0, value));
        return (c <= 0.0031308 ? c * 12.92 : 1.055 * Math.pow(c, 1 / 2.4) - 0.055) * 255;
    });
}
/** `amount` of `color` over `background` in OKLab, as CSS `color-mix(in oklab, ...)` mixes it. */
function mixOklab(background, color, amount) {
    const from = toOklab(background);
    const to = toOklab(color);
    return fromOklab(from.map((c, i) => c + (to[i] - c) * amount));
}
/** Only the info foreground changes; its authored tint and primary fill are retained. */
export function sharePointInfoForeground(primary, background, foreground, mode) {
    const hue = parseColor(primary), page = parseColor(background), text = parseColor(foreground);
    if (!hue || !page || !text)
        return undefined;
    const tint = toHex(mixOklab(page, hue, mode === 'dark' ? 0.2 : 0.12));
    const original = toHex(mixOklab(text, hue, 0.55));
    const guarded = readable(original, tint);
    return guarded === original ? undefined : guarded;
}
function onColor(background) {
    const surface = parseColor(background);
    if (!surface)
        return '#ffffff';
    return contrast(WHITE, surface) >= contrast(BLACK, surface) ? '#ffffff' : '#000000';
}
/** How far a hovered control moves the app bar, at least; pressed moves it twice as far. */
const APP_BAR_HOVER = 0.1;
/** The least contrast between a hovered control and the bar, so hover stays visible. */
const APP_BAR_HOVER_DELTA = 1.15;
/** Fluent's themeDarker sits about 44% of the way from themePrimary to black. */
const THEME_DARKER_SHADE = 0.44;
/** An inverted ramp's themeLighter: about 18% of the primary over the dark page. */
const INVERTED_BRAND_TINT = 0.18;
function mixRgb(from, to, amount) {
    return from.map((c, i) => c + (to[i] - c) * amount);
}
/** `rgb` rounded as `toHex` writes it, so contrast is measured on the colour the page gets. */
function rounded(rgb) {
    return parseColor(toHex(rgb));
}
/**
 * Hover and pressed for a bar with white text: `amount` and twice it toward `target`, from 10%
 * up until hover reaches 1.15:1 against the bar. Undefined when lightening cannot keep white text
 * at 4.5:1 on the pressed state, or darkening cannot make hover visible.
 */
function appBarStates(bar, target) {
    for (let amount = APP_BAR_HOVER; amount <= 0.5 + 1e-9; amount += 0.01) {
        const hover = rounded(mixRgb(bar, target, amount));
        const pressed = rounded(mixRgb(bar, target, Math.min(1, amount * 2)));
        if (target === WHITE && contrast(WHITE, pressed) < 4.5)
            return undefined;
        if (contrast(hover, bar) >= APP_BAR_HOVER_DELTA)
            return { hover: toHex(hover), pressed: toHex(pressed) };
    }
    return undefined;
}
/**
 * The app bar for a site's `themeDarker` (`base`). The text is white. A bar too pale for white
 * text at 4.5:1 (an inverted ramp's themeDarker, a yellow site) is darkened toward black in 1%
 * steps, keeping its hue, until white reads on the rounded hex colour. Hover and pressed lighten
 * the bar toward its text when white still reads at 4.5:1 on the pressed state, so they stay
 * visible on a near-black bar; otherwise they darken it, which only raises the text contrast.
 * Either way hover is at least 1.15:1 against the bar, and pressed goes twice as far.
 *
 * A `base` the layer cannot parse (a CSS variable, a keyword, `color-mix()`) passes through as
 * is, with CSS `color-mix()` states toward black: there is no contrast guarantee for it.
 */
export function sharePointAppBar(base) {
    const parsed = parseColor(base);
    const foreground = '#ffffff';
    if (!parsed) {
        return {
            background: base,
            foreground,
            hover: mix(base, '#000000', APP_BAR_HOVER),
            pressed: mix(base, '#000000', APP_BAR_HOVER * 2)
        };
    }
    let bar = rounded(parsed);
    for (let step = 1; step <= 100 && contrast(WHITE, bar) < 4.5; step++)
        bar = rounded(mixRgb(parsed, BLACK, step / 100));
    const states = appBarStates(bar, WHITE) ??
        appBarStates(bar, BLACK) ?? {
        hover: toHex(rounded(mixRgb(bar, BLACK, 0.5))),
        pressed: toHex(BLACK)
    };
    return { background: toHex(bar), foreground, ...states };
}
/** The site's themeDarker, then themeDark, then a Fluent-like shade of the primary. */
/**
 * The app bar's source colour. A light site: `themeDarker`, then `themeDark`, then a Fluent-like
 * shade of the primary. An inverted (dark) site's ramp runs the other way, so its `themeDarker`
 * is its palest tint; the bar takes the inverted ramp's `themeLighter` instead, the dark brand tint
 * next to the page (about 18% of the primary over it), so it stays a recognisable brand tone that
 * is distinct from the page; without one, that mix. The first slot that parses wins; a slot that
 * does not parse (a CSS variable) falls through, and passes through unguaranteed only when nothing
 * parses.
 */
function appBarBase(slots, palette) {
    const supplied = slots.map((slot) => slot?.trim()).filter((slot) => !!slot);
    const readable = supplied.find((slot) => parseColor(slot));
    if (readable)
        return readable;
    const derived = palette.mode === 'dark'
        ? mix(palette.colorBackground, palette.colorPrimary, INVERTED_BRAND_TINT)
        : mix(palette.colorPrimary, '#000000', THEME_DARKER_SHADE);
    return parseColor(derived) || supplied.length === 0 ? derived : supplied[0];
}
function rampSlots(source, dark) {
    const p = source.palette;
    return dark ? [p?.themeLighter] : [p?.themeDarker, p?.themeDark];
}
function isTokens(source) {
    return typeof source.colorBackground === 'string' && 'mode' in source;
}
function isResolved(source) {
    return source?.kind === 'spfx-kit-sharepoint-site-theme';
}
// mapSharePointTheme prefixes the site font with the Kit's Inter; SharePoint itself uses the site font.
const MAPPED_FONT_PREFIX = /^\s*"Inter Variable"\s*,\s*/u;
function inputFillFor(background, foreground, mode) {
    return mix(background, foreground, mode === 'dark' ? 0.15 : 0.1);
}
/**
 * Complete a (possibly partial) SPFx theme so `mapSharePointTheme` has every slot,
 * with the input stroke at 3:1 on the site surface. Muted text is the site's
 * secondary text in ui-profile's order (`bodySubtext`, then `neutralSecondary`,
 * then a mix of the body colours), passed through as is: `mapSharePointTheme`
 * composites a translucent value over the page and repairs it to 4.5:1 on the
 * page, muted and accent fills, so every app resolves the same muted text.
 */
function completeSharePointTheme(source) {
    const p = source.palette ?? {};
    const s = source.semanticColors ?? {};
    const supplied = s.bodyBackground || p.white;
    const suppliedRgb = supplied ? parseColor(supplied) : undefined;
    const dark = source.isInverted ?? (suppliedRgb ? luminance(suppliedRgb) < 0.18 : false);
    const background = supplied || (dark ? '#292929' : '#ffffff');
    const foreground = s.bodyText || p.neutralPrimary || (dark ? '#ffffff' : '#242424');
    const brand = p.themePrimary || '#0078d4'; // SharePoint's default theme accent
    const onBrand = onColor(brand);
    // Undefined when the site supplies neither: mapSharePointTheme then derives it exactly as the
    // UI profile does (including its fallback to body text when a colour does not parse).
    const muted = s.bodySubtext?.trim() || p.neutralSecondary?.trim() || undefined;
    const divider = s.bodyDivider || p.neutralLight || mix(background, foreground, 0.12);
    const inputBorder = readable(s.inputBorder || p.neutralSecondary || mix(background, foreground, 0.55), background, 3);
    const standout = p.neutralLighter || mix(background, foreground, 0.04);
    const accent = s.buttonBackgroundHovered || p.themeLighter || mix(background, brand, 0.12);
    const buttonBackground = s.buttonBackground || standout;
    const destructive = p.redDark || (dark ? '#f1707b' : '#a4262c'); // SharePoint's default redDark
    const primaryText = s.primaryButtonText;
    const primaryRgb = parseColor(brand);
    const primaryTextRgb = primaryText ? parseColor(primaryText) : undefined;
    return {
        isInverted: dark,
        palette: {
            white: background,
            neutralPrimary: foreground,
            neutralSecondary: muted,
            neutralLight: divider,
            neutralLighter: standout,
            neutralLighterAlt: p.neutralLighterAlt || standout,
            themePrimary: brand,
            themeDarkAlt: readable(p.themeDarkAlt || brand, accent),
            themeLighter: accent,
            redDark: destructive
        },
        semanticColors: {
            bodyBackground: background,
            bodyText: foreground,
            bodySubtext: muted,
            bodyDivider: divider,
            buttonBackground,
            buttonBackgroundHovered: accent,
            buttonText: readable(s.buttonText || foreground, buttonBackground),
            buttonTextHovered: readable(s.buttonTextHovered || p.themeDarkAlt || foreground, accent),
            disabledBackground: s.disabledBackground || standout,
            errorText: readable(s.errorText || destructive, background),
            focusBorder: s.focusBorder || (primaryRgb && contrast(primaryRgb, parseColor(background) ?? WHITE) >= 3 ? brand : foreground),
            inputBorder,
            primaryButtonText: primaryText && (!primaryRgb || !primaryTextRgb || contrast(primaryTextRgb, primaryRgb) >= 4.5) ? primaryText : onBrand
        },
        fonts: source.fonts
    };
}
/**
 * Resolve a SharePoint site theme for the layer. Accepts the SPFx theme object
 * (partial palettes are completed and contrast-checked) or `mapSharePointTheme`
 * output. A theme with no palette and no semantic colours resolves without a
 * palette, so the layer keeps the Svelte colours.
 */
export function resolveSharePointSiteTheme(source) {
    if (isResolved(source))
        return source;
    if (isTokens(source)) {
        const siteFont = source.fontHeading.replace(MAPPED_FONT_PREFIX, '').trim();
        return {
            kind: 'spfx-kit-sharepoint-site-theme',
            mode: source.mode,
            palette: source,
            inputFill: inputFillFor(source.colorBackground, source.colorForeground, source.mode),
            inputBorder: readable(source.colorInput, source.colorBackground, 3),
            fontFamily: siteFont || SHAREPOINT_FONT_STACK,
            // Kit tokens carry no theme ramp, so the bar is derived from the primary (see appBarBase).
            appBar: sharePointAppBar(appBarBase([], source))
        };
    }
    const fontFamily = source.fonts?.medium?.fontFamily?.trim() || SHAREPOINT_FONT_STACK;
    if (!source.palette && !source.semanticColors) {
        return { kind: 'spfx-kit-sharepoint-site-theme', mode: source.isInverted ? 'dark' : 'light', fontFamily };
    }
    const completed = completeSharePointTheme(source);
    const palette = mapSharePointTheme(completed);
    return {
        kind: 'spfx-kit-sharepoint-site-theme',
        mode: palette.mode,
        palette,
        inputFill: inputFillFor(palette.colorBackground, palette.colorForeground, palette.mode),
        inputBorder: completed.semanticColors?.inputBorder,
        fontFamily,
        appBar: sharePointAppBar(appBarBase(rampSlots(source, palette.mode === 'dark'), palette))
    };
}
/**
 * Svelte's colour roles: the shadcn CSS variables (`--primary`, `--muted-foreground`,
 * ...) that app styles and Kit components read next to the Kit tokens. The SharePoint
 * layer maps every one to the site palette. Svelte's chart colours are a data palette,
 * not a brand role, so they stay Svelte's.
 */
export const SVELTE_COLOR_ROLES = [
    'background',
    'foreground',
    'card',
    'card-foreground',
    'popover',
    'popover-foreground',
    'primary',
    'primary-foreground',
    'secondary',
    'secondary-foreground',
    'muted',
    'muted-foreground',
    'accent',
    'accent-foreground',
    'destructive',
    'border',
    'input',
    'ring',
    'sidebar',
    'sidebar-foreground',
    'sidebar-primary',
    'sidebar-primary-foreground',
    'sidebar-accent',
    'sidebar-accent-foreground',
    'sidebar-border',
    'sidebar-ring'
];
/** Kit colour tokens and the Svelte role each one carries. */
const TOKEN_ROLES = {
    colorBackground: 'background',
    colorForeground: 'foreground',
    colorCard: 'card',
    colorCardForeground: 'card-foreground',
    colorPopover: 'popover',
    colorPopoverForeground: 'popover-foreground',
    colorPrimary: 'primary',
    colorPrimaryForeground: 'primary-foreground',
    colorSecondary: 'secondary',
    colorSecondaryForeground: 'secondary-foreground',
    colorMuted: 'muted',
    colorMutedForeground: 'muted-foreground',
    colorAccent: 'accent',
    colorAccentForeground: 'accent-foreground',
    colorDestructive: 'destructive',
    colorBorder: 'border',
    colorInput: 'input',
    colorRing: 'ring'
};
/**
 * Every Svelte colour role from the site palette, with contrast guards: text roles
 * reach 4.5:1 on the surfaces they sit on (primary text on primary, muted text on
 * muted, card and page surfaces, destructive text on the page) and the focus ring
 * reaches 3:1 on the page. The sidebar takes the site's standout surface.
 */
function siteColorRoles(palette, inputFill) {
    const background = palette.colorBackground;
    const primary = palette.colorPrimary;
    const primaryForeground = readable(palette.colorPrimaryForeground, primary);
    const accent = palette.colorAccent;
    const accentForeground = readable(palette.colorAccentForeground, accent);
    const border = palette.colorBorder;
    const ring = readable(palette.colorRing, background, 3);
    const sidebar = palette.colorSecondary;
    return {
        background,
        foreground: readable(palette.colorForeground, [background, palette.colorCard, palette.colorMuted]),
        card: palette.colorCard,
        'card-foreground': readable(palette.colorCardForeground, palette.colorCard),
        popover: palette.colorPopover,
        'popover-foreground': readable(palette.colorPopoverForeground, palette.colorPopover),
        primary,
        'primary-foreground': primaryForeground,
        secondary: palette.colorSecondary,
        'secondary-foreground': readable(palette.colorSecondaryForeground, palette.colorSecondary),
        muted: palette.colorMuted,
        'muted-foreground': readable(palette.colorMutedForeground, [palette.colorMuted, background, palette.colorCard]),
        accent,
        'accent-foreground': accentForeground,
        destructive: readable(palette.colorDestructive, [background, palette.colorCard]),
        border,
        input: inputFill ?? palette.colorInput,
        ring,
        sidebar,
        'sidebar-foreground': readable(palette.colorForeground, sidebar),
        'sidebar-primary': primary,
        'sidebar-primary-foreground': primaryForeground,
        'sidebar-accent': accent,
        'sidebar-accent-foreground': accentForeground,
        'sidebar-border': border,
        'sidebar-ring': ring
    };
}
/**
 * The SharePoint theme as data over Svelte: token overrides and CSS custom
 * properties. Pass the SPFx theme object, `mapSharePointTheme` output, or a
 * resolved site theme; omit it for the structure only (font, corners, density,
 * dialog width) over the Svelte colours.
 *
 * - palette: the site's colours through `mapSharePointTheme`, on the Kit tokens and on
 *   every Svelte colour role (`--primary`, `--muted-foreground`, `--ring`, ...), with
 *   text at 4.5:1 on its surface and the focus ring at 3:1 on the page;
 * - font: the site's font for body and headings (Segoe UI by default);
 * - radius: Fluent's 2 / 4 / 8 px scale and 4px control corners (`radiusControl`)
 *   instead of Luma's squircles and pills;
 * - density: 32px controls, by scaling the Kit spacing unit by 8/9 so Luma's
 *   nine-unit (36px) controls become 32px;
 * - fields: Luma's `input` fill becomes the site surface with 10% of the site
 *   text (15% on dark sites); SharePoint's `inputBorder` stays a stroke, exposed
 *   as `--spfx-ui-sharepoint-input-border` for app stylesheets;
 * - dialogs: 600px wide through `--skui-container-md`;
 * - app bar: the site's `themeDarker` with white text at 4.5:1 and visible hover and
 *   pressed states, as `--spfx-ui-sharepoint-app-bar*` (`SHAREPOINT_APP_BAR_VARIABLES`).
 */
export function sharePointSvelteLayer(site) {
    const resolved = site ? resolveSharePointSiteTheme(site) : undefined;
    const font = resolved?.fontFamily ?? SHAREPOINT_FONT_STACK;
    const palette = {};
    const roleVariables = {};
    if (resolved?.palette) {
        const roles = siteColorRoles(resolved.palette, resolved.inputFill);
        palette.mode = resolved.palette.mode;
        for (const [token, role] of Object.entries(TOKEN_ROLES))
            palette[token] = roles[role];
        for (const role of SVELTE_COLOR_ROLES)
            roleVariables[`--${role}`] = roles[role];
        roleVariables[SHAREPOINT_INPUT_FOCUS_BORDER_VARIABLE] = readable(roles.ring, [roles.input, roles.background], 3);
        roleVariables[SHAREPOINT_LINK_VARIABLE] = readable(roles.primary, [roles.background, roles.card]);
        const infoForeground = sharePointInfoForeground(roles.primary, roles.background, roles.foreground, resolved.palette.mode);
        if (infoForeground)
            roleVariables[SHAREPOINT_INFO_FOREGROUND_VARIABLE] = infoForeground;
    }
    const spacingRem = `calc(0.25rem * ${SHAREPOINT_CONTROL_HEIGHT_PX / 4} / ${LUMA_CONTROL_HEIGHT_UNITS})`;
    return {
        mode: resolved?.palette ? resolved.mode : undefined,
        tokens: {
            ...palette,
            radiusSm: '2px',
            radiusMd: '4px',
            radiusLg: '4px',
            radiusXl: '8px',
            radiusControl: SHAREPOINT_CONTROL_RADIUS,
            fontHeading: font
        },
        cssVariables: {
            ...roleVariables,
            '--skui-spacing': spacingRem,
            '--radius': '4px',
            '--ui-library-radius-base': '4px',
            '--ui-library-radius-pill': '4px',
            '--ui-library-radius-pill-compact': '4px',
            '--ui-library-luma-sidebar-radius-context': '4px',
            '--ui-library-corner-radius-factor': '1',
            '--ui-library-corner-shape': 'round',
            '--skui-radius-xs': '2px',
            '--skui-radius-2xl': '8px',
            '--skui-radius-3xl': '8px',
            '--skui-radius-4xl': '8px',
            '--font-sans': font,
            '--font-heading': font,
            '--ui-library-theming-font-body': font,
            '--skui-container-md': SHAREPOINT_DIALOG_WIDTH,
            ...(resolved?.inputBorder ? { [SHAREPOINT_INPUT_BORDER_VARIABLE]: resolved.inputBorder } : {}),
            ...(resolved?.appBar
                ? {
                    [SHAREPOINT_APP_BAR_VARIABLES.background]: resolved.appBar.background,
                    [SHAREPOINT_APP_BAR_VARIABLES.foreground]: resolved.appBar.foreground,
                    [SHAREPOINT_APP_BAR_VARIABLES.hover]: resolved.appBar.hover,
                    [SHAREPOINT_APP_BAR_VARIABLES.pressed]: resolved.appBar.pressed
                }
                : {})
        }
    };
}
const layerVariableNames = new WeakMap();
/**
 * Apply a SharePoint layer after the Svelte style (`applyThemeArtifact` or
 * `applyCompiledThemeArtifact` in `layer.mode`). `base` is the Svelte tokens for
 * that mode, for example `artifact.compiled[mode].tokens`. Applying a style again
 * clears the layer, so Light and Dark are plain Svelte.
 */
export function applySharePointSvelteLayer(host, base, layer) {
    if (layer.mode && layer.mode !== base.mode) {
        throw new Error(`Apply the Svelte style in the site's ${layer.mode} mode before its SharePoint layer.`);
    }
    host.applyTheme({ ...base, ...layer.tokens, fontMono: base.fontMono });
    const names = layerVariableNames.get(host) ?? new Set();
    layerVariableNames.set(host, names);
    for (const surface of [host.appRoot, host.portalHost]) {
        for (const [name, value] of Object.entries(layer.cssVariables)) {
            surface.style.setProperty(name, value);
            names.add(name);
        }
    }
}
/** Remove the layer's CSS custom properties. Theme application calls this before applying a style. */
export function clearSharePointSvelteLayer(host) {
    const names = layerVariableNames.get(host);
    if (!names)
        return;
    for (const surface of [host.appRoot, host.portalHost])
        for (const name of names)
            surface.style.removeProperty(name);
    layerVariableNames.delete(host);
}
