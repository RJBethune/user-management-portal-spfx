import { applyCompiledThemeSelection, applyCompiledTheme } from './runtime-theme';
import { THEME_FONT_FAMILIES } from './uiLibraryThemingFonts';
import { UI_LIBRARY_BASE_COLOR_NAMES, UI_LIBRARY_CHROMATIC_COLOR_NAMES, UI_LIBRARY_DARK_THEME_PALETTES, UI_LIBRARY_LIGHT_THEME_PALETTES, UI_LIBRARY_THEME_NAMES } from './ui-library-theme-data';
export const BASE_NOVA_FONT_FAMILY = '"Inter Variable", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", "Noto Sans", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"';
export { UI_LIBRARY_BASE_COLOR_NAMES, UI_LIBRARY_CHROMATIC_COLOR_NAMES, UI_LIBRARY_THEME_NAMES };
export const UI_LIBRARY_ICON_LIBRARY_NAMES = ['Lucide', 'Tabler Icons', 'HugeIcons', 'Phosphor Icons', 'Remix Icon'];
export const UI_LIBRARY_STYLE_NAMES = ['Vega', 'Nova', 'Maia', 'Lyra', 'Mira', 'Luma'];
export const UI_LIBRARY_RADIUS_NAMES = ['Default', 'None', 'Small', 'Medium', 'Large'];
export const UI_LIBRARY_CORNER_SHAPE_NAMES = ['Default', 'Squircle'];
export const UI_LIBRARY_MENU_COLOR_NAMES = ['Default', 'Inverted'];
export const UI_LIBRARY_MENU_APPEARANCE_NAMES = ['Solid', 'Translucent'];
export const UI_LIBRARY_MENU_ACCENT_NAMES = ['Subtle', 'Bold'];
export const UI_LIBRARY_THEME_MODES = ['light', 'dark'];
const UI_LIBRARY_RADIUS_VALUES = {
    Default: undefined,
    None: '0',
    Small: '0.45rem',
    Medium: '0.625rem',
    Large: '0.875rem'
};
// A squircle removes less area from a corner than a round curve at the same
// radius. Chromium raster calibration at Small, Medium, and Large found 1.74
// to be the lowest-error shared factor for matching the round corner footprint.
const SQUIRCLE_RADIUS_FACTOR = 1.74;
const chartTokenNames = ['--chart-1', '--chart-2', '--chart-3', '--chart-4', '--chart-5'];
export const uiLibraryFontFamilies = THEME_FONT_FAMILIES;
export const uiLibraryAccentColors = Object.freeze(Object.fromEntries(UI_LIBRARY_THEME_NAMES.map((name) => [name, UI_LIBRARY_LIGHT_THEME_PALETTES[name].primary])));
export const uiLibraryBaseSurfaces = Object.freeze(Object.fromEntries(UI_LIBRARY_BASE_COLOR_NAMES.map((name) => {
    const values = UI_LIBRARY_LIGHT_THEME_PALETTES[name];
    return [name, { border: values.border, muted: values.muted, foreground: values.foreground }];
})));
export const DEFAULT_UI_LIBRARY_PREVIEW_THEME_NAME = 'Svelte';
/**
 * Fallback for axes missing from previously saved selections. Saved data predates
 * the Svelte default, so its omitted values keep their original meaning.
 */
export const LEGACY_UI_LIBRARY_PREVIEW_THEME_FALLBACK = {
    style: 'Nova',
    baseColor: 'Neutral',
    theme: 'Neutral',
    chartColor: 'Neutral',
    font: 'System Sans',
    fontHeading: 'inherit',
    fontMono: 'System Mono',
    iconLibrary: 'Lucide',
    radius: 'Default',
    cornerShape: 'Default',
    menuColor: 'Default',
    menuAppearance: 'Solid',
    menuAccent: 'Subtle'
};
// Shared Svelte style: spfx-kit-styles/themes/8f6bcff6-bc73-4116-811a-d40a6065a20c.json.
export const DEFAULT_UI_LIBRARY_PREVIEW_THEME_SELECTION = {
    style: 'Luma',
    baseColor: 'Zinc',
    theme: 'Blue',
    chartColor: 'Blue',
    font: 'Inter',
    fontHeading: 'inherit',
    fontMono: 'Geist Mono',
    iconLibrary: 'HugeIcons',
    radius: 'Default',
    cornerShape: 'Squircle',
    menuColor: 'Default',
    menuAppearance: 'Translucent',
    menuAccent: 'Subtle'
};
function findName(value, names, fallback) {
    const normalizedValue = value?.trim().toLocaleLowerCase();
    return names.find((name) => name.toLocaleLowerCase() === normalizedValue) ?? fallback;
}
function normalizeFontName(value, fallback) {
    const names = Object.keys(uiLibraryFontFamilies);
    return names.find((name) => name.toLocaleLowerCase() === value?.trim().toLocaleLowerCase()) ?? fallback;
}
export function getUiLibraryThemeNamesForBaseColor(baseColor) {
    return [baseColor, ...UI_LIBRARY_CHROMATIC_COLOR_NAMES];
}
export function normalizeUiLibraryPreviewThemeSelection(selection, defaults = DEFAULT_UI_LIBRARY_PREVIEW_THEME_SELECTION) {
    const baseColor = findName(selection.baseColor, UI_LIBRARY_BASE_COLOR_NAMES, defaults.baseColor);
    const availableThemes = getUiLibraryThemeNamesForBaseColor(baseColor);
    const fallbackTheme = selection.baseColor === undefined && selection.theme === undefined ? defaults.theme : baseColor;
    const theme = findName(selection.theme, availableThemes, fallbackTheme);
    const requestedChartColor = selection.chartColor?.trim();
    const chartColor = requestedChartColor ? findName(requestedChartColor, availableThemes, baseColor) : theme;
    const font = normalizeFontName(selection.font, defaults.font);
    const requestedHeading = selection.fontHeading?.trim();
    const fontHeading = !requestedHeading || requestedHeading.toLocaleLowerCase() === 'inherit'
        ? 'inherit'
        : normalizeFontName(requestedHeading, font);
    const fontMono = normalizeFontName(selection.fontMono, defaults.fontMono);
    const combinedMenuValue = selection.menuColor?.toLocaleLowerCase() ?? '';
    const menuColor = findName(combinedMenuValue.includes('inverted') ? 'Inverted' : selection.menuColor, UI_LIBRARY_MENU_COLOR_NAMES, defaults.menuColor);
    const menuAppearance = findName(combinedMenuValue.includes('translucent') ? 'Translucent' : selection.menuAppearance, UI_LIBRARY_MENU_APPEARANCE_NAMES, defaults.menuAppearance);
    const requestedMenuAccent = findName(selection.menuAccent, UI_LIBRARY_MENU_ACCENT_NAMES, defaults.menuAccent);
    const menuAccent = menuAppearance === 'Translucent' ? 'Subtle' : requestedMenuAccent;
    return {
        style: findName(selection.style, UI_LIBRARY_STYLE_NAMES, defaults.style),
        baseColor,
        theme,
        chartColor,
        font,
        fontHeading: fontHeading === font ? 'inherit' : fontHeading,
        fontMono,
        iconLibrary: findName(selection.iconLibrary, UI_LIBRARY_ICON_LIBRARY_NAMES, defaults.iconLibrary),
        radius: findName(selection.radius, UI_LIBRARY_RADIUS_NAMES, defaults.radius),
        cornerShape: findName(selection.cornerShape, UI_LIBRARY_CORNER_SHAPE_NAMES, defaults.cornerShape),
        menuColor,
        menuAppearance,
        menuAccent
    };
}
function buildRegistryThemeValues(selection, mode) {
    const palettes = mode === 'dark' ? UI_LIBRARY_DARK_THEME_PALETTES : UI_LIBRARY_LIGHT_THEME_PALETTES;
    const baseValues = palettes[selection.baseColor];
    const themeValues = palettes[selection.theme];
    const chartValues = palettes[selection.chartColor];
    const values = { ...baseValues, ...themeValues };
    for (let index = 1; index <= 5; index += 1) {
        const key = `chart-${index}`;
        const value = chartValues[key];
        if (value)
            values[key] = value;
    }
    if (selection.menuAccent === 'Bold') {
        values.accent = values.primary;
        values['accent-foreground'] = values['primary-foreground'];
    }
    if (mode === 'light') {
        const radius = UI_LIBRARY_RADIUS_VALUES[selection.radius];
        if (radius !== undefined)
            values.radius = radius;
        if (selection.style === 'Luma') {
            const ringPalette = ('ring' in themeValues ? selection.theme : selection.baseColor);
            const ring = LUMA_LIGHT_RING[ringPalette];
            if (ring !== undefined) {
                values.ring = ring;
                values['sidebar-ring'] = ring;
            }
        }
    }
    return values;
}
/**
 * Luma light focus ring. The registry's light ring (Zinc `oklch(0.705 0.015 286.067)`, #9f9fa9) is 2.62:1 against
 * the white page and 2.39:1 against the muted fill, below the 3:1 WCAG 1.4.11 asks of a focus indicator. Luma draws
 * focus as a 1px border in the ring colour (Button, inputs, selects, CollapsibleTrigger, Disclosure), so in light
 * mode its ring and sidebar ring are moved to the lightest same-hue OKLCH grey (same chroma and hue, lightness in
 * 0.001 steps) that reaches 3:1 against both the palette's background and its muted fill, as rendered in 8-bit sRGB.
 * Keyed by the palette that supplies `ring` (the base colour, or the theme when the theme is a base colour; chromatic
 * themes set no ring). Other styles and dark mode keep the registry values.
 */
export const LUMA_LIGHT_RING = Object.freeze({
    Neutral: 'oklch(0.648 0 0)',
    Stone: 'oklch(0.647 0.01 56.259)',
    Zinc: 'oklch(0.645 0.015 286.067)',
    Mauve: 'oklch(0.641 0.019 323.02)',
    Olive: 'oklch(0.644 0.021 106.9)',
    Mist: 'oklch(0.639 0.014 214.4)',
    Taupe: 'oklch(0.639 0.014 41.2)'
});
/**
 * Mirrors shadcn/ui's buildRegistryTheme merge order at the pinned Create
 * registry revision. Dark values intentionally omit radius and inherit it from
 * the light/root rule when the preview resolves the active mode.
 */
export function buildUiLibraryRegistryTheme(selection) {
    const normalizedSelection = normalizeUiLibraryPreviewThemeSelection(selection);
    return Object.freeze({
        name: `${normalizedSelection.baseColor.toLocaleLowerCase()}-${normalizedSelection.theme.toLocaleLowerCase()}`,
        selection: normalizedSelection,
        cssVars: Object.freeze({
            light: Object.freeze(buildRegistryThemeValues(normalizedSelection, 'light')),
            dark: Object.freeze(buildRegistryThemeValues(normalizedSelection, 'dark'))
        })
    });
}
function resolveRegistryThemeValues(registryTheme, mode) {
    if (mode === 'light')
        return registryTheme.cssVars.light;
    return { ...registryTheme.cssVars.light, ...registryTheme.cssVars.dark };
}
function createCssVariables(values, fontBody, fontHeading, fontMono, radiusName, cornerShape, radius) {
    const compensatedRadius = compensateSquircleRadius(radius, cornerShape);
    const extendedRadiusVariables = radiusName === 'None'
        ? {
            '--skui-radius-xs': '0',
            '--skui-radius-2xl': '0',
            '--skui-radius-3xl': '0',
            '--skui-radius-4xl': '0'
        }
        : {
            '--skui-radius-xs': compensateSquircleRadius('2px', cornerShape),
            '--skui-radius-2xl': compensateSquircleRadius(`calc(${radius} + 8px)`, cornerShape),
            '--skui-radius-3xl': compensateSquircleRadius(`calc(${radius} + 12px)`, cornerShape),
            '--skui-radius-4xl': compensateSquircleRadius(`calc(${radius} + 16px)`, cornerShape)
        };
    const usesSquircle = radiusName !== 'None' && cornerShape === 'Squircle';
    const lumaSidebarRadiusContext = radiusName === 'None' ? '0' : `calc(${radius} + 4px)`;
    return Object.freeze({
        ...Object.fromEntries(Object.entries(values).map(([name, value]) => [`--${name}`, value])),
        ...extendedRadiusVariables,
        '--ui-library-radius-base': radius,
        '--ui-library-radius-pill': radiusName === 'None' ? '0px' : `calc(${radius} + 16px)`,
        '--ui-library-radius-pill-compact': radiusName === 'None' ? '0px' : `calc(${radius} + 12px)`,
        '--ui-library-luma-sidebar-radius-context': lumaSidebarRadiusContext,
        '--radius': compensatedRadius,
        '--ui-library-corner-shape': usesSquircle ? 'squircle' : 'round',
        '--ui-library-corner-radius-factor': usesSquircle ? String(SQUIRCLE_RADIUS_FACTOR) : '1',
        '--font-sans': fontBody,
        '--font-heading': fontHeading,
        '--font-mono': fontMono,
        '--spfx-ui-font-mono-weight': '400'
    });
}
function createThemeTokens(values, fontHeading, fontMono, mode, radiusValue = values.radius, cornerShape = 'Default') {
    const hasRadius = radiusValue.trim() !== '0';
    const radiusSm = hasRadius ? compensateSquircleRadius(`max(0px, calc(${radiusValue} - 4px))`, cornerShape) : '0';
    const radiusMd = hasRadius ? compensateSquircleRadius(`max(0px, calc(${radiusValue} - 2px))`, cornerShape) : '0';
    const radiusLg = hasRadius ? compensateSquircleRadius(radiusValue, cornerShape) : '0';
    const radiusXl = hasRadius ? compensateSquircleRadius(`calc(${radiusValue} + 4px)`, cornerShape) : '0';
    return {
        mode,
        colorBackground: values.background,
        colorForeground: values.foreground,
        colorCard: values.card,
        colorCardForeground: values['card-foreground'],
        colorPopover: values.popover,
        colorPopoverForeground: values['popover-foreground'],
        colorPrimary: values.primary,
        colorPrimaryForeground: values['primary-foreground'],
        colorSecondary: values.secondary,
        colorSecondaryForeground: values['secondary-foreground'],
        colorMuted: values.muted,
        colorMutedForeground: values['muted-foreground'],
        colorAccent: values.accent,
        colorAccentForeground: values['accent-foreground'],
        colorDestructive: values.destructive,
        colorBorder: values.border,
        colorInput: values.input,
        colorRing: values.ring,
        radiusSm,
        radiusMd,
        radiusLg: `var(--radius, ${radiusLg})`,
        radiusXl,
        fontHeading,
        fontMono
    };
}
function compensateSquircleRadius(radius, cornerShape) {
    if (cornerShape !== 'Squircle' || radius.trim() === '0')
        return radius;
    return `calc(${radius} * ${SQUIRCLE_RADIUS_FACTOR})`;
}
export function createBaseNovaUiThemeTokens(mode = 'light') {
    return createUiLibraryPreviewTheme(DEFAULT_UI_LIBRARY_PREVIEW_THEME_SELECTION, mode).tokens;
}
export function createUiLibraryPreviewTheme(selection, mode = 'light') {
    const registryTheme = buildUiLibraryRegistryTheme(selection);
    const normalizedSelection = registryTheme.selection;
    const values = resolveRegistryThemeValues(registryTheme, mode);
    const fontBody = uiLibraryFontFamilies[normalizedSelection.font] ?? uiLibraryFontFamilies['System Sans'];
    const fontHeading = normalizedSelection.fontHeading === 'inherit'
        ? fontBody
        : (uiLibraryFontFamilies[normalizedSelection.fontHeading] ?? fontBody);
    const fontMono = uiLibraryFontFamilies[normalizedSelection.fontMono] ?? uiLibraryFontFamilies['System Mono'];
    const chartColors = [values['chart-1'], values['chart-2'], values['chart-3'], values['chart-4'], values['chart-5']];
    const selectedRadius = UI_LIBRARY_RADIUS_VALUES[normalizedSelection.radius] ?? values.radius;
    const radius = selectedRadius;
    return {
        mode,
        selection: normalizedSelection,
        tokens: createThemeTokens(values, fontHeading, fontMono, mode, radius, normalizedSelection.cornerShape),
        cssVariables: createCssVariables(values, fontBody, fontHeading, fontMono, normalizedSelection.radius, normalizedSelection.cornerShape, radius),
        fontBody,
        fontHeading,
        fontMono,
        chartColors,
        chartColor: chartColors[3]
    };
}
export function createUiLibraryInvertedMenuThemeTokens(selection, activeMode) {
    return createUiLibraryPreviewTheme(selection, activeMode === 'light' ? 'dark' : 'light').tokens;
}
export function applyUiLibraryPreviewTheme(host, tokens) {
    host.applyTheme(tokens);
    const defaultTheme = createUiLibraryPreviewTheme(DEFAULT_UI_LIBRARY_PREVIEW_THEME_SELECTION, tokens.mode);
    for (const surface of [host.appRoot, host.portalHost]) {
        for (const tokenName of chartTokenNames)
            surface.style.setProperty(tokenName, defaultTheme.cssVariables[tokenName]);
    }
}
export { applyUiLibraryPreviewCssVariables, restoreLabUiTheme } from './runtime-theme';
export function applyUiLibraryThemeSelection(host, previewTheme) {
    applyCompiledThemeSelection(host, previewTheme, createUiLibraryInvertedMenuThemeTokens(previewTheme.selection, previewTheme.mode));
}
export function applyUiLibraryTheme(host, previewTheme) {
    applyCompiledTheme(host, previewTheme, createUiLibraryInvertedMenuThemeTokens(previewTheme.selection, previewTheme.mode));
}
