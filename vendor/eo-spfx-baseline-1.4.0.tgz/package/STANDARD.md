# The Executive Office SPFx standard

Human-readable rendering of [`contracts/toolchain.json`](contracts/toolchain.json) and
[`contracts/ui-runtime.json`](contracts/ui-runtime.json). **Those files are authoritative** —
they are what `eo-spfx audit` reads and what CI enforces. If this page and the JSON disagree,
the JSON wins and this page is the bug.

The original toolchain pins came from the tested `task-tracker-spfx/toolchains/heft-preview/package.json` configuration. The committed contracts define the accepted profile; each consuming app still needs its own local and tenant acceptance. A standalone baseline clone does not require that historical sibling checkout.

---

## 1. Platform

| Thing | Pinned value | Notes |
|---|---|---|
| SPFx | **1.23.2** | All `@microsoft/sp-*`, the build rig, and the Heft plugins move together |
| Build | **`@rushstack/heft` 1.2.19** | |
| TypeScript | **`~5.8.0`** | lock resolves 5.8.3 |
| Node | **`>=22.14.0 <23.0.0`** | `engines` field in every project |
| React | **17.0.1** | React 18 is *not* supported by this SPFx line |
| Package manager | **npm**, `package-lock.json` committed, install with `npm ci` | |

## 2. Full dependency set

The exact reference install. Pin these literally — no carets on the SPFx or Fluent lines.

### Runtime

```jsonc
"dependencies": {
  "@microsoft/sp-component-base":        "1.23.2",
  "@microsoft/sp-core-library":          "1.23.2",
  "@microsoft/sp-loader":                "1.23.2",
  "@microsoft/sp-lodash-subset":         "1.23.2",
  "@microsoft/sp-office-ui-fabric-core": "1.23.2",
  "@microsoft/sp-property-pane":         "1.23.2",
  "@microsoft/sp-webpart-base":          "1.23.2",

  "react":     "17.0.1",
  "react-dom": "17.0.1",
  "tslib":     "2.3.1",
  "@pnp/sp":   "4.20.0",

  // Fluent — see section 3 before changing ANY of these
  "@fluentui/react-components": "9.70.0",
  "@fluentui/react-icons":      "2.0.330",
  "@fluentui/react-tabster":    "9.26.14",
  "tabster":                    "8.5.5",
  "keyborg":                    "2.6.0"
}
```

> **Do not declare `@fluentui/react` (Fluent 8).** SPFx already depends on it —
> `sp-component-base`, `sp-loader`, `sp-property-pane`, and `sp-webpart-base` each pull it in —
> so it is always installed whether you list it or not. Declaring it adds an unpinned `^` range
> to an otherwise fully pinned project and buys nothing. Import from it if you need a v8 control
> that has no v9 equivalent; just don't add it to `dependencies`.

### Build / dev

```jsonc
"devDependencies": {
  "@microsoft/spfx-web-build-rig":   "1.23.2",
  "@microsoft/spfx-heft-plugins":    "1.23.2",
  "@microsoft/sp-module-interfaces": "1.23.2",
  "@microsoft/eslint-config-spfx":   "1.23.2",
  "@microsoft/eslint-plugin-spfx":   "1.23.2",
  "@rushstack/heft":                 "1.2.19",
  "typescript":                      "~5.8.0",
  "eslint":                          "9.37.0",
  "eslint-plugin-react-hooks":       "5.2.0",
  "css-loader":                      "~7.1.2",
  "@types/react":                    "17.0.45",
  "@types/react-dom":                "17.0.17",
  "@types/webpack-env":              "~1.15.2",
  "@types/jest":                     "30.0.0"
},
"resolutions": {
  "@types/react": "17.0.45"
}
```

> The `resolutions` entry is not optional. Something in the tree will pull `@types/react` 18
> and TypeScript will then fail on JSX in ways that look unrelated to React.

## 3. The Fluent / Tabster contract

SharePoint and Fluent v9 share the page-global `window.__tabsterInstance`, including across
modern navigation. A Fluent dependency that installs a *different or nested* Tabster runtime
fails at page load with `Cannot read properties of undefined (reading 'set')`. Never delete,
replace, or monkeypatch that global.

Contract id: **`sharepoint-shell-tabster-8.5.5`**

| Part | Count | What it does |
|---|---|---|
| Direct pins | 5 | `react-components` 9.70.0, `react-icons` 2.0.330, `react-tabster` 9.26.14, `tabster` 8.5.5, `keyborg` 2.6.0 |
| `overrides` | 71 | The full 9.70.0 closure — every `@fluentui/react-*`, `@griffel/*`, `@fluentui/tokens` |
| Single physical copy | 4 | `react-components`, `react-tabster`, `tabster`, `keyborg` must each resolve to exactly one top-level install |

**Pinning the aggregate alone does not work.** `@fluentui/react-components` declares *ranges*
for its internal packages, so without all 71 overrides a fresh `npm install` can silently move
`tabster` or `keyborg` and reintroduce the failure. The full list is in
[`contracts/ui-runtime.json`](contracts/ui-runtime.json).

Applies to any project using a focus-managed v9 control: Tabs, dialogs, drawers, menus,
comboboxes/pickers, popovers, tooltips, trees — anything with focus, keyboard nav, portals,
overlays, or positioning.

A project with **no** Fluent React dependency is exempt. Native semantic HTML +
`@microsoft/sp-office-ui-fabric-core` + theme tokens is a legitimate choice for simple web parts.

## 4. Consistent delivery commands

Migrated Heft apps use descriptor-based delivery (baseline 1.2+). Keep dev/check/build for iteration; use package:dev and package:prod for finished artifacts. ship and release are compatibility aliases.

| Command | Behavior |
| --- | --- |
| npm run package:dev | Validate and build an isolated DEV package with permanent distinct IDs |
| npm run package:prod | Validate and build an isolated PROD package with preserved IDs and explicit CDN |
| npm run verify:cdn -- --build RETAINED-FOLDER --origin HTTPS-ORIGIN | Verify exact uploaded bytes before catalog installation |
| npm run releases:open | Open the app's root release directory |

Completed outputs always live in releases/dev/latest and releases/prod/latest, with immutable channel/app-version/build-id archives. Failed builds do not replace latest. Neither command deploys.

delivery/app.json declares the app and optional nested host; delivery/identities.json holds stable channel GUIDs; delivery/environments supplies the exact CDN and optional verification origins. Never infer CDN routes or GUIDs from checkout names. Tenants are deployment targets, not runtime allowlists. Keep permanent PROD identities in source; staging applies DEV values without changing source or lockfiles.

See [1.2 migration](MIGRATION-1.2.0.md) and [1.3 adoption](MIGRATION-1.3.md) for nested library builds, independent solution numbering and Teams icons. Legacy mode/Gulp templates remain for unmigrated apps and are not the standard for new or migrated applications.

## 5. Production / CDN

Production sites sit behind a block-download policy that 302-redirects ClientSideAssets requests
to an HTML policy page, so embedded assets **do not load** in production.

| Setting | Dev / test | Production |
|---|---|---|
| `config/package-solution.json` → `includeClientSideAssets` | `true` | `false` |
| `config/write-manifests.json` → `cdnBasePath` | ignored | exact CDN root from the selected delivery profile |

A production manifest must never contain `localhost`, `REPLACE-WITH`, or
`SPCLIENTSIDEASSETLIBRARY`. `eo-spfx preflight` checks this mechanically.

### Required from baseline 1.1.0: validate emitted chunks

The CDN serves classic scripts without CORS response headers. Use the shared
`config/webpack-cdn-compat.cjs` patch to set `output.crossOriginLoading: false`.
Merge it into the project's webpack configuration after other patches. This
preserves CSP and SharePoint permissions; it may reduce cross-origin exception
detail. ES module scripts require a separate CORS-capable hosting contract.

PROD must use `eo-spfx deliver prod` or invoke `eo-spfx preflight <sppkg> --assets <directory>`;
`audit` blocks omission of the asset argument. The check inspects emitted script
loaders and webpack 5 JSONP references, rejecting missing files, wrong chunk IDs,
mixed namespaces and invalid JavaScript. Heft uses `release/assets`, Gulp commonly
uses `temp/deploy`. Upload production manifests from `release/manifests`, never
the localhost manifests in `dist`.

After uploading matching assets, run `eo-spfx verify-cdn <sppkg> --assets <directory>`
before updating the App Catalog. It checks exact SHA-256 content, HTTP success,
JavaScript MIME types and referrer-based access for the lab and production origins
in the contract. Preserve bytes and retain older hashed assets. Finish with an
authenticated browser test of lazy views. CI validates and retains PROD outputs;
it does not publish assets or install applications.

## 5a. Cross-platform lockfiles — required if CI runs on Linux

`npm ci` installs **strictly** from the lockfile, including platform-specific optional
dependencies. A lockfile generated on Windows records only `sass-embedded-win32-x64`, so an
Ubuntu runner ends up with no Dart Sass compiler and Heft fails to load its sass plugin:

```
Embedded Dart Sass couldn't find the embedded compiler executable.
Please make sure the optional dependency sass-embedded-linux-x64 is installed
```

Declare both binaries so the lockfile carries both. The `os` constraint means each machine
still installs only the one it can use:

```jsonc
"optionalDependencies": {
  "sass-embedded-linux-x64": "1.85.1",
  "sass-embedded-win32-x64": "1.85.1"
}
```

Pin them to whatever `sass-embedded` version the build rig resolves — check with
`npm ls sass-embedded` — and revisit when the rig moves. The alternative is running CI on
`windows-latest`, which matches the dev machines but makes the eventual GitLab move harder.

## 6. The legacy lane

Still supported, not extended. Migrate a project on its next feature touch.

| Thing | Value |
|---|---|
| SPFx | 1.21.1 |
| Build | `gulp` 4.0.2 |
| TypeScript | 5.3.3 |
| React / Node | 17.0.1 / same as above |

Do not mix Gulp and Heft commands within one release.

---

## Two decisions still open

Recorded here so they are not mistaken for settled.

**Heft 1.2.17 vs 1.2.19.** The contract says **1.2.19**, matching the validated toolchain and
`org-chart-spfx`. But `better-list-spfx` and `cost-report-spfx` run 1.2.17, and
SPFX-ARCHITECTURE.md said 1.2.17 until 2026-07-25. 1.2.19 was chosen because it is the version
that was actually built and tenant-tested. This is a cheap decision to reverse — it is a build
tool, not shipped runtime — and the audit reports it as a warning, not a blocker.

**Fluent 9.70.0 vs 9.74.x — unresolved, and the bigger one.** The contract says 9.70.0 because
that is what was validated. But four projects already run 9.74.x with *none* of the closure
pinned: `better-list-spfx` (9.74.3), `cost-report-spfx` (9.74.1),
`user-management-portal-spfx` (9.74.1), `intake-front-door-spfx` (`^9.74.2`, an unpinned range).
They work today; nothing holds them there. Two honest paths:

1. **Converge on 9.70.0** — one already-validated closure everywhere. Cost: four projects move
   backwards a minor version, and any 9.71–9.74 API they use must be checked.
2. **Validate 9.74.x and move the contract forward** — generate the 9.74.x closure, tenant-test
   it once, update `ui-runtime.json`. Cost: a real tenant validation cycle before anything ships.

Either way the end state is one pinned closure. Leaving four projects on unpinned ranges is the
only option that is not a decision.
