# 1.3.1 — Teams packaging icons

SPFx always copies the teams/ folder even with includeClientSideAssets=false. An explicit teamsIcons descriptor permits only the two source-hashed PNG icons for the current component ID; embedded JavaScript and other runtime assets remain rejected. DEV renames these icons inside staging to its own component ID. Source identities and files remain unchanged. Add malformed/changed-icon and hidden-code regressions.

# 1.3.0 — nested applications and catalog version mapping

Add nested SPFx project roots, explicit solution-version mappings, and staged library build scripts. Local file dependencies use a private node_modules overlay pointing to staged source; installed dependencies and source lockfiles are never changed by packaging. Release manifests record every installation lock and the build graph. Existing flat apps remain compatible and stay on their pinned baseline until upgraded individually.

# 1.2.1 — SPFx manifest encoding

Accept omitted SkipFeatureDeployment as the SPFx false/default encoding for DEV. Explicit tenant-wide deployment remains rejected. Add a regression using the real emitted XML shape.

# 1.2.0 — portable delivery pilot

- Add isolated, descriptor-based DEV/PROD packaging and retained/latest release folders.
- Preserve PROD identity; require separate DEV solution/feature/component IDs.
- Add raw ZIP bytes for embedded binary asset validation and explicit CDN-root checks.
- Add tenant-neutral profiles and retained-build live verification.
- Add publication-failure, path, identity, portability and binary-asset tests.

# Changelog

## 1.1.0 — 2026-09-16

- Add a shared classic-script webpack patch for the managed CDN's missing CORS
  response headers. Consumers must register the patch in their build configuration.
- Extend production preflight with `--assets` to check emitted JavaScript,
  webpack 5 chunk filenames/IDs/namespaces and matching package entry bundles.
- Block audited PROD release scripts that omit the asset preflight.
- Add `verify-cdn` for live status, MIME type, redirect and exact checksum checks
  using the configured SharePoint referrers before App Catalog installation.
- Reject malformed package archives and packages without a verifiable CDN route.
- Update Heft/Gulp script templates, webpack configuration guidance and CI
  templates. Consumer CI retains matching PROD outputs without deploying them.
- Prefer a versioned vendored archive over private-repository tokens in CI.
- Fix the baseline's own workflow to run its real tests and package validation.
- Preserve the existing SPFx/React/Fluent/Tabster compatibility pins.

Manifest-only `preflight` remains available for diagnosis. Upgrading the baseline
does not rewrite consuming projects; register the shared patch and adopt the new
PROD release command before expecting the additional protection.
