'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { inspectJavaScript, inspectRelease, verifyCdn } = require('./cdn-assets.cjs');
const { preflight } = require('./preflight.cjs');

function zip(name, content) {
  const filename = Buffer.from(name);
  const bytes = Buffer.from(content);
  let crc = 0xffffffff;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++) crc = (crc >>> 1) ^ ((crc & 1) ? 0xedb88320 : 0);
  }
  crc = (crc ^ 0xffffffff) >>> 0;
  const header = Buffer.alloc(30);
  header.writeUInt32LE(0x04034b50); header.writeUInt16LE(20, 4);
  header.writeUInt32LE(crc, 14); header.writeUInt32LE(bytes.length, 18);
  header.writeUInt32LE(bytes.length, 22); header.writeUInt16LE(filename.length, 26);
  const central = Buffer.alloc(46);
  central.writeUInt32LE(0x02014b50); central.writeUInt16LE(20, 4); central.writeUInt16LE(20, 6);
  central.writeUInt32LE(crc, 16); central.writeUInt32LE(bytes.length, 20);
  central.writeUInt32LE(bytes.length, 24); central.writeUInt16LE(filename.length, 28);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50); end.writeUInt16LE(1, 8); end.writeUInt16LE(1, 10);
  end.writeUInt32LE(central.length + filename.length, 12);
  end.writeUInt32LE(header.length + filename.length + bytes.length, 16);
  return Buffer.concat([header, filename, bytes, central, filename, end]);
}

const main = `var w={};self.webpackJsonp_example=self.webpackJsonp_example||[];
w.u=e=>'chunk.'+e+'_'+({600:'abc',637:'def'}[e])+'.js';
w.l=(url,done)=>{var s=document.createElement('script');s.src=url;document.head.appendChild(s)};`;

function fixture(t, code = main) {
  const prefix = path.join(os.tmpdir(), 'eo-cdn-tests-');
  const root = fs.mkdtempSync(prefix);
  t.after(() => {
    assert.ok(path.resolve(root).startsWith(path.resolve(prefix)));
    fs.rmSync(root, { recursive: true, force: true });
  });
  const assets = path.join(root, 'assets'); fs.mkdirSync(assets);
  fs.writeFileSync(path.join(assets, 'main_abc.js'), code);
  for (const [id, hash] of [[600, 'abc'], [637, 'def']]) {
    fs.writeFileSync(path.join(assets, `chunk.${id}_${hash}.js`),
      `(self.webpackJsonp_example=self.webpackJsonp_example||[]).push([[${id}],{}]);`);
  }
  const manifest = JSON.stringify({ loaderConfig: {
    internalModuleBaseUrls: ['https://irm.azureedge.us/M/example-spfx/'],
    scriptResources: { app: { type: 'path', path: 'main_abc.js' } }
  } }).replace(/"/g, '&quot;');
  const sppkg = path.join(root, 'example.sppkg');
  fs.writeFileSync(sppkg, zip('manifest.xml', `<Manifest>${manifest}</Manifest>`));
  return { root, assets, sppkg };
}

test('accepts a complete release with classic chunks', t => {
  const f = fixture(t); const result = inspectRelease(f.sppkg, f.assets);
  assert.equal(result.ok, true, result.report.join('\n')); assert.equal(result.assets.length, 3);
});
test('rejects the old anonymous CORS loader despite a valid package', t => {
  const f = fixture(t, main.replace('s.src=url;', 's.crossOrigin="anonymous";s.src=url;'));
  assert.equal(preflight(f.sppkg).ok, true);
  const result = inspectRelease(f.sppkg, f.assets);
  assert.equal(result.ok, false); assert.match(result.report.join('\n'), /loader sets crossorigin/);
});
test('rejects crossorigin setAttribute and module-script loaders', () => {
  for (const attribute of ['s.setAttribute("crossorigin","anonymous");', 's.type="module";']) {
    assert.ok(inspectJavaScript(main.replace('s.src=url;', attribute + 's.src=url;')).problems.length);
  }
});
test('does not confuse an unrelated image crossorigin attribute with a script loader', () => {
  assert.deepEqual(inspectJavaScript(main + ';function image(){var i=document.createElement("img");i.crossOrigin="anonymous"}').problems, []);
});
test('rejects a missing lazy dependency', t => {
  const f = fixture(t); fs.unlinkSync(path.join(f.assets, 'chunk.637_def.js'));
  const r = inspectRelease(f.sppkg, f.assets); assert.equal(r.ok, false); assert.match(r.report.join('\n'), /missing referenced.*637/);
});
test('rejects mismatched package and entry bundle filenames', t => {
  const f = fixture(t); fs.renameSync(path.join(f.assets, 'main_abc.js'), path.join(f.assets, 'main_other.js'));
  assert.equal(inspectRelease(f.sppkg, f.assets).ok, false);
});
test('rejects a misnamed chunk which registers another ID', t => {
  const f = fixture(t); fs.copyFileSync(path.join(f.assets, 'chunk.600_abc.js'), path.join(f.assets, 'chunk.637_def.js'));
  const r = inspectRelease(f.sppkg, f.assets); assert.equal(r.ok, false); assert.match(r.report.join('\n'), /expected chunk 637/);
});
test('rejects a chunk from another webpack release namespace', t => {
  const f = fixture(t); const p = path.join(f.assets, 'chunk.637_def.js');
  fs.writeFileSync(p, fs.readFileSync(p, 'utf8').replaceAll('webpackJsonp_example', 'webpackJsonp_old'));
  const r = inspectRelease(f.sppkg, f.assets); assert.equal(r.ok, false); assert.match(r.report.join('\n'), /namespace differs/);
});
test('rejects truncated JavaScript and a missing asset directory', t => {
  const f = fixture(t); fs.writeFileSync(path.join(f.assets, 'chunk.637_def.js'), 'function(');
  assert.equal(inspectRelease(f.sppkg, f.assets).ok, false);
  assert.equal(inspectRelease(f.sppkg, path.join(f.root, 'missing')).ok, false);
});
test('rejects a manifest without a production route', t => {
  const f = fixture(t); fs.writeFileSync(f.sppkg, zip('manifest.xml', '<Manifest/>'));
  assert.equal(preflight(f.sppkg).ok, false);
});
test('rejects a malformed archive after its first valid entry', t => {
  const f = fixture(t); const bytes = fs.readFileSync(f.sppkg);
  bytes.writeUInt16LE(2, bytes.length - 22 + 10); fs.writeFileSync(f.sppkg, bytes);
  assert.equal(preflight(f.sppkg).ok, false);
});
test('live check uses referrer-only requests and accepts exact JavaScript without CORS headers', async t => {
  const f = fixture(t); const requests = [];
  const r = await verifyCdn(f.sppkg, f.assets, { origins: ['https://usdossiolab.sharepoint.com'], fetch: async (url, options) => {
    requests.push(options);
    return new Response(fs.readFileSync(path.join(f.assets, path.basename(url.pathname))), { headers: { 'content-type': 'application/javascript' } });
  } });
  assert.equal(r.ok, true); assert.equal(requests.length, 3);
  for (const request of requests) { assert.equal(request.headers.Origin, undefined); assert.equal(request.headers.Referer, 'https://usdossiolab.sharepoint.com/'); assert.equal(request.redirect, 'error'); }
});
test('live check rejects HTTP errors, HTML, changed content, and network failure', async t => {
  const f = fixture(t);
  for (const bad of [() => new Response('missing', { status: 404 }), () => new Response('<html/>', { headers: { 'content-type': 'text/html' } }),
    () => new Response('changed', { headers: { 'content-type': 'application/javascript' } }), () => { throw new Error('network failure'); }]) {
    assert.equal((await verifyCdn(f.sppkg, f.assets, { origins: ['https://usdossiolab.sharepoint.com'], fetch: bad })).ok, false);
  }
});
test('live check makes no requests when local release inspection fails', async t => {
  const f = fixture(t, main.replace('s.src=url;', 's.crossOrigin="anonymous";s.src=url;'));
  let calls = 0;
  const r = await verifyCdn(f.sppkg, f.assets, { fetch: () => { calls++; } });
  assert.equal(r.ok, false); assert.equal(calls, 0);
});
test('CLI rejects unsupported arguments instead of silently skipping checks', t => {
  const f = fixture(t);
  const r = spawnSync(process.execPath, [path.join(__dirname, '../bin/eo-spfx.cjs'), 'preflight', f.sppkg, '--asset', f.assets], { encoding: 'utf8' });
  assert.equal(r.status, 1); assert.match(r.stderr, /unexpected/);
});

test('audit blocks an unguarded release and accepts a guarded npm-script alias', t => {
  const f = fixture(t);
  fs.mkdirSync(path.join(f.root, '.git'));
  fs.writeFileSync(path.join(f.root, 'AGENTS.md'), '# Project guidance\n');
  fs.writeFileSync(path.join(f.root, 'package-lock.json'), '{}');
  const pkg = { dependencies: { '@microsoft/sp-core-library': '1.23.2' },
    devDependencies: { '@rushstack/heft': '1.2.19', typescript: '~5.8.0' },
    scripts: { dev: 'heft start', check: 'heft test', build: 'heft build', ship: 'heft package-solution',
      release: 'eo-spfx preflight sharepoint/solution/example.sppkg' } };
  const run = () => spawnSync(process.execPath, [path.join(__dirname, '../bin/eo-spfx.cjs'), 'audit', f.root, '--json'], { encoding: 'utf8' });
  fs.writeFileSync(path.join(f.root, 'package.json'), JSON.stringify(pkg));
  let result = run(); assert.equal(result.status, 1); assert.match(result.stdout, /cdn-assets/);
  pkg.scripts.release = 'npm run prod:verify';
  pkg.scripts['prod:verify'] = 'eo-spfx preflight sharepoint/solution/example.sppkg --assets release/assets';
  fs.writeFileSync(path.join(f.root, 'package.json'), JSON.stringify(pkg));
  result = run(); assert.equal(result.status, 0, result.stdout + result.stderr);
});

test('chunk resolver retains numeric IDs used by strict comparisons', () => {
  const result = inspectJavaScript('var w={};w.u=e=>e===637?"chunk.637_def.js":"chunk.600_abc.js";');
  assert.deepEqual(result.problems, []);
  assert.ok(result.chunks.includes('chunk.637_def.js'));
});
