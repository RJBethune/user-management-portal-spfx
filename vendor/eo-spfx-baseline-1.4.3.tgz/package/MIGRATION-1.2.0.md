# Baseline 1.2.0: portable delivery pilot

Toolchain/UI versions remain unchanged. New optional eo-spfx deliver dev|prod commands add descriptor-based channel identities, isolated build configuration, complete byte inventories, immutable releases and safe latest publication. Existing CLI commands remain supported.

Consumer adoption:

1. Preserve current source and installed PROD identity evidence. Add delivery/app.json, identities.json and environments/default.json from a reviewed pilot. Choose permanent new DEV solution/feature/component IDs once.
2. Keep PROD identities in source config. Align app/solution/feature versions; preserve CDN fixes and app-specific checks.
3. Pin this exact vendor archive and regenerate/review the lockfile. Alias package:dev and package:prod to eo-spfx deliver dev and prod. Keep ship/release aliases. Declare required validationScripts without recursive packaging.
4. Ignore generated releases, scratch and build output. Preserve historical artifacts before removing any tracked output.
5. Use src/delivery/buildInfo.ts for optional Settings version/channel display. Packaging stamps only its staging copy. It contains no tenant allowlist.
6. Run the baseline tests, app tests/evals, both channel builds, package/asset checks and later actual tenant acceptance. Production deployment still requires matching CDN bytes first.

Profiles customize asset hosting, not SharePoint tenant eligibility. verificationOrigins are test defaults only; verify a retained package against another tenant with --origin without rebuilding it. Rehosting to a different CDN requires rebuilding its manifest. No implicit tenant data migration.

The pilot covers ordinary single-component Heft apps. Multiple components, nested solution roots and additional asset-loader types require explicit support before their adoption. Unsupported input must fail rather than bypass validation.

Use eo-spfx deliver verify --build <retained-directory> [--origin <https-origin>] after upload. --allow-dirty is diagnostic-only and never advances official latest. Baseline archive rollback restores the prior coherent package/config/lockfile set, not one isolated dependency.
