'use strict';

// The managed EO CDN serves classic scripts without CORS response headers.
// Keep lazy JSONP chunks in the same request mode as SPFx's initial bundle.
// CSP, the CDN URL, code splitting and SharePoint permissions remain unchanged.
module.exports = config => {
  config.output = { ...config.output, crossOriginLoading: false };
  return config;
};
