'use strict';

// Descriptor-driven packaging. Tenant configuration and channel identities are inputs,
// never inferred from checkout names. Builders only write inside an isolated staging tree.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync, execFileSync } = require('node:child_process');
const { readZipEntries } = require('./preflight.cjs');
const { inspectRelease } = require('./cdn-assets.cjs');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const json = file => JSON.parse(fs.readFileSync(file, 'utf8'));
const writeJson = (file, value) => { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, JSON.stringify(value, null, 2) + '\n'); };
const assert = (condition, message) => { if (!condition) throw new Error(message); };
const slug = value => typeof value === 'string' && /^[a-z0-9][a-z0-9-]*$/.test(value);
const guid = value => typeof value === 'string' && /^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(value);

function inside(root, relative) {
  assert(typeof relative === 'string' && relative && !path.isAbsolute(relative), 'Expected a relative path');
  const target = path.resolve(root, relative);
  assert(target.startsWith(path.resolve(root) + path.sep), 'Path escapes its root: ' + relative);
  let current = path.resolve(root);
  for (const part of path.relative(current, target).split(path.sep)) {
    current = path.join(current, part);
    if (fs.existsSync(current)) assert(!fs.lstatSync(current).isSymbolicLink(), 'Symlink/reparse input is not supported: ' + relative);
  }
  return target;
}

function httpsUrl(value, originOnly = false) {
  const url = new URL(value);
  assert(url.protocol === 'https:' && !url.username && !url.password && !url.search && !url.hash, 'Expected a credential-free HTTPS URL');
  if (originOnly) assert(url.pathname === '/', 'SharePoint origins must not include a site path');
  else assert(url.pathname.endsWith('/'), 'CDN root must end with /');
  return originOnly ? url.origin : url.href;
}

function loadConfig(root, profileName) {
  const app = json(inside(root, 'delivery/app.json'));
  assert(app.schemaVersion === 1 && slug(app.appKey) && typeof app.projectRoot === 'string', 'Unsupported app descriptor');
  const projectRoot = projectPath(root, app.projectRoot);
  assert(typeof app.displayName === 'string' && app.displayName.length > 0, 'App display name is required');
  assert(slug(profileName || app.defaultProfile), 'Invalid profile name');
  const name = profileName || app.defaultProfile;
  const profile = json(inside(root, 'delivery/environments/' + name + '.json'));
  assert(profile.schemaVersion === 1 && profile.id === name, 'Profile identity/schema mismatch');
  const ids = json(inside(root, 'delivery/identities.json'));
  const components = [{ key: 'main', manifest: app.componentManifest, displayName: app.displayName }, ...(app.additionalComponents || [])];
  const keys = new Set(), manifestsSeen = new Set();
  for (const item of components) {
    assert(slug(item.key) && !keys.has(item.key) && typeof item.displayName === 'string' && item.displayName, 'Invalid/duplicate component descriptor');
    const file = inside(root, item.manifest);
    assert(!manifestsSeen.has(file), 'Duplicate component manifest');
    keys.add(item.key); manifestsSeen.add(file); item.source = json(file);
  }
  const seen = new Set();
  for (const channel of ['dev', 'prod']) {
    const identity = ids[channel], environment = profile.channels?.[channel];
    assert(identity && environment, 'Both DEV and PROD must be declared');
    assert(Object.keys(identity.additionalComponentIds || {}).sort().join() === components.slice(1).map(c => c.key).sort().join(), 'Additional component identities must match descriptors');
    for (const id of [identity.solutionId, identity.featureId, identity.componentId, ...Object.values(identity.additionalComponentIds || {})]) {
      assert(guid(id) && !seen.has(id.toLowerCase()), 'Channel identities must be valid and distinct'); seen.add(id.toLowerCase());
    }
    assert(['embedded', 'cdn'].includes(environment.assetMode), 'Unsupported asset mode');
    assert(channel !== 'prod' || environment.assetMode === 'cdn', 'This profile requires PROD CDN delivery');
    assert(environment.skipFeatureDeployment === undefined || typeof environment.skipFeatureDeployment === 'boolean', 'skipFeatureDeployment must be a boolean when declared');
    assert(channel !== 'dev' || environment.skipFeatureDeployment !== false, 'DEV must support adding the app to all sites; skipFeatureDeployment cannot be false');
    environment.cdnRoot = httpsUrl(environment.cdnRoot);
    assert(!environment.verificationOrigins || Array.isArray(environment.verificationOrigins), 'Verification origins must be an array');
    environment.verificationOrigins = (environment.verificationOrigins || []).map(x => httpsUrl(x, true));
  }
  inside(root, app.componentManifest);
  assert(Array.isArray(app.validationScripts) && app.validationScripts.length && app.validationScripts.every(s => /^[a-z0-9:-]+$/.test(s)), 'Validation scripts are required');
  const pkg = json(inside(root, 'package.json'));
  assert(/^\d+\.\d+\.\d+$/.test(pkg.version), 'Use a numeric app release version');
  for (const script of app.validationScripts) assert(pkg.scripts?.[script] && !/eo-spfx\s+deliver/.test(pkg.scripts[script]), 'Invalid/recursive validation script: ' + script);
  const solutionVersion = app.solutionVersion || pkg.version + '.0';
  assert(/^\d+\.\d+\.\d+\.\d+$/.test(solutionVersion), 'Invalid solution version');
  assert(json(inside(projectRoot, 'package.json')).version === pkg.version, 'Library/app and SPFx host versions must agree');
  const solution = json(inside(projectRoot, 'config/package-solution.json'));
  // Eligibility is independent of asset hosting. Every DEV package supports
  // adding the app to all sites; PROD preserves its declared/source behavior.
  const skipFeatureDeployment = {
    dev: true,
    prod: profile.channels.prod.skipFeatureDeployment ?? (solution.solution.skipFeatureDeployment === true)
  };
  assert(solution.solution.features?.length === 1 && solution.solution.version === solutionVersion && solution.solution.features[0].version === solutionVersion, 'App, solution and feature versions must agree with the declared mapping');
  assert(solution.solution.id === ids.prod.solutionId && solution.solution.features[0].id === ids.prod.featureId && json(inside(root, app.componentManifest)).id === ids.prod.componentId, 'Source must retain the permanent PROD identities');
  for (const item of components) assert(item.source.id === componentId(ids.prod, item.key), 'Source must retain the permanent PROD identity: ' + item.key);
  const bundlesFile = inside(projectRoot, 'config/config.json');
  if (fs.existsSync(bundlesFile)) {
    const bundled = Object.values(json(bundlesFile).bundles || {}).flatMap(b => b.components || []).map(c => inside(projectRoot, c.manifest));
    assert(bundled.length === components.length && bundled.every(f => manifestsSeen.has(f)), 'Every bundled component must have a channel identity');
  }
  const installRoots = [...new Set(['.', app.projectRoot])];
  for (const script of app.stageScripts || []) assert(/^[a-z0-9:-]+$/.test(script) && pkg.scripts?.[script] && !/eo-spfx\s+deliver/.test(pkg.scripts[script]), 'Invalid/recursive stage script');
  for (const script of [...(app.afterBuildScripts || []), ...(app.afterPackageScripts || [])]) assert(/^[a-z0-9:-]+$/.test(script) && pkg.scripts?.[script] && !/eo-spfx\s+deliver/.test(pkg.scripts[script]), 'Invalid/recursive post-build script');
  for (const local of app.localPackages || []) {
    assert(installRoots.includes(local.installRoot) && /^(@[a-z0-9-]+\/)?[a-z0-9-]+$/.test(local.name), 'Invalid local package');
    const sourceRoot = projectPath(root, local.sourceRoot), installRoot = projectPath(root, local.installRoot);
    const dep = json(inside(installRoot, 'package.json')).dependencies?.[local.name];
    assert(dep?.startsWith('file:') && path.resolve(installRoot, dep.slice(5)) === sourceRoot, 'Local package must refer to its declared source directory');
    assert(json(inside(sourceRoot, 'package.json')).name === local.name, 'Local package name mismatch');
  }
  const component = json(inside(root, app.componentManifest)), packagingIcons = [];
  if (app.teamsIcons) {
    assert(app.teamsIcons === true && component.supportedHosts?.some(h => h.startsWith('Teams')), 'Teams icon exception requires a Teams-capable component');
    for (const suffix of ['_color.png', '_outline.png']) {
      const bytes = fs.readFileSync(inside(projectRoot, 'teams/' + ids.prod.componentId + suffix));
      assert(bytes.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10])), 'Teams icon must be a PNG');
      packagingIcons.push({ suffix, sha256: sha(bytes) });
    }
  }
  return { app, profile, ids, pkg, solutionVersion, installRoots, component, components, packagingIcons, skipFeatureDeployment };
}

function componentId(identity, key) { return key === 'main' ? identity.componentId : identity.additionalComponentIds?.[key]; }

function projectPath(root, relative) { return relative === '.' ? path.resolve(root) : inside(root, relative); }

// Registry dependencies remain read-only junctions to each locked installation.
// A private overlay redirects repo-local packages to the isolated source tree,
// preventing nested hosts from bundling stale output from the working checkout.
function stageDependencies(root, stage, config) {
  const link = (source, target) => fs.symlinkSync(source, target, process.platform === 'win32' ? 'junction' : 'dir');
  for (const relative of config.installRoots || ['.']) {
    const installed = path.join(projectPath(root, relative), 'node_modules');
    const target = path.join(projectPath(stage, relative), 'node_modules');
    assert(fs.existsSync(installed), 'Run npm ci in ' + relative + ' before packaging');
    const local = (config.app.localPackages || []).filter(x => x.installRoot === relative);
    if (!local.length) { link(installed, target); continue; }
    fs.mkdirSync(target);
    const names = new Set(local.map(x => x.name));
    for (const entry of fs.readdirSync(installed, { withFileTypes: true })) {
      if (names.has(entry.name)) continue;
      const source = path.join(installed, entry.name), dest = path.join(target, entry.name);
      if (entry.name.startsWith('@') && local.some(x => x.name.startsWith(entry.name + '/'))) {
        fs.mkdirSync(dest);
        for (const child of fs.readdirSync(source)) if (!names.has(entry.name + '/' + child)) link(path.join(source, child), path.join(dest, child));
      } else if (entry.isFile()) fs.copyFileSync(source, dest);
      else link(source, dest);
    }
    for (const item of local) { const dest = path.join(target, item.name); fs.mkdirSync(path.dirname(dest), { recursive: true }); link(projectPath(stage, item.sourceRoot), dest); }
  }
}

function git(root, args) { return execFileSync('git', ['-C', root, ...args], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trimEnd(); }
function inputFiles(root) {
  return [...new Set(git(root, ['ls-files', '-z', '--cached', '--others', '--exclude-standard']).split('\0').filter(Boolean))].sort().map(relative => {
    const file = inside(root, relative);
    assert(fs.existsSync(file) && fs.statSync(file).isFile(), 'Missing source input: ' + relative);
    return { path: relative, sha256: sha(fs.readFileSync(file)) };
  });
}
const digestInputs = files => sha(Buffer.from(JSON.stringify(files)));

function acquireLock(root) {
  const folder = inside(root, 'scratch/.delivery-lock'); fs.mkdirSync(path.dirname(folder), { recursive: true });
  try { fs.mkdirSync(folder); } catch (error) { if (error.code === 'EEXIST') throw new Error('Another delivery owns scratch/.delivery-lock. Check owner.json; after a terminated build, remove this lock only after confirming its PID is no longer running.'); throw error; }
  writeJson(path.join(folder, 'owner.json'), { pid: process.pid, createdAt: new Date().toISOString() });
  return () => { fs.unlinkSync(path.join(folder, 'owner.json')); fs.rmdirSync(folder); };
}

function command(root, executable, args, log) {
  fs.mkdirSync(path.dirname(log), { recursive: true });
  const fd = fs.openSync(log, 'w'); let result;
  try { result = spawnSync(executable, args, { cwd: root, stdio: ['ignore', fd, fd], windowsHide: true }); } finally { fs.closeSync(fd); }
  assert(!result.error && result.status === 0, 'Command failed (' + (result.error?.message || result.status) + '). Full log: ' + log);
}

function applyProfile(stage, config, channel) {
  const identity = config.ids[channel], environment = config.profile.channels[channel];
  const project = projectPath(stage, config.app.projectRoot);
  const solutionFile = inside(project, 'config/package-solution.json'), componentFile = inside(stage, config.app.componentManifest);
  const solution = json(solutionFile), component = json(componentFile);
  solution.solution.id = identity.solutionId;
  solution.solution.features[0].id = identity.featureId;
  solution.solution.includeClientSideAssets = environment.assetMode === 'embedded';
  solution.solution.skipFeatureDeployment = config.skipFeatureDeployment[channel];
  if (channel === 'dev') {
    solution.solution.name = config.app.displayName + ' DEV';
    if (solution.solution.title) solution.solution.title = config.app.displayName + ' DEV';
    solution.solution.features[0].title = config.app.displayName + ' DEV - web part';
    for (const entry of component.preconfiguredEntries) entry.title.default = config.app.displayName + ' DEV';
  }
  component.id = identity.componentId;
  for (const item of config.components?.slice(1) || []) {
    const file = inside(stage, item.manifest), extra = json(file);
    extra.id = componentId(identity, item.key);
    for (const entry of extra.preconfiguredEntries) entry.title.default = item.displayName + (channel === 'dev' ? ' DEV' : '');
    writeJson(file, extra);
  }
  for (const icon of config.packagingIcons || []) {
    const target = inside(project, 'teams/' + identity.componentId + icon.suffix);
    if (!fs.existsSync(target)) {
      const previous = inside(project, 'teams/' + config.ids[channel === 'dev' ? 'prod' : 'dev'].componentId + icon.suffix);
      assert(sha(fs.readFileSync(previous)) === icon.sha256, 'Staged Teams icon changed');
      fs.renameSync(previous, target);
    }
    assert(sha(fs.readFileSync(target)) === icon.sha256, 'Staged Teams icon changed');
  }
  const manifests = json(inside(project, 'config/write-manifests.json')); manifests.cdnBasePath = environment.cdnRoot;
  writeJson(solutionFile, solution); writeJson(componentFile, component); writeJson(inside(project, 'config/write-manifests.json'), manifests);
  const buildInfo = { appKey: config.app.appKey, version: config.pkg.version, channel };
  fs.mkdirSync(inside(project, 'src/delivery'), { recursive: true });
  fs.writeFileSync(inside(project, 'src/delivery/buildInfo.ts'), '// Generated in the isolated build; source defaults stay unchanged.\nexport const buildInfo = ' + JSON.stringify(buildInfo, null, 2) + ' as const;\n');
}

function collectAssets(root) {
  const files = [];
  function walk(dir) { for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const file = path.join(dir, entry.name); assert(!entry.isSymbolicLink(), 'Asset symlink is not allowed');
    if (entry.isDirectory()) walk(file); else { const bytes = fs.readFileSync(file); assert(bytes.length, 'Empty asset: ' + file); files.push({ path: path.relative(root, file).replaceAll('\\', '/'), bytes: bytes.length, sha256: sha(bytes) }); }
  } }
  walk(root); assert(files.some(f => f.path.endsWith('.js')), 'No emitted JavaScript');
  return files.sort((a, b) => a.path.localeCompare(b.path));
}

function inspectPackage(packageFile, assetsDir, config, channel) {
  const entries = readZipEntries(fs.readFileSync(packageFile), () => true, { binary: true });
  const text = name => entries.find(e => e.name === name)?.content.toString('utf8');
  const xml = text('AppManifest.xml') || '', ids = config.ids[channel], env = config.profile.channels[channel];
  assert(xml.includes('ProductID="' + ids.solutionId + '"') && xml.includes('Version="' + config.solutionVersion + '"'), 'Wrong package solution identity/version');
  const feature = entries.filter(e => /\.xml$/i.test(e.name)).some(e => new RegExp('<Feature\\b[^>]*\\bId="' + ids.featureId + '"', 'i').test(e.content.toString('utf8')));
  assert(feature, 'Wrong package feature identity');
  const manifests = entries.filter(e => /(?:^|\/)WebPart_[^/]+\.xml$/i.test(e.name));
  const expected = config.components || [{ key: 'main', displayName: config.app.displayName, source: config.component }];
  assert(manifests.length === expected.length, 'Wrong number of web-part components');
  const packed = manifests.map(m => {
    const encoded = m.content.toString('utf8').match(/ComponentManifest="([^"]+)"/);
    assert(encoded, 'Missing component manifest');
    return JSON.parse(encoded[1].replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&'));
  });
  for (const item of expected) {
    const component = packed.find(c => c.id === componentId(ids, item.key));
    assert(component && component.version === config.pkg.version, 'Wrong component identity/version: ' + item.key);
    for (const key of ['supportedHosts', 'supportsFullBleed', 'supportsThemeVariants']) {
      if (item.source[key] !== undefined) assert(JSON.stringify(component[key]) === JSON.stringify(item.source[key]), 'Package changed component capability: ' + key);
    }
    if (config.app.requirePickerTitle) assert(component.preconfiguredEntries?.[0]?.title?.default === item.displayName + (channel === 'dev' ? ' DEV' : ''), 'Wrong web-part picker title');
    const bases = component.loaderConfig?.internalModuleBaseUrls;
    assert(Array.isArray(bases) && bases.length > 0, 'Missing component asset root');
    if (env.assetMode === 'embedded') assert(bases.every(u => u.includes('SPCLIENTSIDEASSETLIBRARY')), 'DEV embedded manifest is not embedded');
    else assert(JSON.stringify(bases) === JSON.stringify([env.cdnRoot]), 'Wrong CDN destination');
  }
  const assets = collectAssets(assetsDir);
  const embeddedFiles = entries.filter(e => /(?:^|\/)ClientSideAssets\/./i.test(e.name) && !e.name.endsWith('/'));
  const iconFiles = (config.packagingIcons || []).map(icon => ({ name: 'ClientSideAssets/' + ids.componentId + icon.suffix, sha256: icon.sha256 }));
  for (const icon of iconFiles) assert(embeddedFiles.some(e => e.name === icon.name && sha(e.content) === icon.sha256), 'Missing or changed Teams icon: ' + icon.name);
  if (env.assetMode === 'embedded') {
    const embedded = entries.filter(e => /(?:^|\/)ClientSideAssets\//i.test(e.name));
    for (const asset of assets) {
      const found = embedded.find(e => e.name.endsWith('/' + asset.path));
      assert(found && sha(found.content) === asset.sha256, 'Missing or mismatched embedded asset: ' + asset.path);
    }
  } else {
    assert(embeddedFiles.every(e => iconFiles.some(icon => icon.name === e.name && sha(e.content) === icon.sha256)), 'CDN package embeds unapproved runtime assets');
    const inspected = inspectRelease(packageFile, assetsDir, { cdnBaseUrl: env.cdnRoot });
    assert(inspected.ok, inspected.report.join('\n'));
  }
  const deploymentAttribute = xml.match(/<App\b[^>]*\bSkipFeatureDeployment="([^"]+)"/);
  const expectedDeployment = config.skipFeatureDeployment[channel];
  assert(expectedDeployment
    ? deploymentAttribute && ['true', '1'].includes(deploymentAttribute[1])
    : !deploymentAttribute || ['false', '0'].includes(deploymentAttribute[1]),
  'Package tenant-wide eligibility does not match the declared deployment profile');
  return { ok: true, channel, profile: config.profile.id, identities: ids, assets, packagingIcons: iconFiles, skipFeatureDeployment: expectedDeployment };
}

function verifyBuild(folder) {
  const manifest = json(path.join(folder, 'release-manifest.json'));
  assert(manifest.schemaVersion === 1 && Array.isArray(manifest.files) && manifest.files.length, 'Invalid release manifest');
  for (const file of manifest.files) assert(sha(fs.readFileSync(inside(folder, file.path))) === file.sha256, 'Release bytes changed: ' + file.path);
  const sums = fs.readFileSync(path.join(folder, 'SHA256SUMS.txt'), 'utf8').trim().split('\n');
  for (const line of sums) { const match = line.match(/^([a-f0-9]{64})  (.+)$/); assert(match && sha(fs.readFileSync(inside(folder, match[2]))) === match[1], 'Checksum list mismatch'); }
  return manifest;
}

function publish(root, staged, config, channel, buildId) {
  verifyBuild(staged);
  const retained = inside(root, `releases/${channel}/${config.pkg.version}/${buildId}`);
  assert(!fs.existsSync(retained), 'A retained build cannot be overwritten');
  fs.mkdirSync(path.dirname(retained), { recursive: true }); fs.renameSync(staged, retained);
  const channelRoot = inside(root, 'releases/' + channel + (config.profile.id === config.app.defaultProfile ? '' : '/profiles/' + config.profile.id));
  fs.mkdirSync(channelRoot, { recursive: true });
  const latest = path.join(channelRoot, 'latest'), previous = path.join(channelRoot, '.previous'), next = path.join(channelRoot, '.next-' + buildId);
  assert(!fs.existsSync(previous), 'Interrupted publication: inspect .previous before publishing again');
  fs.cpSync(retained, next, { recursive: true }); verifyBuild(next);
  let replaced = false;
  try {
    if (fs.existsSync(latest)) { fs.renameSync(latest, previous); replaced = true; }
    fs.renameSync(next, latest);
  } catch (error) { if (replaced && !fs.existsSync(latest)) fs.renameSync(previous, latest); throw error; }
  // Only the expendable alias copy is removed; retained builds are never deleted.
  if (replaced) fs.rmSync(inside(root, path.relative(root, previous)), { recursive: true });
  writeJson(path.join(channelRoot, 'latest.json'), { buildId, profile: config.profile.id, manifestSha256: sha(fs.readFileSync(path.join(latest, 'release-manifest.json'))), retained: path.relative(root, retained).replaceAll('\\', '/') });
  return { retained, latest };
}

function writeIndex(root) {
  const rows = [];
  for (const channel of ['dev', 'prod']) {
    const folder = path.join(root, 'releases', channel, 'latest'); if (!fs.existsSync(folder)) continue;
    const manifest = verifyBuild(folder);
    rows.push(`<tr><td>${channel.toUpperCase()}</td><td>${manifest.appVersion}</td><td>${manifest.profile}</td><td><a href="${channel}/latest/${manifest.packageFile}">Package</a> · <a href="${channel}/latest/DEPLOYMENT.md">Deployment instructions</a></td></tr>`);
  }
  fs.writeFileSync(inside(root, 'releases/index.html'), '<!doctype html><html lang="en"><meta charset="utf-8"><title>SPFx builds</title><style>body{font:16px system-ui;margin:3rem;line-height:1.6}td,th{padding:.7rem;text-align:left}table{border-collapse:collapse}tr{border-bottom:1px solid #ccc}</style><h1>Local build files</h1><p>Validated builds. Upload, installation and tenant verification remain separate.</p><table><tr><th>Channel</th><th>Version</th><th>Profile</th><th>Files</th></tr>' + rows.join('') + '</table></html>');
}

function deliver(root, channel, options = {}) {
  assert(['dev', 'prod'].includes(channel), 'Use dev or prod');
  const config = loadConfig(root, options.profile);
  assert(process.versions.node.split('.')[0] === '22' && Number(process.versions.node.split('.')[1]) >= 14, 'Node >=22.14 <23 is required');
  const initial = inputFiles(root), inputDigest = digestInputs(initial), sourceSha = git(root, ['rev-parse', 'HEAD']);
  const dirty = Boolean(git(root, ['status', '--porcelain']));
  assert(!dirty || options.allowDirty, 'Commit/reconcile source before packaging; --allow-dirty creates diagnostics only');
  const buildId = new Date().toISOString().replace(/[-:]/g, '').replace('.','').replace(/Z$/, 'Z') + '-' + sourceSha.slice(0, 8) + '-' + crypto.randomBytes(3).toString('hex');
  const unlock = acquireLock(root), work = inside(root, 'scratch/builds/' + buildId);
  try {
    fs.mkdirSync(work, { recursive: true }); const checks = path.join(work, 'checks');
    const npm = process.env.npm_execpath || path.join(path.dirname(process.execPath), 'node_modules/npm/bin/npm-cli.js');
    for (const script of config.app.validationScripts) {
      console.log('Checking ' + script + ' (log in ' + checks + ')');
      command(root, process.execPath, [npm, 'run', script], path.join(checks, script.replaceAll(':', '-') + '.log'));
    }
    assert(digestInputs(inputFiles(root)) === inputDigest, 'Validation changed source inputs');
    const stage = path.join(work, 'source'); fs.mkdirSync(stage);
    for (const file of initial) { const target = inside(stage, file.path); fs.mkdirSync(path.dirname(target), { recursive: true }); fs.copyFileSync(inside(root, file.path), target); }
    // Dependencies belong to this exact app/lockfile; installation never runs in staging.
    stageDependencies(root, stage, config);
    applyProfile(stage, config, channel);
    for (const script of config.app.stageScripts || []) command(stage, process.execPath, [npm, 'run', script], path.join(checks, 'stage-' + script.replaceAll(':', '-') + '.log'));
    const project = projectPath(stage, config.app.projectRoot);
    const heft = path.join(path.dirname(require.resolve('@rushstack/heft/package.json', { paths: [projectPath(root, config.app.projectRoot)] })), 'bin/heft');
    console.log('Building ' + config.app.displayName + ' ' + channel.toUpperCase() + ' / ' + config.profile.id);
    command(project, process.execPath, [heft, 'build', '--clean', '--production'], path.join(checks, 'build.log'));
    for (const script of config.app.afterBuildScripts || []) command(stage, process.execPath, [npm, 'run', script], path.join(checks, 'after-build-' + script.replaceAll(':', '-') + '.log'));
    command(project, process.execPath, [heft, 'package-solution', '--production'], path.join(checks, 'package.log'));
    for (const script of config.app.afterPackageScripts || []) command(stage, process.execPath, [npm, 'run', script], path.join(checks, 'after-package-' + script.replaceAll(':', '-') + '.log'));
    const solution = json(path.join(project, 'config/package-solution.json'));
    const sppkg = inside(project, 'sharepoint/' + solution.paths.zippedPackage), assets = inside(project, 'release/assets');
    const inspected = inspectPackage(sppkg, assets, config, channel);
    assert(digestInputs(inputFiles(root)) === inputDigest, 'Build changed source inputs');
    const output = path.join(work, 'handoff'); fs.mkdirSync(output);
    const packageFile = `${config.app.appKey}-${config.pkg.version}-${channel}.sppkg`;
    fs.copyFileSync(sppkg, path.join(output, packageFile)); fs.cpSync(assets, path.join(output, 'assets'), { recursive: true });
    writeJson(path.join(output, 'checks/package.json'), inspected);
    fs.cpSync(checks, path.join(output, 'checks'), { recursive: true });
    const env = config.profile.channels[channel];
    fs.writeFileSync(path.join(output, 'DEPLOYMENT.md'), `# ${config.app.displayName} ${config.pkg.version} ${channel.toUpperCase()}\n\nProfile: ${config.profile.id}. Suggested verification origins: ${env.verificationOrigins.join(', ') || 'supply the destination tenant at verification time'}. These are test defaults, not tenant restrictions.\n\nAsset mode: ${env.assetMode}. CDN root: ${env.cdnRoot}\n\nTenant-wide eligibility: ${config.skipFeatureDeployment[channel]}. ${config.skipFeatureDeployment[channel] ? 'In the tenant App Catalog, select Enable this app and add it to all sites (or Add to all sites for an existing app). The package enables this choice; an administrator must confirm deployment.' : 'Install or upgrade the app on each intended site.'}\n\n${env.assetMode === 'cdn' ? 'Upload the complete assets tree unchanged, preserving paths. Run npm run verify:cdn -- --build "<this retained build folder>" after upload; then manually update the App Catalog.' : 'This DEV package embeds assets. If the selected site blocks ClientSideAssets, configure an approved DEV CDN root/profile and rebuild.'}\n\nVerify catalog identities before installation. DEV uses separate component/feature IDs. Existing page instances in the same DEV family receive package updates; a deliberate transition is needed only when moving a page from another identity family. Do not replace PROD page bindings. Confirm DEV lists, endpoints, usage logs and recipients are test resources. No site/data isolation has been inferred from an origin allowlist.\n\nRun authenticated cold/warm, navigation, edit/remount, permission and feature smoke tests. Local checks do not prove upload, installation or tenant behavior. Keep the previous package/assets for rollback; an older package may need repackaging with a higher solution version. Never remove shared registrations as a cache fix.\n`);
    const allFiles = []; const enumerate = dir => { for (const e of fs.readdirSync(dir, { withFileTypes: true })) { const p = path.join(dir, e.name); if (e.isDirectory()) enumerate(p); else allFiles.push({ path: path.relative(output, p).replaceAll('\\', '/'), sha256: sha(fs.readFileSync(p)) }); } }; enumerate(output);
    const manifest = { schemaVersion: 1, appKey: config.app.appKey, displayName: config.app.displayName, appVersion: config.pkg.version, solutionVersion: config.solutionVersion, channel, profile: config.profile.id, buildId, createdAt: new Date().toISOString(), sourceSha, sourceDigest: inputDigest, dirty, lockfileSha256: sha(fs.readFileSync(path.join(root, 'package-lock.json'))), lockfiles: config.installRoots.map(relative => ({ path: (relative === '.' ? '' : relative + '/') + 'package-lock.json', sha256: sha(fs.readFileSync(path.join(projectPath(root, relative), 'package-lock.json'))) })), buildGraph: { projectRoot: config.app.projectRoot, stageScripts: config.app.stageScripts || [], localPackages: config.app.localPackages || [] }, baselineVersion: require('../package.json').version, baselineArchiveSha256: sha(fs.readFileSync(inside(root, config.pkg.devDependencies['@eo/spfx-baseline'].replace(/^file:/, '')))), toolchainProfile: config.app.baselineProfile, uiProfile: config.app.uiProfile, profileSha256: sha(Buffer.from(JSON.stringify(config.profile))), nodeVersion: process.versions.node, identity: config.ids[channel], environment: env, skipFeatureDeployment: config.skipFeatureDeployment[channel], packageFile, files: allFiles, validation: 'local-passed', deployment: 'unverified', knownIssueIds: config.app.knownIssueIds || [] };
    writeJson(path.join(output, 'release-manifest.json'), manifest);
    const sums = [...allFiles, { path: 'release-manifest.json', sha256: sha(fs.readFileSync(path.join(output, 'release-manifest.json'))) }];
    fs.writeFileSync(path.join(output, 'SHA256SUMS.txt'), sums.map(f => f.sha256 + '  ' + f.path).join('\n') + '\n');
    verifyBuild(output);
    if (dirty) { const diagnostic = inside(root, 'scratch/diagnostics/' + buildId); fs.mkdirSync(path.dirname(diagnostic), { recursive: true }); fs.renameSync(output, diagnostic); console.log('DIAGNOSTIC ONLY: ' + path.join(diagnostic, packageFile)); return { diagnostic }; }
    const result = publish(root, output, config, channel, buildId); writeIndex(root);
    console.log(`Validated ${channel.toUpperCase()} / ${config.profile.id}: ${path.join(result.latest, packageFile)}\nRetained build: ${result.retained}\nDeployment: UNVERIFIED`);
    return result;
  } finally { unlock(); }
}

async function verifyLive(root, folder, origins) {
  assert(folder, 'Select an explicit retained build with --build <folder>');
  const build = path.resolve(root, folder), manifest = verifyBuild(build);
  assert(!manifest.dirty && manifest.environment.assetMode === 'cdn', 'Only a clean CDN build can be verified for deployment');
  const local = inspectRelease(path.join(build, manifest.packageFile), path.join(build, 'assets'), { cdnBaseUrl: manifest.environment.cdnRoot });
  assert(local.ok, local.report.join('\n'));
  const results = [];
  const selectedOrigins = (origins?.length ? origins : manifest.environment.verificationOrigins || []).map(x => httpsUrl(x, true));
  assert(selectedOrigins.length, 'Supply --origin <SharePoint origin> for the destination tenant');
  for (const origin of selectedOrigins) for (const file of manifest.files.filter(f => f.path.startsWith('assets/'))) {
    const url = new URL(file.path.slice(7), manifest.environment.cdnRoot); let row = { origin, url: url.href, ok: false };
    try {
      const response = await fetch(url, { headers: { Referer: origin + '/' }, redirect: 'error', signal: AbortSignal.timeout(20000) });
      const type = response.headers.get('content-type') || '', bytes = Buffer.from(await response.arrayBuffer());
      const ext = path.extname(file.path).toLowerCase(); const mime = { '.js': /(?:java|ecma)script/i, '.css': /^text\/css/i, '.json': /json/i, '.woff': /font|woff|octet-stream/i, '.woff2': /font|woff|octet-stream/i, '.png': /^image\/png/i, '.svg': /^image\/svg\+xml/i, '.jpg': /^image\/jpeg/i, '.txt': /^text\/plain/i }[ext];
      row = { ...row, status: response.status, contentType: type, sha256: sha(bytes), ok: response.status === 200 && sha(bytes) === file.sha256 && Boolean(mime?.test(type)) };
    } catch (error) { row.error = error.message; }
    results.push(row);
  }
  const report = { checkedAt: new Date().toISOString(), buildId: manifest.buildId, manifestSha256: sha(fs.readFileSync(path.join(build, 'release-manifest.json'))), ok: results.length > 0 && results.every(r => r.ok), results };
  const file = inside(root, 'releases/evidence/' + manifest.buildId + '/' + Date.now() + '-cdn.json'); writeJson(file, report);
  console.log((report.ok ? 'Live CDN bytes verified; tenant smoke test still required. ' : 'DO NOT INSTALL: live CDN verification failed. ') + file);
  assert(report.ok, 'Live CDN verification failed');
}

async function main(args) {
  const [action, ...rest] = args; const options = {};
  for (let i = 0; i < rest.length; i++) {
    if (rest[i] === '--allow-dirty' && !options.allowDirty) options.allowDirty = true;
    else if (rest[i] === '--origin' && rest[i + 1]) (options.origins ||= []).push(rest[++i]);
    else if (['--profile', '--build'].includes(rest[i]) && rest[i + 1] && !rest[i + 1].startsWith('--') && !options[rest[i].slice(2)]) options[rest[i].slice(2)] = rest[++i];
    else throw new Error('Unexpected/duplicate option: ' + rest[i]);
  }
  if (action === 'verify') { assert(!options.profile && !options.allowDirty, 'Verification uses the retained build profile'); return verifyLive(process.cwd(), options.build, options.origins); }
  assert(!options.build && !options.origins, '--build and --origin are for verification only');
  return deliver(process.cwd(), action, options);
}

module.exports = { inside, projectPath, stageDependencies, loadConfig, applyProfile, collectAssets, inspectPackage, verifyBuild, publish, acquireLock, deliver, main };
