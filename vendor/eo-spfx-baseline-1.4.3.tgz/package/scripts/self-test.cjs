'use strict';

// Guards the property that actually matters for preflight: it must fail CLOSED.
// A zip reader that silently stops parsing would make every package look clean, which is
// the one bug that would let a broken .sppkg reach production wearing a green check.

const fs = require('fs');
const path = require('path');
const { preflight } = require('./preflight.cjs');

let failures = 0;
function check(name, cond) {
  process.stdout.write(`${cond ? 'ok  ' : 'FAIL'}  ${name}\n`);
  if (!cond) failures++;
}

// --- fails closed on unusable input -----------------------------------------
const tmp = path.join(require('os').tmpdir(), `eo-preflight-${process.pid}`);
fs.mkdirSync(tmp, { recursive: true });

check('missing file is not OK', preflight(path.join(tmp, 'nope.sppkg')).ok === false);

const garbage = path.join(tmp, 'garbage.sppkg');
fs.writeFileSync(garbage, Buffer.from('this is not a zip archive at all'));
check('non-zip input is not OK', preflight(garbage).ok === false);

const emptyZip = path.join(tmp, 'empty.sppkg');
// A valid but empty zip: end-of-central-directory record only.
fs.writeFileSync(emptyZip, Buffer.from('504b0506000000000000000000000000000000000000', 'hex'));
const emptyResult = preflight(emptyZip);
check('zip with no manifests is not OK', emptyResult.ok === false);
check('  ...and says why', emptyResult.report.some((l) => /no XML manifests/.test(l)));

if (!path.resolve(tmp).startsWith(path.resolve(require('os').tmpdir(), 'eo-preflight-'))) {
  throw new Error('refusing to clean outside the test temporary directory');
}
fs.rmSync(tmp, { recursive: true, force: true });

// --- real packages, when this is checked out beside the projects -------------
const workspace = path.resolve(__dirname, '..', '..');
const dev = path.join(workspace, 'org-chart-spfx', 'artifacts', '1.5.0', 'org-chart-spfx-1.5.0-DEV.sppkg');
const prod = path.join(workspace, 'better-list-spfx', 'cdn-handoff', 'better-list-spfx-0.1.11.sppkg');

if (fs.existsSync(dev)) {
  const r = preflight(dev);
  check('dev package is rejected', r.ok === false);
  check('  ...for the asset-library token', r.report.some((l) => /SPCLIENTSIDEASSETLIBRARY/i.test(l)));
} else {
  process.stdout.write('skip  dev-package case (sibling project not present)\n');
}

if (fs.existsSync(prod)) {
  const r = preflight(prod);
  check('CDN package is accepted', r.ok === true);
  check('  ...and resolves a clean CDN url', r.report.some((l) => /irm\.azureedge\.us\/M\/[\w-]+\/$/.test(l.trim())));
} else {
  process.stdout.write('skip  cdn-package case (sibling project not present)\n');
}

process.stdout.write(`\n${failures === 0 ? 'all checks passed' : `${failures} check(s) failed`}\n`);
process.exitCode = failures === 0 ? 0 : 1;
