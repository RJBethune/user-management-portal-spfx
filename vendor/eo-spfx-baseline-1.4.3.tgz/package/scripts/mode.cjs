'use strict';

// eo-spfx mode dev|prod — flip a project between the dev/test and production asset routes.
//
// This was a hand-edit of two JSON files, which is where production mistakes come from:
// task-tracker-spfx sat on a literal "https://<CDN-HOST>/M/..." placeholder that would have
// produced a package whose assets 404. Making it a command means the CDN path is derived,
// not typed, and prod mode refuses to proceed if it cannot be.
//
//   dev  : includeClientSideAssets = true   (assets embedded; workbench + policy-exempt sites)
//   prod : includeClientSideAssets = false  + cdnBasePath = <CDN>/M/<repo-folder>/

const fs = require('fs');
const path = require('path');

const toolchain = require(path.join(__dirname, '..', 'contracts', 'toolchain.json'));

function readJson(f) {
  return JSON.parse(fs.readFileSync(f, 'utf8'));
}

// Write back preserving 2-space formatting; these files are code-reviewed.
function writeJson(f, obj) {
  fs.writeFileSync(f, JSON.stringify(obj, null, 2) + '\n');
}

// The CDN folder is named after the REPO, which is not always the solution folder
// (intake-front-door-spfx contains gso-front-door/). Walk up to the git root.
function repoFolderName(startDir) {
  let dir = path.resolve(startDir);
  for (;;) {
    if (fs.existsSync(path.join(dir, '.git'))) return path.basename(dir);
    const parent = path.dirname(dir);
    if (parent === dir) return null;
    dir = parent;
  }
}

function setMode(projectDir, mode) {
  const report = [];
  const solutionPath = path.join(projectDir, 'config', 'package-solution.json');
  const manifestPath = path.join(projectDir, 'config', 'write-manifests.json');

  if (!fs.existsSync(solutionPath)) {
    return { ok: false, report: [`  x no config/package-solution.json under ${projectDir}`] };
  }

  const solution = readJson(solutionPath);
  const isProd = mode === 'prod';
  solution.solution.includeClientSideAssets = !isProd;
  writeJson(solutionPath, solution);
  report.push(`  . includeClientSideAssets = ${!isProd}`);

  if (isProd) {
    const repo = repoFolderName(projectDir);
    if (!repo) {
      return {
        ok: false,
        report: [...report, '  x cannot determine the repo folder name (no .git found) — ' +
                            'refusing to guess the CDN path'],
      };
    }
    const expected = `${toolchain.cdn.baseUrl}${repo}/`;
    const manifest = fs.existsSync(manifestPath) ? readJson(manifestPath) : {
      $schema: 'https://developer.microsoft.com/json-schemas/spfx-build/write-manifests.schema.json',
    };
    const before = manifest.cdnBasePath;
    if (before !== expected) {
      manifest.cdnBasePath = expected;
      writeJson(manifestPath, manifest);
      report.push(`  . cdnBasePath ${before ? `${before} ->` : '='} ${expected}`);
    } else {
      report.push(`  . cdnBasePath = ${expected}`);
    }
    report.push('  ! CDN files must be confirmed live BEFORE the .sppkg reaches the App Catalog');
  }

  return { ok: true, report };
}

module.exports = { setMode, repoFolderName };
