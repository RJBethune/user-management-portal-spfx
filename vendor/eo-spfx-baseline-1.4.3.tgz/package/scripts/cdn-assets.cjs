'use strict';

const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const acorn = require('acorn');
const { preflight, readZipEntries } = require('./preflight.cjs');
const toolchain = require('../contracts/toolchain.json');

const sha256 = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const isFunction = node => /^(FunctionExpression|FunctionDeclaration|ArrowFunctionExpression)$/.test(node.type);
const property = node => node && (node.computed ? node.property.value : node.property.name);

function walk(node, visit, skipFunctions = false, root = node) {
  if (!node || typeof node.type !== 'string') return;
  if (skipFunctions && node !== root && isFunction(node)) return;
  visit(node);
  for (const value of Object.values(node)) {
    if (Array.isArray(value)) value.forEach(child => walk(child, visit, skipFunctions, root));
    else if (value && typeof value.type === 'string') walk(value, visit, skipFunctions, root);
  }
}

// Inspect emitted code, rather than trusting a source config which another plugin
// could override. Only inspect attributes in functions that create script tags;
// unrelated image crossorigin attributes are not chunk loader settings.
function inspectJavaScript(code) {
  const ast = acorn.parse(code, { ecmaVersion: 'latest', sourceType: 'script' });
  const problems = [];
  const chunks = new Set();
  const references = [];
  const registeredIds = new Set();
  const namespaces = new Set();
  walk(ast, node => {
    if (node.type === 'MemberExpression' && node.object.type === 'Identifier' &&
        ['self', 'window', 'globalThis'].includes(node.object.name) && /^webpack(?:Jsonp|Chunk)/.test(property(node) || '')) {
      namespaces.add(property(node));
    }
    if (node.type === 'CallExpression' && node.callee.type === 'MemberExpression' && property(node.callee) === 'push') {
      const ids = node.arguments[0]?.type === 'ArrayExpression' && node.arguments[0].elements[0];
      if (ids?.type === 'ArrayExpression') {
        for (const id of ids.elements) if (id?.type === 'Literal') registeredIds.add(String(id.value));
      }
    }
    if (isFunction(node)) {
      let createsScript = false;
      let cors = false;
      let moduleScript = false;
      walk(node, item => {
        if (item.type === 'CallExpression' && item.callee.type === 'MemberExpression') {
          const name = property(item.callee);
          if (name === 'createElement' && item.arguments[0]?.value === 'script') createsScript = true;
          if (name === 'setAttribute' && String(item.arguments[0]?.value).toLowerCase() === 'crossorigin') cors = true;
          if (name === 'setAttribute' && item.arguments[0]?.value === 'type' && item.arguments[1]?.value === 'module') moduleScript = true;
        }
        if (item.type === 'AssignmentExpression' && item.left.type === 'MemberExpression') {
          if (property(item.left) === 'crossOrigin') cors = true;
          if (property(item.left) === 'type' && item.right.value === 'module') moduleScript = true;
        }
      }, true);
      if (createsScript && cors) problems.push('script loader sets crossorigin; the managed CDN requires classic script loading');
      if (createsScript && moduleScript) problems.push('module script loader requires CORS; expected classic JSONP chunks');
    }

    // Webpack 5's chunk filename resolver is a pure function assigned to .u.
    // Collect every ID in its lookup tables, then resolve filenames in an isolated
    // context without host objects, I/O, timers or runtime dependencies.
    if (node.type !== 'AssignmentExpression' || node.left.type !== 'MemberExpression' ||
        property(node.left) !== 'u' || !isFunction(node.right)) return;
    const source = code.slice(node.right.start, node.right.end);
    if (!source.includes('.js')) return;
    const ids = new Set();
    walk(node.right, item => {
      if (item.type === 'Property' && !item.computed) {
        const key = item.key.value ?? item.key.name;
        if (key !== undefined) ids.add(key);
      }
      if (item.type === 'BinaryExpression' && ['===', '=='].includes(item.operator)) {
        for (const side of [item.left, item.right]) if (side.type === 'Literal') ids.add(side.value);
      }
    });
    // A runtime with one lazy chunk can return a literal filename without a
    // lookup table. Keep the ID/namespace checks by reading that runtime's
    // static ensure-chunk calls; never invent an ID or accept a dynamic call.
    const body = node.right.body;
    const returned = body.type === 'BlockStatement'
      ? (body.body.length === 1 && body.body[0].type === 'ReturnStatement' ? body.body[0].argument : null)
      : body;
    if (!ids.size && returned?.type === 'Literal' && typeof returned.value === 'string' &&
        returned.value.endsWith('.js') && node.left.object.type === 'Identifier') {
      const runtime = node.left.object.name;
      let dynamic = false;
      walk(ast, call => {
        if (call.type !== 'CallExpression' || call.callee.type !== 'MemberExpression' ||
            property(call.callee) !== 'e' || call.callee.object.type !== 'Identifier' ||
            call.callee.object.name !== runtime) return;
        const id = call.arguments[0];
        if (call.arguments.length !== 1 || id?.type !== 'Literal' ||
            !['string', 'number'].includes(typeof id.value)) dynamic = true;
        else ids.add(id.value);
      });
      if (dynamic) {
        problems.push('cannot enumerate dynamic chunk request for a constant filename resolver');
        return;
      }
    }
    if (!ids.size) {
      problems.push('cannot enumerate chunk filename resolver; review this webpack output before release');
      return;
    }
    for (const id of ids) {
      try {
        const filename = vm.runInNewContext(`(${source})(id)`, { id },
          { timeout: 100, contextCodeGeneration: { strings: false, wasm: false } });
        if (typeof filename !== 'string' || !filename.endsWith('.js') || filename.includes('undefined')) {
          throw new Error('resolver returned an invalid filename');
        }
        chunks.add(filename);
        references.push({ file: filename, id: String(id) });
      } catch (error) {
        problems.push(`cannot resolve chunk ${id}: ${error.message}`);
      }
    }
  });
  return { problems: [...new Set(problems)], chunks: [...chunks], references,
    registeredIds: [...registeredIds], namespaces: [...namespaces] };
}

function inspectRelease(sppkgPath, assetsDir, options = {}) {
  const base = preflight(sppkgPath, options);
  const report = base.report.filter(line => !line.startsWith('RESULT:'));
  const result = { ok: base.ok, report, assets: [], baseUrls: [] };
  const fail = message => { result.ok = false; report.push(`  x ${message}`); };
  if (!base.ok) return result;
  try {
    if (!assetsDir || !fs.statSync(assetsDir).isDirectory()) throw new Error('asset directory is required');
    const entries = readZipEntries(fs.readFileSync(sppkgPath), name => /\.xml$/i.test(name));
    const xml = entries.map(entry => entry.content.replace(/&quot;/g, '"').replace(/&amp;/g, '&')).join('\n');
    const required = new Set();
    for (const match of xml.matchAll(/"path"\s*:\s*"([^"\r\n]+\.js)"/g)) required.add(match[1]);
    for (const match of xml.matchAll(/internalModuleBaseUrls[^\]]*\]/g)) {
      for (const url of match[0].matchAll(/https?:\/\/[^"'<\s\]]+/g)) result.baseUrls.push(url[0]);
    }
    result.baseUrls = [...new Set(result.baseUrls)];
    if (!required.size) throw new Error('no JavaScript entry bundles found in package manifests');
    if (result.baseUrls.length !== 1) throw new Error('expected one CDN base URL for the release asset directory');
    const names = fs.readdirSync(assetsDir).filter(file => /\.(js|json|txt)$/i.test(file));
    const files = new Set(names);
    const inspected = new Map();
    let javascript = 0;
    for (const file of names) {
      const absolute = path.join(assetsDir, file);
      if (!fs.lstatSync(absolute).isFile()) { fail(`asset is not a regular file: ${file}`); continue; }
      const bytes = fs.readFileSync(absolute);
      result.assets.push({ file, bytes: bytes.length, sha256: sha256(bytes), path: absolute });
      if (!file.endsWith('.js')) continue;
      javascript++;
      try {
        const checked = inspectJavaScript(bytes.toString('utf8'));
        inspected.set(file, checked);
        checked.problems.forEach(problem => fail(`${file}: ${problem}`));
        checked.chunks.forEach(chunk => required.add(chunk));
      } catch (error) { fail(`${file}: JavaScript cannot be parsed: ${error.message}`); }
    }
    for (const file of required) {
      if (path.basename(file) !== file || !files.has(file)) fail(`missing referenced bundle/chunk: ${file}`);
    }
    for (const [source, checked] of inspected) {
      for (const reference of checked.references) {
        const chunk = inspected.get(reference.file);
        if (!chunk) continue; // Missing or unparsable files already fail above.
        if (!chunk.registeredIds.includes(reference.id)) fail(`${reference.file}: does not register expected chunk ${reference.id}`);
        if (!checked.namespaces.some(name => chunk.namespaces.includes(name))) {
          fail(`${reference.file}: webpack namespace differs from ${source}; mixed release files`);
        }
      }
    }
    if (!javascript) fail('no JavaScript assets found');
    report.push(`  . inspected ${javascript} JavaScript files and ${required.size} package/chunk references`);
  } catch (error) { fail(error.message); }
  report.push(result.ok
    ? 'RESULT: package and local assets passed; verify the live CDN before the App Catalog update'
    : 'RESULT: DO NOT DEPLOY — package/assets failed production checks');
  return result;
}

async function verifyCdn(sppkgPath, assetsDir, options = {}) {
  const local = inspectRelease(sppkgPath, assetsDir);
  const report = [...local.report];
  const results = [];
  if (!local.ok) return { ok: false, report, results };
  const origins = options.origins?.length ? options.origins : toolchain.cdn.sharePointOrigins;
  for (const origin of origins) {
    const parsed = new URL(origin);
    if (parsed.origin !== origin || parsed.protocol !== 'https:') throw new Error(`expected an HTTPS origin, got ${origin}`);
  }
  const request = options.fetch || fetch;
  const jobs = local.assets.flatMap(asset => origins.map(origin => ({ asset, origin })));
  let cursor = 0;
  await Promise.all(Array.from({ length: Math.min(4, jobs.length) }, async () => {
    while (cursor < jobs.length) {
      const { asset, origin } = jobs[cursor++];
      const row = { file: asset.file, origin, ok: false };
      try {
        // Classic cross-origin scripts send a referrer, but no Origin header.
        const response = await request(new URL(asset.file, local.baseUrls[0]), {
          headers: { Referer: origin + '/' }, redirect: 'error', signal: AbortSignal.timeout(20000)
        });
        row.status = response.status;
        row.contentType = response.headers.get('content-type');
        row.sha256 = sha256(Buffer.from(await response.arrayBuffer()));
        row.ok = row.status === 200 && row.sha256 === asset.sha256 &&
          (!asset.file.endsWith('.js') || /^(application|text)\/(x-)?(java|ecma)script\b/i.test(row.contentType || ''));
        if (!row.ok) row.error = 'status, JavaScript content type, or exact SHA-256 does not match the release';
      } catch (error) { row.error = error.message; }
      results.push(row);
    }
  }));
  const ok = results.length > 0 && results.every(row => row.ok);
  for (const row of results.filter(item => !item.ok)) report.push(`  x ${row.origin} ${row.file}: ${row.error}`);
  report.push(`RESULT: ${ok ? 'live CDN assets verified; complete the tenant smoke test after installation' : 'DO NOT UPDATE THE APP CATALOG — live CDN verification failed'}`);
  return { ok, checkedAt: new Date().toISOString(), report, results };
}

module.exports = { inspectJavaScript, inspectRelease, verifyCdn };
