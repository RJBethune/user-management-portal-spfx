'use strict';

// Audits every SPFx project in the workspace against the contracts in ../contracts.
// Read-only: reports drift, never fixes it. Exit 1 if any BLOCK-level finding exists.
//
//   node scripts/audit.cjs            # audit all sibling *-spfx projects
//   node scripts/audit.cjs ../foo     # audit specific project(s)
//   node scripts/audit.cjs --json     # machine-readable

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const WORKSPACE = path.resolve(ROOT, '..');
const uiContract = require(path.join(ROOT, 'contracts', 'ui-runtime.json'));
const toolchain = require(path.join(ROOT, 'contracts', 'toolchain.json'));

const BLOCK = 'BLOCK';
const WARN = 'WARN';

function readJson(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return null;
  }
}

// A folder counts as a project if it holds a solution at the root OR one level down
// (the nested-solution layout intake-front-door-spfx still uses).
function isProject(dir) {
  if (fs.existsSync(path.join(dir, 'package.json'))) return true;
  if (fs.existsSync(path.join(dir, 'config', 'package-solution.json'))) return true;
  let children;
  try {
    children = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return false;
  }
  return children.some((e) =>
    e.isDirectory() &&
    !e.name.startsWith('.') &&
    fs.existsSync(path.join(dir, e.name, 'config', 'package-solution.json')));
}

// A project is a REPO, not necessarily the directory holding the solution. Running
// `eo-spfx audit .` from inside a nested solution (intake-front-door-spfx/gso-front-door)
// must audit the repo, or it reports a missing .git and a missing CLAUDE.md that do exist
// one level up.
function toRepoRoot(dir) {
  let cur = path.resolve(dir);
  for (;;) {
    if (fs.existsSync(path.join(cur, '.git'))) return cur;
    const parent = path.dirname(cur);
    if (parent === cur) return path.resolve(dir);
    cur = parent;
  }
}

function discoverProjects(args) {
  const explicit = args.filter((a) => !a.startsWith('--'));
  if (explicit.length) return explicit.map((p) => toRepoRoot(p));
  return fs
    .readdirSync(WORKSPACE, { withFileTypes: true })
    .filter((e) => e.isDirectory() && e.name.endsWith('-spfx'))
    .map((e) => path.join(WORKSPACE, e.name))
    .filter(isProject);
}

// A project's real build lane is not always what its root package.json says: a project
// may keep a vestigial legacy manifest at the root while building through a staged
// toolchain (task-tracker-spfx does exactly this). Prefer the toolchain manifest.
function resolveManifest(projectDir) {
  const rootPkg = readJson(path.join(projectDir, 'package.json'));

  // If the root manifest declares a build lane, it IS the solution. Only fall back to a
  // toolchains/ overlay when it does not — that shape existed because task-tracker-spfx
  // staged its build elsewhere, and preferring toolchains/ unconditionally kept reporting
  // the stale overlay after that project was flattened.
  if (rootPkg && detectLane({ ...rootPkg.dependencies, ...rootPkg.devDependencies }).lane !== 'unknown') {
    return { pkg: rootPkg, source: 'package.json', rootPkg, staged: false };
  }

  const toolchainDir = path.join(projectDir, 'toolchains');
  if (fs.existsSync(toolchainDir)) {
    for (const entry of fs.readdirSync(toolchainDir)) {
      const candidate = path.join(toolchainDir, entry, 'package.json');
      const pkg = readJson(candidate);
      if (pkg) return { pkg, source: path.relative(projectDir, candidate), rootPkg, staged: true };
    }
  }
  // Nested-solution layout (intake-front-door-spfx keeps its solution under a child folder).
  if (!rootPkg) {
    for (const entry of fs.readdirSync(projectDir, { withFileTypes: true })) {
      if (!entry.isDirectory() || entry.name.startsWith('.')) continue;
      const candidate = path.join(projectDir, entry.name, 'package.json');
      const pkg = readJson(candidate);
      if (pkg && fs.existsSync(path.join(projectDir, entry.name, 'config', 'package-solution.json'))) {
        return { pkg, source: path.relative(projectDir, candidate), rootPkg: null, nested: entry.name };
      }
    }
  }
  return { pkg: rootPkg, source: 'package.json', rootPkg, staged: false };
}

function detectLane(deps) {
  const spfx = deps['@microsoft/sp-core-library'];
  if (deps['@rushstack/heft']) return { lane: 'heft', spfx };
  if (deps.gulp || deps['@microsoft/sp-build-web']) return { lane: 'gulp', spfx };
  return { lane: 'unknown', spfx };
}

function auditProject(projectDir) {
  const name = path.basename(projectDir);
  const findings = [];
  const add = (level, rule, detail) => findings.push({ level, rule, detail });

  const { pkg, source, rootPkg, staged, nested } = resolveManifest(projectDir);
  if (!pkg) {
    add(BLOCK, 'manifest', 'no package.json found');
    return { name, findings, lane: 'unknown' };
  }

  const deps = { ...pkg.dependencies, ...pkg.devDependencies };
  const { lane, spfx } = detectLane(deps);
  const expected = toolchain.lanes[lane];

  // --- structure -----------------------------------------------------------
  if (nested) {
    add(WARN, 'structure', `solution nested under ${nested}/ instead of the repo root (SPFX-ARCHITECTURE §1)`);
  }
  if (fs.existsSync(path.join(projectDir, 'packages'))) {
    add(BLOCK, 'structure', 'top-level packages/ workspace is banned (SPFX-ARCHITECTURE §3)');
  }
  if (!fs.existsSync(path.join(projectDir, '.git'))) {
    add(BLOCK, 'vcs', 'not under version control');
  }
  if (!['AGENTS.md', 'CLAUDE.md'].some(file => fs.existsSync(path.join(projectDir, file)))) {
    add(WARN, 'docs', 'no AGENTS.md or CLAUDE.md project guidance');
  }
  if (staged && rootPkg) {
    const rootLane = detectLane({ ...rootPkg.dependencies, ...rootPkg.devDependencies });
    if (rootLane.lane !== lane) {
      add(WARN, 'manifest',
        `root package.json advertises the ${rootLane.lane} lane (SPFx ${rootLane.spfx}) but the ` +
        `real build uses ${source} (${lane}, SPFx ${spfx}) — the root manifest misreports the toolchain`);
    }
  }

  // --- toolchain -----------------------------------------------------------
  if (lane === 'unknown') {
    add(WARN, 'toolchain', 'could not determine build lane');
  } else {
    if (expected.deprecated) {
      add(WARN, 'toolchain', `on the deprecated ${lane} lane (SPFx ${spfx}) — migrate on next feature touch`);
    }
    if (spfx && expected.spfx && spfx !== expected.spfx) {
      add(WARN, 'toolchain', `SPFx ${spfx}, lane expects ${expected.spfx}`);
    }
    // Heft is a build tool, not a shipped runtime dependency — a patch-level difference
    // does not threaten the Tabster contract, so this warns rather than blocks.
    if (lane === 'heft' && deps['@rushstack/heft'] !== expected.heft) {
      add(WARN, 'toolchain', `Heft ${deps['@rushstack/heft']}, contract pins ${expected.heft}`);
    }
    if (expected.typescript && deps.typescript && deps.typescript !== expected.typescript) {
      add(WARN, 'toolchain', `TypeScript ${deps.typescript}, lane expects ${expected.typescript}`);
    }
  }
  if (pkg.engines && pkg.engines.node !== toolchain.lanes.heft.node) {
    add(WARN, 'toolchain', `node engine ${pkg.engines.node}, expected ${toolchain.lanes.heft.node}`);
  }

  // --- Fluent / Tabster contract ------------------------------------------
  const usesFluent9 = Boolean(deps['@fluentui/react-components']);
  if (usesFluent9) {
    for (const [dep, want] of Object.entries(uiContract.directDependencies)) {
      const got = deps[dep];
      if (got === undefined) {
        add(BLOCK, 'ui-contract', `uses Fluent v9 but does not pin ${dep} (contract: ${want})`);
      } else if (got !== want) {
        add(BLOCK, 'ui-contract', `${dep} is ${got}, contract requires exactly ${want}`);
      }
    }
    const overrides = pkg.overrides || {};
    const missing = Object.keys(uiContract.overrides).filter((k) => overrides[k] !== uiContract.overrides[k]);
    if (missing.length) {
      add(BLOCK, 'ui-contract',
        `${missing.length}/${Object.keys(uiContract.overrides).length} contract overrides missing or wrong ` +
        `(e.g. ${missing.slice(0, 3).join(', ')}) — partial pinning does not hold the closure`);
    }
  }
  if (deps['@fluentui/react'] && usesFluent9) {
    add(WARN, 'ui-contract', 'Fluent 8 and 9 both present — mid-migration');
  } else if (deps['@fluentui/react']) {
    add(WARN, 'ui-contract', `Fluent 8 only (${deps['@fluentui/react']}) — v9 is the standard`);
  }

  // --- lockfile ------------------------------------------------------------
  // The lockfile sits beside its manifest, which is not always the project root
  // (staged toolchain, or a nested solution).
  const lockDir = path.dirname(path.join(projectDir, source));
  if (!fs.existsSync(path.join(lockDir, 'package-lock.json'))) {
    add(BLOCK, 'lockfile', 'no package-lock.json committed');
  }

  // --- command surface -----------------------------------------------------
  const scripts = pkg.scripts || {};
  const rootScripts = (rootPkg && rootPkg.scripts) || {};
  for (const verb of ['dev', 'check', 'build', 'ship', 'release']) {
    if (!scripts[verb] && !rootScripts[verb]) {
      add(WARN, 'commands', `missing "${verb}" script`);
    }
  }

  // Inspect the command users and CI actually run. A package-only preflight cannot
  // detect a lazy chunk requesting CORS from a CDN that does not return CORS headers.
  const expand = (command, seen = new Set()) => String(command || '').replace(
    /npm run ([\w:.-]+)/g, (match, verb) => {
      if (seen.has(verb)) return match;
      return expand(scripts[verb] || rootScripts[verb], new Set([...seen, verb]));
    });
  if (toolchain.cdn.requireAssetPreflight && lane !== 'unknown') {
    const release = expand(scripts.release || rootScripts.release);
    const delivery = readJson(path.join(projectDir, 'delivery', 'app.json'));
    const guardedDelivery = /^eo-spfx deliver prod(?: --profile [a-z0-9-]+)?$/.test(release.trim()) && delivery?.schemaVersion === 1;
    if (!guardedDelivery && !/eo-spfx\s+preflight\b[^&;|\n]*--assets\s+\S+/.test(release)) {
      add(BLOCK, 'cdn-assets', 'release must run eo-spfx preflight <sppkg> --assets <emitted-assets-directory>');
    }
  }

  return { name, findings, lane, spfx, manifest: source };
}

function main() {
  const args = process.argv.slice(2);
  const asJson = args.includes('--json');
  const results = discoverProjects(args).map(auditProject);

  if (asJson) {
    process.stdout.write(JSON.stringify({ results }, null, 2) + '\n');
  } else {
    for (const r of results) {
      const blocks = r.findings.filter((f) => f.level === BLOCK);
      const warns = r.findings.filter((f) => f.level === WARN);
      const status = blocks.length ? 'FAIL' : warns.length ? 'WARN' : 'OK';
      process.stdout.write(`\n${status.padEnd(4)}  ${r.name}  [${r.lane} lane${r.spfx ? `, SPFx ${r.spfx}` : ''}]\n`);
      if (r.manifest && r.manifest !== 'package.json') {
        process.stdout.write(`        manifest: ${r.manifest}\n`);
      }
      for (const f of [...blocks, ...warns]) {
        process.stdout.write(`        ${f.level === BLOCK ? 'x' : '-'} ${f.rule}: ${f.detail}\n`);
      }
    }
    const totalBlocks = results.reduce((n, r) => n + r.findings.filter((f) => f.level === BLOCK).length, 0);
    const totalWarns = results.reduce((n, r) => n + r.findings.filter((f) => f.level === WARN).length, 0);
    process.stdout.write(`\n${results.length} projects, ${totalBlocks} blocking, ${totalWarns} warnings\n`);
  }

  const hasBlock = results.some((r) => r.findings.some((f) => f.level === BLOCK));
  process.exitCode = hasBlock ? 1 : 0;
}

main();
