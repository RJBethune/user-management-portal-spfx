'use strict';

// Production guardrail: inspect a built .sppkg WITHOUT deploying it.
//
// The tenant's block-download policy 302-redirects ClientSideAssets requests to an HTML
// policy page, so a production package must point every module at the Azure CDN. A package
// still carrying localhost / REPLACE-WITH / SPCLIENTSIDEASSETLIBRARY will fail at runtime
// with a RequireJS scripterror that is painful to diagnose after the fact.
//
// Implemented with Node's built-in zlib so it runs unchanged on Windows dev boxes and on
// Linux CI runners — no unzip binary, no npm dependency.

const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const toolchain = require(path.join(__dirname, '..', 'contracts', 'toolchain.json'));

const EOCD_SIG = 0x06054b50;
const CD_SIG = 0x02014b50;

// Minimal zip reader: walk the central directory, inflate the entries we care about.
function readZipEntries(buf, nameFilter, { binary = false } = {}) {
  let eocd = -1;
  for (let i = buf.length - 22; i >= 0 && i > buf.length - 22 - 65536; i--) {
    if (buf.readUInt32LE(i) === EOCD_SIG) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('not a zip archive (no end-of-central-directory record)');

  const count = buf.readUInt16LE(eocd + 10);
  let ptr = buf.readUInt32LE(eocd + 16);
  const entries = [];

  for (let n = 0; n < count; n++) {
    if (ptr + 46 > buf.length || buf.readUInt32LE(ptr) !== CD_SIG) throw new Error('invalid zip central directory');
    const method = buf.readUInt16LE(ptr + 10);
    const compSize = buf.readUInt32LE(ptr + 20);
    const nameLen = buf.readUInt16LE(ptr + 28);
    const extraLen = buf.readUInt16LE(ptr + 30);
    const commentLen = buf.readUInt16LE(ptr + 32);
    const localOff = buf.readUInt32LE(ptr + 42);
    const name = buf.toString('utf8', ptr + 46, ptr + 46 + nameLen);
    if (ptr + 46 + nameLen + extraLen + commentLen > buf.length) throw new Error('truncated zip directory entry');

    if (nameFilter(name)) {
      // Local header: name and extra lengths differ from the central directory's.
      if (localOff + 30 > buf.length || buf.readUInt32LE(localOff) !== 0x04034b50) throw new Error('invalid zip local header');
      const lNameLen = buf.readUInt16LE(localOff + 26);
      const lExtraLen = buf.readUInt16LE(localOff + 28);
      const dataStart = localOff + 30 + lNameLen + lExtraLen;
      if (dataStart + compSize > buf.length) throw new Error('truncated zip entry');
      const raw = buf.subarray(dataStart, dataStart + compSize);
      if (method !== 0 && method !== 8) throw new Error(`unsupported zip compression method ${method}`);
      const content = method === 0 ? raw : zlib.inflateRawSync(raw);
      entries.push({ name, content: binary ? content : content.toString('utf8') });
    }
    ptr += 46 + nameLen + extraLen + commentLen;
  }
  return entries;
}

function preflight(sppkgPath, options = {}) {
  const report = [];
  let ok = true;
  const fail = (m) => { ok = false; report.push(`  x ${m}`); };
  const pass = (m) => report.push(`  . ${m}`);

  report.push(`preflight: ${path.basename(sppkgPath)}`);

  if (!fs.existsSync(sppkgPath)) {
    return { ok: false, report: [...report, `  x file not found: ${sppkgPath}`] };
  }

  let entries;
  try {
    entries = readZipEntries(fs.readFileSync(sppkgPath), (n) => /\.xml$/i.test(n));
  } catch (e) {
    return { ok: false, report: [...report, `  x could not read package: ${e.message}`] };
  }
  if (!entries.length) {
    return { ok: false, report: [...report, '  x no XML manifests found inside the package'] };
  }
  pass(`${entries.length} manifest(s) inspected`);

  // 1. Forbidden tokens anywhere in the manifests.
  for (const token of toolchain.forbiddenInManifest) {
    const hits = entries.filter((e) => e.content.toLowerCase().includes(token.toLowerCase()));
    if (hits.length) {
      fail(`manifest contains forbidden token "${token}" in: ${hits.map((h) => h.name).join(', ')}`);
    }
  }
  if (ok) pass(`no forbidden tokens (${toolchain.forbiddenInManifest.join(', ')})`);

  // 2. Every internalModuleBaseUrls entry must point at the CDN.
  const urls = new Set();
  for (const e of entries) {
    // Manifests are XML, so the JSON inside arrives entity-encoded; decode before matching
    // or the quote terminator ends up glued to the URL.
    const decoded = e.content.replace(/&quot;/g, '"').replace(/&amp;/g, '&');
    for (const m of decoded.matchAll(/internalModuleBaseUrls[^\]]*\]/g)) {
      for (const u of m[0].matchAll(/https?:\/\/[^"'<\s\]]+/g)) urls.add(u[0]);
    }
  }
  if (urls.size === 0) {
    fail('no internalModuleBaseUrls found — cannot verify a production asset route');
  } else {
    const expected = options.cdnBaseUrl || toolchain.cdn.baseUrl;
    const offCdn = [...urls].filter((u) => options.cdnBaseUrl ? u !== expected : !u.startsWith(expected));
    if (offCdn.length) {
      fail(`module base URL(s) not on the CDN: ${offCdn.join(', ')}`);
    } else {
      pass(`all module base URLs on ${expected}`);
      for (const u of urls) report.push(`      ${u}`);
    }
  }

  report.push(ok
    ? 'RESULT: package manifests passed; use --assets to check JavaScript, then verify-cdn before deployment'
    : 'RESULT: DO NOT DEPLOY — this package would fail on a production site');
  return { ok, report };
}

module.exports = { preflight, readZipEntries };
