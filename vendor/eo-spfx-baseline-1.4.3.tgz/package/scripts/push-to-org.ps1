<#
.SYNOPSIS
  Push every Executive Office repo to a single GitHub org.

.DESCRIPTION
  Nothing here is destructive: it creates remote repos (PRIVATE by default) and pushes.
  It never rewrites history and never deletes a remote.

  For repos that already live somewhere else (pbroom/better-list-spfx, pbroom/spfx-kit,
  AleshireAL/CRCE), this COPIES rather than moves. The original repo on GitHub is never
  touched - it keeps its issues, PRs, and collaborators, and its owner sees no change. The
  full history is pushed to the org copy, and the original is retained locally as 'upstream'
  so you can still `git fetch upstream` and merge their later work.

  What does change is where YOUR local clone pushes by default. After this, your commits go
  to the org copy, not to theirs. If the intent is for a repo to genuinely LEAVE its current
  owner - taking issues, PRs, stars, and redirects with it - that is a GitHub transfer, which
  only the current owner can initiate. This script deliberately does not attempt that.

  Run with -WhatIf first. Requires the GitHub CLI (`gh auth login` already done).

.PARAMETER Org
  The GitHub org (or user) to push to.

.PARAMETER AllBranches
  Also push every other local branch. Off by default: task-tracker-spfx carries divergent
  experiment branches (and a pre-sanitize-backup) that are older than master, and publishing
  them unasked makes the remote confusing. The current branch is always pushed.

.PARAMETER WhatIf
  Print what would happen without touching anything.

.EXAMPLE
  .\push-to-org.ps1 -Org my-org -WhatIf
  .\push-to-org.ps1 -Org my-org
#>
param(
  [Parameter(Mandatory = $true)][string]$Org,
  [switch]$Public,
  [switch]$AllBranches,
  [switch]$WhatIf
)

# Native commands (git, gh) write ordinary status to stderr. Under 'Stop', PowerShell 5.1
# promotes that to a terminating NativeCommandError - which killed this script on the first
# repo that had no origin yet. Check $LASTEXITCODE explicitly instead.
$ErrorActionPreference = 'Continue'
$workspace = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$visibility = if ($Public) { 'public' } else { 'private' }

function Get-RemoteUrl {
  param([string]$Dir, [string]$Name)
  $names = @(git -C $Dir remote)
  if ($names -contains $Name) { return (git -C $Dir remote get-url $Name).Trim() }
  return $null
}

function Test-GhRepo {
  param([string]$Slug)
  gh repo view $Slug --json name *> $null
  return ($LASTEXITCODE -eq 0)
}

# folder name == repo name. Where a repo currently lives under a different name, the
# folder name wins - see SPFX-ARCHITECTURE.md section 8.
$repos = @(
  'better-list-spfx'
  'cost-report-spfx'
  'decision-risk-log'
  'enterprise-relationship-graph'
  'intake-front-door-spfx'
  'org-chart-spfx'
  'spfx-architecture'
  'spfx-baseline'
  'spfx-implementation-docs'
  'spfx-kit'
  'subscription-service-spfx'
  'task-tracker-spfx'
  'user-management-portal-spfx'
  'visitor-tracker-spfx'
)

if (-not (Get-Command gh -ErrorAction SilentlyContinue)) {
  throw "GitHub CLI not found. Install it, then run 'gh auth login'."
}

Write-Host "Target org : $Org  ($visibility repos)" -ForegroundColor Cyan
Write-Host "Workspace  : $workspace`n"

foreach ($name in $repos) {
  $dir = Join-Path $workspace $name
  if (-not (Test-Path (Join-Path $dir '.git'))) {
    Write-Host "skip   $name (not a git repo)" -ForegroundColor DarkGray
    continue
  }

  $branch = (git -C $dir rev-parse --abbrev-ref HEAD).Trim()
  $existing = Get-RemoteUrl -Dir $dir -Name 'origin'
  $target = "https://github.com/$Org/$name.git"

  if ($existing -eq $target) {
    $action = "push (origin already correct)"
  } elseif ($existing) {
    $action = "re-point origin from $existing"
  } else {
    $action = "create repo + add origin"
  }

  if ($WhatIf) {
    Write-Host ("would  {0,-32} {1}  [branch {2}]" -f $name, $action, $branch) -ForegroundColor Yellow
    continue
  }

  Write-Host ("--> {0,-32} {1}" -f $name, $action) -ForegroundColor Green

  # Create the remote repo if it does not exist yet.
  if (-not (Test-GhRepo "$Org/$name")) {
    gh repo create "$Org/$name" --$visibility --disable-wiki | Out-Null
    if ($LASTEXITCODE -ne 0) {
      Write-Warning "could not create $Org/$name - skipping (permission? org not found?)"
      continue
    }
  }

  # This is a COPY, never a move: the original repo on GitHub is never modified, and we keep
  # it as 'upstream' so its future changes can still be fetched and merged. Only our local
  # notion of where 'origin' points changes.
  if ($existing -and $existing -ne $target) {
    if (-not (Get-RemoteUrl -Dir $dir -Name 'upstream')) {
      git -C $dir remote add upstream $existing
    }
    git -C $dir remote set-url origin $target
  } elseif (-not $existing) {
    git -C $dir remote add origin $target
  }

  git -C $dir push -u origin $branch
  if ($LASTEXITCODE -ne 0) { Write-Warning "push failed for $name"; continue }
  if ($AllBranches) { git -C $dir push --all origin }
  git -C $dir push --tags origin
}

Write-Host "`nDone. Verify with: gh repo list $Org --limit 50" -ForegroundColor Cyan
