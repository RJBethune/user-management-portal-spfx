> Delivery pilot 1.2.0 adds `eo-spfx deliver dev|prod` and `eo-spfx deliver verify --build <folder>`. See [migration recipe](MIGRATION-1.2.0.md). No toolchain/UI version change and no tenant allowlist. Earlier mode commands remain for legacy consumers; migrated apps use explicit descriptors and isolated builds.

# @eo/spfx-baseline

Shared build contracts and production checks for Executive Office SPFx projects.
Version 1.1.0 adds the CDN chunk-loading compatibility rule and validates the
JavaScript deployed alongside a SharePoint package.

## Install or upgrade

Use the versioned npm archive attached to the GitHub release. Commit it under the
consuming project's vendor/ directory, install it, and commit package-lock.json:

```bash
npm install --save-dev --save-exact ./vendor/eo-spfx-baseline-1.1.0.tgz
```

The archive avoids a private-repository token during npm ci. Its dependencies come
from npm, and the lockfile records integrity. A Git tag dependency remains an
option for environments that already have private-repository authentication.
Never edit the installed copy in node_modules.

## Adopt the CDN rule

For Heft projects, merge this entry into config/webpack-patch.json, preserving any
existing patches. Keep the CDN patch last:

```json
{
  "patchFiles": ["node_modules/@eo/spfx-baseline/config/webpack-cdn-compat.cjs"]
}
```

The shared patch sets output.crossOriginLoading to false. The EO CDN serves
classic JavaScript without Access-Control-Allow-Origin; the SPFx default
anonymous CORS loader rejects lazy chunks even when the files return HTTP 200.
Classic script loading matches the initial SPFx bundle and preserves CSP, the CDN
path, code splitting, and SharePoint permissions. Cross-origin exception reports
may contain less detail. This setting is for classic JSONP scripts, not ES modules.

For legacy Gulp projects, use the same exported function as the additionalConfiguration
callback in build.configureWebpack.mergeConfig before build.initialize. Consult the
project's existing webpack customization rather than replacing it. The current
chunk filename/registration validation targets webpack 5 JSONP output; legacy
loaders also need a browser smoke test for their dynamic views.

## Production workflow

Use the lane-specific scripts in templates/. Production release scripts must run:

```bash
eo-spfx preflight sharepoint/solution/<solution>.sppkg --assets release/assets
```

Heft emits production JavaScript into release/assets and production manifests into
release/manifests. dist manifests point to localhost and must not be uploaded.
Legacy Gulp generally uses temp/deploy; pass the actual emitted assets directory.

The audit blocks a release script that omits the asset check. Preflight then checks
actual emitted code, so a later webpack plugin cannot silently undo the setting.
It rejects invalid manifests, unparsable scripts, CORS-dependent script loaders,
missing entry bundles/chunks, wrong chunk IDs, and mixed webpack namespaces.
A preflight call without --assets remains a manifest-only diagnostic and says so.

1. Run npm ci, npm run check, and npm run release. The templates validate a PROD
   package and retain its package, assets and manifests together; they do not deploy.
2. Upload the exact matching CDN files first. Preserve filenames and bytes; do not
   normalize line endings, rewrite files, or overwrite older content-hashed files.
3. Check the live CDN before installing the package:

```bash
eo-spfx verify-cdn sharepoint/solution/<solution>.sppkg --assets release/assets --origin https://usdossiolab.sharepoint.com --report cdn-verification.json
```

Repeat --origin for multiple tenants. If omitted, both lab and production origins
from contracts/toolchain.json are checked. The check uses referrer-only requests,
matching the classic script loader. Redirects, HTTP errors, invalid JavaScript
content types and differing SHA-256 hashes fail. No CORS header is required for
this request mode. Text transcoding at upload must be corrected, not ignored.

4. Deploy/update the matching .sppkg, reload the page, and open every lazy view:
   forms/designer, submissions, settings, exports and language views as applicable.
   HTTP checks do not replace an authenticated browser test.

Correcting CDN CORS headers remains an alternative for an older application build.
The baseline's standard build uses classic loading so its chunk requests do not
depend on those headers.

## Commands and files

| Command or file | Purpose |
|---|---|
| eo-spfx audit [project...] | Toolchain, UI contract and production command conformance |
| eo-spfx mode dev or prod | Select embedded test assets or the derived production CDN path |
| eo-spfx preflight package --assets directory | Check the package and generated JavaScript |
| eo-spfx verify-cdn package --assets directory | Verify deployed bytes before App Catalog update |
| contracts/ui-runtime.json | Tenant-tested Fluent/Tabster dependency closure |
| contracts/toolchain.json | Supported toolchain and managed CDN contract |
| config/webpack-cdn-compat.cjs | Reusable webpack compatibility patch |
| templates/ | Heft/Gulp scripts, webpack patch config, CI, and gitignore |
| STANDARD.md | Detailed platform and release standard |

## Maintenance and validation

Run npm ci, npm test, npm audit, and npm pack --dry-run in this repository. Its own
CI tests the baseline package; it does not run consuming-project npm scripts.

The September 16, 2026 review confirmed SPFx 1.23.2 remains current. React 17.0.1
and TypeScript through 5.8 match Microsoft's SPFx compatibility table. The existing
Fluent/Tabster closure and Heft 1.2.19 stay pinned to the tested contract; newer npm
versions are not an automatic compatibility upgrade. CI follows the supported
Node 22 line for maintenance updates; the minimum engine remains 22.14.0.

Changing a platform/UI pin requires a coherent dependency update and a tenant
trial: cold load, refresh, edit remount, warm navigation, Back/Forward and keyboard
focus. Updating this baseline does not silently modify existing consuming projects.
They must install the new version and adopt the patch and release check above.

References: [SPFx compatibility](https://learn.microsoft.com/en-us/sharepoint/dev/spfx/compatibility),
[webpack crossOriginLoading](https://webpack.js.org/configuration/output/#outputcrossoriginloading).