'use strict';

const path = require('node:path');
const {
  UI_PROFILE_STYLE_NAMES,
  resolveUiProfileDeliveryArtifact: resolveArtifact,
  resolveUiProfileStyleSubset: resolveStyleSubset
} = require('./scripts/lib/delivery-artifact.cjs');

function resolveUiProfileDeliveryArtifact(options = {}) {
  return resolveArtifact({ packageRoot: path.resolve(options.packageRoot || __dirname) });
}

function resolveUiProfileStyleSubset(options = {}) {
  return resolveStyleSubset({ packageRoot: path.resolve(options.packageRoot || __dirname), styles: options.styles });
}

module.exports = { UI_PROFILE_STYLE_NAMES, resolveUiProfileDeliveryArtifact, resolveUiProfileStyleSubset };
