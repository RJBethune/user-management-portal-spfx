'use strict';

const path = require('node:path');
const { readFileSync, realpathSync } = require('node:fs');

const { resolveUiProfileDeliveryArtifact, resolveUiProfileStyleSubset } = require('./scripts/lib/delivery-artifact.cjs');
const { normalizeStyleSelection } = require('./scripts/lib/style-fragments.cjs');
const UI_PROFILE_RULE_MARKER = Symbol.for('spfx-kit.ui-profile.global-css-rule');
const UI_PROFILE_ASSET_PLUGIN_MARKER = Symbol.for('spfx-kit.ui-profile.delivery-assets-plugin');
const BASE_UI_MJS_RULE_MARKER = Symbol.for('spfx-kit.ui-profile.base-ui-mjs-rule');
const SHIPPED_STYLES_RULE_MARKER = Symbol.for('spfx-kit.ui-profile.shipped-styles-rule');
const DELIVERY_STYLES_MARKER = Symbol.for('spfx-kit.ui-profile.delivery-styles');
const SHIPPED_STYLES_MODULES = ['dist/src/shipped-styles.js', 'dist/commonjs/src/shipped-styles.js'];

module.exports = function configureSpfxUiProfileCss(webpackConfiguration, options = {}) {
  if (options.cssDelivery !== undefined && !['inline', 'external'].includes(options.cssDelivery)) {
    throw new Error('cssDelivery must be inline or external.');
  }
  // Validate the style selection before touching the configuration so an
  // invalid name fails the build with a clear message.
  const styles = options.styles === undefined ? undefined : normalizeStyleSelection(options.styles);
  const rules = webpackConfiguration && webpackConfiguration.module && webpackConfiguration.module.rules;
  if (!Array.isArray(rules)) {
    throw new Error('SPFx webpack configuration does not expose module.rules.');
  }
  const packageRoot = path.resolve(options.packageRoot || __dirname);
  const artifact = resolveUiProfileDeliveryArtifact({ packageRoot });
  const subset = styles ? resolveUiProfileStyleSubset({ packageRoot, styles }) : null;
  const delivery = subset
    ? { sha256: subset.sha256, bytes: subset.bytes, styles: subset.styles, fragments: subset.fragments }
    : { sha256: artifact.cssSha256, bytes: null, styles: null, fragments: null };
  const deliveryKey = subset ? subset.styles.join(',') : '*';
  const preparedBaseUiRoot = realpathSync(path.join(packageRoot, '.prepared/base-ui'));
  const expectedPreparedParent = `${realpathSync(path.join(packageRoot, '.prepared'))}${path.sep}`;
  if (!preparedBaseUiRoot.startsWith(expectedPreparedParent)) {
    throw new Error('Prepared Base UI compatibility root resolves outside the UI profile package.');
  }
  const preparedManifest = JSON.parse(readFileSync(path.join(preparedBaseUiRoot, 'package.json'), 'utf8'));
  if (preparedManifest.name !== '@base-ui/react' || preparedManifest.version !== '1.6.0') {
    throw new Error('Prepared Base UI compatibility package identity differs.');
  }

  const resolve = webpackConfiguration.resolve || (webpackConfiguration.resolve = {});
  const alias = resolve.alias || (resolve.alias = {});
  if (Array.isArray(alias) || typeof alias !== 'object') {
    throw new Error('SPFx webpack configuration does not expose an object resolve.alias map.');
  }
  const currentBaseUiAlias = alias['@base-ui/react'];
  if (currentBaseUiAlias && path.resolve(currentBaseUiAlias) !== preparedBaseUiRoot) {
    throw new Error('SPFx webpack configuration already aliases @base-ui/react to a different package.');
  }
  alias['@base-ui/react'] = preparedBaseUiRoot;

  const baseUiUtilsManifestPath = require.resolve('@base-ui/utils/package.json', { paths: [packageRoot] });
  const baseUiUtilsRoot = realpathSync(path.dirname(baseUiUtilsManifestPath));
  const baseUiUtilsManifest = JSON.parse(readFileSync(baseUiUtilsManifestPath, 'utf8'));
  if (baseUiUtilsManifest.name !== '@base-ui/utils') {
    throw new Error('Resolved Base UI utilities package identity differs.');
  }
  if (!rules.some((rule) => rule && rule[BASE_UI_MJS_RULE_MARKER] === preparedBaseUiRoot)) {
    rules.push({
      test: /\.mjs$/u,
      include: [preparedBaseUiRoot, baseUiUtilsRoot],
      resolve: { fullySpecified: false },
      [BASE_UI_MJS_RULE_MARKER]: preparedBaseUiRoot
    });
  }

  const exactCssPath = path.normalize(artifact.cssPath);
  const exactCssCondition = (resource) => path.normalize(String(resource || '').split('?', 1)[0]) === exactCssPath;
  exactCssCondition.uiProfileCssPath = exactCssPath;

  const moduleRule = rules.find((rule) => usesSpCssLoader(rule, true));
  const globalRule = rules.find((rule) => usesSpCssLoader(rule, false));
  if (!moduleRule || !globalRule) {
    throw new Error('Could not find the SPFx module and global CSS loader rules.');
  }

  if (!containsUiProfileCondition(moduleRule.exclude, exactCssPath)) {
    moduleRule.exclude = appendCondition(moduleRule.exclude, exactCssCondition);
  }

  const existingProfileRule = rules.find((rule) => rule && rule[UI_PROFILE_RULE_MARKER] === exactCssPath);
  if (existingProfileRule) {
    assertSameDelivery(existingProfileRule, deliveryKey);
  } else {
    const globalRuleIndex = rules.indexOf(globalRule);
    const loaderOptions = {
      cssSha256: artifact.cssSha256,
      cssDelivery: options.cssDelivery || 'inline',
      cssRelativePath: `spfx-ui-profile/${delivery.sha256}.css`
    };
    if (subset) {
      Object.assign(loaderOptions, {
        styles: [...subset.styles],
        styleFragments: subset.styleFragments,
        deliveredCssSha256: subset.sha256
      });
    }
    rules.splice(globalRuleIndex + 1, 0, {
      ...globalRule,
      test: exactCssCondition,
      use: (Array.isArray(globalRule.use) ? globalRule.use : [globalRule.use]).map((entry) =>
        entry && typeof entry === 'object' && String(entry.loader || '').includes('@microsoft/sp-css-loader')
          ? {
              loader: path.join(packageRoot, 'spfx-ui-css-loader.cjs'),
              options: {
                ...loaderOptions,
                spfxCssLoader: entry.loader,
                async: entry.options?.async,
                loadThemedStylesImportPath: entry.options?.loadThemedStylesImportPath
              }
            }
          : entry
      ),
      [UI_PROFILE_RULE_MARKER]: exactCssPath,
      [DELIVERY_STYLES_MARKER]: deliveryKey
    });
  }

  // Gulp SPFx configurations can use a broad global CSS rule. Leave the
  // dedicated profile rule as the only loader chain matching this artifact.
  if (!containsUiProfileCondition(globalRule.exclude, exactCssPath)) {
    globalRule.exclude = appendCondition(globalRule.exclude, exactCssCondition);
  }

  // A trimmed build records its shipped styles in the bundled runtime, so the
  // host defaults to a shipped style and falls back from unshipped ones.
  if (subset) {
    const resolvedPackageRoot = realpathSync(packageRoot);
    const shippedModulePaths = SHIPPED_STYLES_MODULES.map((relativePath) => path.join(resolvedPackageRoot, relativePath));
    if (!rules.some((rule) => rule && rule[SHIPPED_STYLES_RULE_MARKER] === resolvedPackageRoot)) {
      const shippedModuleCondition = (resource) =>
        shippedModulePaths.includes(path.normalize(String(resource || '').split('?', 1)[0]));
      rules.push({
        test: shippedModuleCondition,
        use: [
          {
            loader: path.join(packageRoot, 'spfx-ui-shipped-styles-loader.cjs'),
            options: { styles: [...subset.styles] }
          }
        ],
        [SHIPPED_STYLES_RULE_MARKER]: resolvedPackageRoot
      });
    }
  }

  const plugins = webpackConfiguration.plugins || (webpackConfiguration.plugins = []);
  const existingPlugin = plugins.find((plugin) => plugin && plugin[UI_PROFILE_ASSET_PLUGIN_MARKER] === artifact.cssSha256);
  if (existingPlugin) {
    assertSameDelivery(existingPlugin, deliveryKey);
  } else {
    plugins.push(createDeliveryAssetsPlugin(artifact, delivery, deliveryKey));
  }

  return webpackConfiguration;
};

function assertSameDelivery(marked, deliveryKey) {
  if (marked[DELIVERY_STYLES_MARKER] !== undefined && marked[DELIVERY_STYLES_MARKER] !== deliveryKey) {
    throw new Error('The SPFx UI profile stylesheet is already configured with different styles in this webpack configuration.');
  }
}

function createDeliveryAssetsPlugin(artifact, delivery, deliveryKey) {
  const cssAssetPath = `spfx-ui-profile/${delivery.sha256}.css`;
  const manifestAssetPath = 'spfx-ui-profile/ui-profile-delivery.json';
  const cssBytes = delivery.bytes || readFileSync(artifact.cssPath);
  const manifest = {
    schemaVersion: 1,
    profileId: artifact.profileId,
    profileSha256: artifact.profileSha256,
    provenanceSha256: artifact.provenanceSha256,
    scopeValue: artifact.scopeValue,
    css: { path: cssAssetPath, bytes: cssBytes.byteLength, sha256: delivery.sha256 }
  };
  if (delivery.styles) {
    // The shipped stylesheet is a verified subset of the full artifact: the
    // shared fragments plus the listed styles' fragments, in original order.
    manifest.css.subsetOf = { sha256: artifact.cssSha256, bytes: readFileSync(artifact.cssPath).byteLength };
    manifest.styles = [...delivery.styles];
    manifest.fragments = delivery.fragments.map(({ style, sha256 }) => ({ style, sha256 }));
  }
  const manifestBytes = Buffer.from(`${JSON.stringify(manifest)}\n`);
  return {
    [UI_PROFILE_ASSET_PLUGIN_MARKER]: artifact.cssSha256,
    [DELIVERY_STYLES_MARKER]: deliveryKey,
    apply(compiler) {
      const emitDelivery = (compilation) => {
        emitAsset(compilation, cssAssetPath, cssBytes);
        emitAsset(compilation, manifestAssetPath, manifestBytes);
      };
      if (compiler.webpack?.Compilation && compiler.hooks.thisCompilation) {
        compiler.hooks.thisCompilation.tap('SpfxUiProfileDeliveryAssetsPlugin', (compilation) => {
          compilation.hooks.processAssets.tap(
            { name: 'SpfxUiProfileDeliveryAssetsPlugin', stage: compiler.webpack.Compilation.PROCESS_ASSETS_STAGE_ADDITIONAL },
            () => emitDelivery(compilation)
          );
        });
      } else {
        compiler.hooks.emit.tap('SpfxUiProfileDeliveryAssetsPlugin', emitDelivery);
      }
    }
  };
}

function emitAsset(compilation, assetPath, bytes) {
  const asset = { source: () => bytes, size: () => bytes.byteLength };
  if (typeof compilation.emitAsset === 'function' && compilation.compiler?.webpack?.sources?.RawSource) {
    compilation.emitAsset(assetPath, new compilation.compiler.webpack.sources.RawSource(bytes));
    return;
  }
  compilation.assets[assetPath] = asset;
}

function usesSpCssLoader(rule, modulesEnabled) {
  const loaders = Array.isArray(rule && rule.use) ? rule.use : [rule && rule.use];
  return loaders.some((entry) => {
    if (!entry || typeof entry !== 'object' || !String(entry.loader || '').includes('@microsoft/sp-css-loader')) {
      return false;
    }
    return Boolean(entry.options && entry.options.generateCssClassName) === modulesEnabled;
  });
}

function appendCondition(current, condition) {
  if (!current) return condition;
  return Array.isArray(current) ? [...current, condition] : [current, condition];
}

function containsUiProfileCondition(current, exactCssPath) {
  if (Array.isArray(current)) return current.some((entry) => containsUiProfileCondition(entry, exactCssPath));
  return typeof current === 'function' && current.uiProfileCssPath === exactCssPath;
}
