'use strict';

const { createHash } = require('node:crypto');
const { createRequire } = require('node:module');

const { selectStyleFragments } = require('./scripts/lib/style-fragments.cjs');

// The profile is already compiled, prefixed and scoped. Reprocessing it with
// legacy SPFx CSSnano changes its delivery bytes and rejects modern CSS colors.
module.exports = function loadCompiledUiProfile(source) {
  const options = this.getOptions();
  const fullCss = String(source);
  if (createHash('sha256').update(fullCss).digest('hex') !== options.cssSha256) {
    throw new Error('Compiled UI profile CSS differs from the verified delivery artifact.');
  }
  const { css, cssSha256 } = deliveredCss(fullCss, options);
  if (
    /@import\s/iu.test(fullCss) ||
    [...fullCss.matchAll(/url\(\s*(['"]?)([^'"\)]+)\1\s*\)/giu)].some(
      (match) => !/^(?:data:|https?:|\/\/|#)/iu.test(match[2].trim())
    )
  ) {
    throw new Error('Compiled UI profile CSS requires unresolved asset imports.');
  }
  if (options.cssDelivery === 'external') {
    return `
const href = new URL(__webpack_public_path__ + ${JSON.stringify(options.cssRelativePath)}, document.baseURI).href;
const registryKey = Symbol.for('spfx-kit.ui-profile.stylesheets.v1');
export function loadStylesheet() {
  const registry = document[registryKey] || (document[registryKey] = new Map());
  if (registry.has(href)) return registry.get(href);
  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = href;
  link.setAttribute('data-spfx-ui-stylesheet', ${JSON.stringify(cssSha256)});
  if (typeof __webpack_nonce__ !== 'undefined' && __webpack_nonce__) link.nonce = __webpack_nonce__;
  let timer;
  const promise = new Promise((resolve, reject) => {
    const fail = () => {
      clearTimeout(timer);
      link.onload = link.onerror = null;
      link.remove();
      registry.delete(href);
      reject(new Error('Unable to load the SPFx UI stylesheet: ' + href));
    };
    link.onload = () => {
      clearTimeout(timer);
      link.onload = link.onerror = null;
      resolve();
    };
    link.onerror = fail;
    timer = setTimeout(fail, 30000);
  });
  registry.set(href, promise);
  promise.catch(() => {});
  try { document.head.appendChild(link); }
  catch (_) { link.onerror(); }
  return promise;
}
export const stylesReady = loadStylesheet();
`;
  }
  const runtime =
    options.loadThemedStylesImportPath || createRequire(options.spfxCssLoader).resolve('@microsoft/load-themed-styles');
  return `import { loadStyles } from ${JSON.stringify(runtime)};\nloadStyles(${JSON.stringify(css)}, ${Boolean(options.async)});\n`;
};

// A trimmed build ships the shared fragments plus the selected styles'
// fragments of the verified artifact, in original order. The subset digest was
// computed by the webpack adapter and must match here too.
function deliveredCss(fullCss, options) {
  if (options.styles === undefined) return { css: fullCss, cssSha256: options.cssSha256 };
  const subset = selectStyleFragments(Buffer.from(fullCss, 'utf8'), options.styleFragments, options.styles, options.cssSha256);
  if (subset.sha256 !== options.deliveredCssSha256) {
    throw new Error('Trimmed UI profile CSS differs from the stylesheet the webpack adapter emitted.');
  }
  return { css: subset.bytes.toString('utf8'), cssSha256: subset.sha256 };
}
