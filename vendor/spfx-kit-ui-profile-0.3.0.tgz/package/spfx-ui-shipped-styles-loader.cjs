'use strict';

const { normalizeStyleSelection } = require('./scripts/lib/style-fragments.cjs');

// Records a trimmed build's shipped styles in the bundled copy of
// dist/src/shipped-styles.js (ESM or CommonJS). The module assigns `null`
// exactly once; anything else means the runtime and adapter disagree.
const ASSIGNMENT = /(\bSPFX_UI_BUILD_SHIPPED_STYLES = )null;/gu;

module.exports = function recordShippedUiProfileStyles(source) {
  const styles = normalizeStyleSelection(this.getOptions().styles);
  const text = String(source);
  const matches = text.match(ASSIGNMENT) || [];
  if (matches.length !== 1) {
    throw new Error('UI profile shipped-styles module differs from the reviewed runtime; cannot record the shipped styles.');
  }
  return text.replace(ASSIGNMENT, (_match, prefix) => `${prefix}Object.freeze(${JSON.stringify(styles)});`);
};
