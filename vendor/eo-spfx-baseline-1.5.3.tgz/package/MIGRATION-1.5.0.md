# One identity and name for both channels

Baseline 1.5.1 packages DEV and PROD as updates to the same original application. It removes automatic DEV suffixes from app, feature and web-part picker names. The channel remains visible in build metadata and About attribution. Runtime contracts, dependency pins, permissions and all-sites eligibility are unchanged.

## Adopt

1. Back up local edits and retain previous packages. Record the existing PROD solution, feature and component IDs, including additional components.
2. Copy those exact original IDs into the DEV record in `delivery/identities.json`. Do not generate replacement IDs. Keep the original IDs in source manifests and package configuration. Preserve any obsolete DEV IDs in migration notes, outside active delivery configuration.
3. Keep the normal product name in `displayName` and each additional component descriptor. Remove any channel suffix that an app added itself. Baseline 1.5.1 rejects split identity descriptors before staging; there is no opt-in split mode.
4. Vendor the new immutable archive and checksum. Update locks deliberately, install each app's lock with `npm ci`, and run its checks and both root packaging commands. Inspect the actual app title, component titles, IDs, picker entries, capabilities, permissions and asset paths in each package.

DEV can embed assets or use an explicit CDN. PROD retains its explicit CDN profile. Both channels update the same catalog registration and its existing page instances. Installing DEV into a production catalog therefore changes that application for its consumers. Use a separate test catalog or tenant when isolation is needed.

## Existing duplicate registrations

A new package cannot remove an older app registered under a different ID. Inventory catalog entries and page instances using the obsolete DEV component IDs before retiring that registration. Preserve page configuration and records when moving affected pages to the original component. Treat removal as a separate, reviewed deployment action; packaging does not alter catalogs, pages, list schemas or permissions.

Previous retained packages remain historical artifacts and still contain their original identity behavior. Rebuild reviewed source with the new baseline. Other apps retain their existing pinned toolkit until explicitly migrated.
