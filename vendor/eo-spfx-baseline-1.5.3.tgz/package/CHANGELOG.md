# 1.5.3 — Verify renamed package files by content

A renamed outer `.sppkg` file remains verifiable when exactly one package in its release folder matches the recorded SHA-256. Original manifests, checksums and source provenance remain unchanged. Changed bytes, ambiguous matches, linked files and renamed runtime assets remain rejected. Both channels retain the original application and component IDs and names.

# 1.5.2 — Stable package download names

Release packages retain the filename declared by package-solution.json (for example better-atlas.sppkg) in both channels. Versions and channels remain in release folders and manifests. This removes the need to rename the inventoried file before a catalog upload, which invalidated the Portfolio download. Existing release folders are not rewritten.

# 1.5.1 — Preserve the original internal solution name

Validate the emitted App Name against the original technical solution name, which may differ from the visible product title. Both DEV and PROD retain that name. This corrects the 1.5.0 package validator without changing the single-identity policy.

# 1.5.0 — One application identity and name

DEV and PROD now reuse the original PROD solution, feature and component IDs. Channel suffixes are removed from app, feature and picker titles. Split descriptors fail before staging, and actual package inspection rejects incorrect app names, picker titles, IDs or component counts. Channel metadata, asset hosting, all-sites eligibility, permissions and runtime contracts remain intact. See [migration](MIGRATION-1.5.0.md) before adoption; previously installed DEV registrations require a separate usage review.

# 1.4.4 — All-sites deployment option in both channels

DEV and PROD packages now allow administrators to add the app to all sites. Omitted settings default to true; explicit false is rejected. Legacy source false settings are enabled in staging. Package inspection enforces the flag for embedded and CDN assets. Channel identities, names and runtime contracts remain unchanged. Older retained packages require rebuilding.

# 1.4.3 — DEV all-sites deployment contract

DEV packages now always support adding the app to all sites and subsites. An omitted setting defaults to true; an explicit false is rejected before staging. Actual package inspection rejects a missing or false deployment flag, for both embedded assets and CDN hosting. PROD eligibility, channel identities, runtime contracts and tenant activation remain unchanged. Older retained packages require a rebuild; updating tooling does not modify them.

# 1.4.2 — explicit deployment eligibility

Allow each delivery profile channel to declare boolean `skipFeatureDeployment`. DEV keeps its site-install default unless explicitly enabled; PROD preserves its source setting unless explicitly configured. Staging and actual package inspection enforce the same setting independently of embedded or CDN asset hosting. Release metadata and deployment instructions record eligibility, which still requires administrator confirmation in SharePoint. Runtime contracts and other applications remain unchanged until they adopt this release.

# 1.4.1 — constant lazy-chunk validation

Recognize webpack single-chunk literal filename resolvers using the emitted runtime’s static chunk requests. Preserve missing-file, registration-ID, namespace and classic-loader checks. Unknown/dynamic requests remain blocked. This fixes NEXUS PROD packaging without changing application behavior or runtime dependency contracts.

# 1.3.1 — Teams packaging icons

SPFx always copies the teams/ folder even with includeClientSideAssets=false. An explicit teamsIcons descriptor permits only the two source-hashed PNG icons for the current component ID; embedded JavaScript and other runtime assets remain rejected. DEV renames these icons inside staging to its own component ID. Source identities and files remain unchanged. Add malformed/changed-icon and hidden-code regressions.

# 1.3.0 — nested applications and catalog version mapping

Add nested SPFx project roots, explicit solution-version mappings, and staged library build scripts. Local file dependencies use a private node_modules overlay pointing to staged source; installed dependencies and source lockfiles are never changed by packaging. Release manifests record every installation lock and the build graph. Existing flat apps remain compatible and stay on their pinned baseline until upgraded individually.

# 1.2.1 — SPFx manifest encoding

Accept omitted SkipFeatureDeployment as the SPFx false/default encoding for DEV. Explicit tenant-wide deployment remains rejected. Add a regression using the real emitted XML shape.

# 1.2.0 — portable delivery pilot

- Add isolated, descriptor-based DEV/PROD packaging and retained/latest release folders.
- Preserve PROD identity; require separate DEV solution/feature/component IDs.
- Add raw ZIP bytes for embedded binary asset validation and explicit CDN-root checks.
- Add tenant-neutral profiles and retained-build live verification.
- Add publication-failure, path, identity, portability and binary-asset tests.

# Changelog

## 1.1.0 — 2026-09-16

- Add a shared classic-script webpack patch for the managed CDN's missing CORS
  response headers. Consumers must register the patch in their build configuration.
- Extend production preflight with `--assets` to check emitted JavaScript,
  webpack 5 chunk filenames/IDs/namespaces and matching package entry bundles.
- Block audited PROD release scripts that omit the asset preflight.
- Add `verify-cdn` for live status, MIME type, redirect and exact checksum checks
  using the configured SharePoint referrers before App Catalog installation.
- Reject malformed package archives and packages without a verifiable CDN route.
- Update Heft/Gulp script templates, webpack configuration guidance and CI
  templates. Consumer CI retains matching PROD outputs without deploying them.
- Prefer a versioned vendored archive over private-repository tokens in CI.
- Fix the baseline's own workflow to run its real tests and package validation.
- Preserve the existing SPFx/React/Fluent/Tabster compatibility pins.

Manifest-only `preflight` remains available for diagnosis. Upgrading the baseline
does not rewrite consuming projects; register the shared patch and adopt the new
PROD release command before expecting the additional protection.
