'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { inside, loadConfig, stageDependencies, applyProfile, collectAssets, inspectPackage, verifyBuild, publish, acquireLock } = require('./delivery.cjs');
const hash = b => crypto.createHash('sha256').update(b).digest('hex');
const write = (file, value) => { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, typeof value === 'string' || Buffer.isBuffer(value) ? value : JSON.stringify(value)); };

function fixture(t) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'renamed SPFx pilot '));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  const app = { schemaVersion: 1, appKey: 'example', displayName: 'Example', projectRoot: '.', componentManifest: 'src/Example.manifest.json', defaultProfile: 'default', validationScripts: ['check'] };
  const ids = { dev: { solutionId: crypto.randomUUID(), featureId: crypto.randomUUID(), componentId: crypto.randomUUID() }, prod: { solutionId: crypto.randomUUID(), featureId: crypto.randomUUID(), componentId: crypto.randomUUID() } };
  const profile = { schemaVersion: 1, id: 'default', channels: { dev: { assetMode: 'embedded', cdnRoot: 'https://assets.example.test/app/', verificationOrigins: ['https://one.sharepoint.com', 'https://two.sharepoint.com'] }, prod: { assetMode: 'cdn', cdnRoot: 'https://assets.example.test/app/', verificationOrigins: ['https://one.sharepoint.com'] } } };
  write(path.join(root, 'delivery/app.json'), app); write(path.join(root, 'delivery/identities.json'), ids); write(path.join(root, 'delivery/environments/default.json'), profile);
  write(path.join(root, 'package.json'), { version: '1.2.3', scripts: { check: 'node check.cjs' } });
  write(path.join(root, 'config/package-solution.json'), { solution: { id: ids.prod.solutionId, version: '1.2.3.0', skipFeatureDeployment: true, features: [{ id: ids.prod.featureId, version: '1.2.3.0' }] } });
  write(path.join(root, 'config/write-manifests.json'), { cdnBasePath: profile.channels.prod.cdnRoot });
  write(path.join(root, app.componentManifest), { id: ids.prod.componentId, preconfiguredEntries: [{ title: { default: 'Example' } }] });
  return { root, app, ids, profile };
}

// Store-only ZIP sufficient to exercise byte-preserving package inspection.
function zip(entries) {
  const locals = [], central = []; let offset = 0;
  for (const [name, raw] of entries) {
    const file = Buffer.from(name), data = Buffer.from(raw), header = Buffer.alloc(30), directory = Buffer.alloc(46);
    let crc = 0xffffffff; for (const byte of data) { crc ^= byte; for (let n = 0; n < 8; n++) crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0); } crc = (crc ^ 0xffffffff) >>> 0;
    header.writeUInt32LE(0x04034b50); header.writeUInt16LE(20, 4); header.writeUInt32LE(crc, 14); header.writeUInt32LE(data.length, 18); header.writeUInt32LE(data.length, 22); header.writeUInt16LE(file.length, 26);
    directory.writeUInt32LE(0x02014b50); directory.writeUInt16LE(20, 4); directory.writeUInt16LE(20, 6); directory.writeUInt32LE(crc, 16); directory.writeUInt32LE(data.length, 20); directory.writeUInt32LE(data.length, 24); directory.writeUInt16LE(file.length, 28); directory.writeUInt32LE(offset, 42);
    locals.push(header, file, data); central.push(directory, file); offset += header.length + file.length + data.length;
  }
  const c = Buffer.concat(central), end = Buffer.alloc(22); end.writeUInt32LE(0x06054b50); end.writeUInt16LE(entries.length, 8); end.writeUInt16LE(entries.length, 10); end.writeUInt32LE(c.length, 12); end.writeUInt32LE(offset, 16);
  return Buffer.concat([...locals, c, end]);
}

function packageFixture(f, channel, overrides = {}) {
  const id = { ...f.ids[channel], ...overrides }, embedded = f.profile.channels[channel].assetMode === 'embedded', assets = path.join(f.root, 'asset tree');
  const js = Buffer.from('define([],function(){return 1;});'), font = Buffer.from([0, 255, 128, 1]);
  write(path.join(assets, 'bundle.js'), js); write(path.join(assets, 'fonts/font.woff2'), font);
  const manifest = { id: id.componentId, version: '1.2.3', ...(overrides.component || {}), loaderConfig: { internalModuleBaseUrls: [embedded ? 'https://example/SPCLIENTSIDEASSETLIBRARY/' : f.profile.channels[channel].cdnRoot], scriptResources: { main: { type: 'path', path: 'bundle.js' } } } };
  const entries = [['AppManifest.xml', `<App ProductID="${id.solutionId}" Version="1.2.3.0"${overrides.deploymentAttribute ?? ' SkipFeatureDeployment="true"'}/>`], ['feature/Feature.xml', `<Feature Id="${id.featureId}"/>`], ['feature/WebPart_example.xml', `<ClientSideComponent ComponentManifest="${JSON.stringify(manifest).replaceAll('"', '&quot;')}"/>`]];
  if (embedded) entries.push(['ClientSideAssets/bundle.js', js], ['ClientSideAssets/fonts/font.woff2', font]);
  entries.push(...(overrides.extraEntries || []));
  const file = path.join(f.root, channel + '.sppkg'); fs.writeFileSync(file, zip(entries)); return { file, assets };
}

test('descriptor rejects overlapping channel IDs and path escape before generation', t => {
  const f = fixture(t); f.ids.dev.componentId = f.ids.prod.componentId; write(path.join(f.root, 'delivery/identities.json'), f.ids);
  assert.throws(() => loadConfig(f.root), /distinct/); assert.throws(() => inside(f.root, '../other'), /escapes/);
  assert(!fs.existsSync(path.join(f.root, 'scratch')));
});
test('tenant test origins never become application allowlists; CDN profiles can change independently', t => {
  const f = fixture(t), config = loadConfig(f.root); applyProfile(f.root, config, 'dev');
  const info = fs.readFileSync(path.join(f.root, 'src/delivery/buildInfo.ts'), 'utf8'); assert(!info.includes('sharepoint.com')); assert(!info.includes('Origins'));
  const component = JSON.parse(fs.readFileSync(path.join(f.root, f.app.componentManifest))); assert.equal(component.id, f.ids.dev.componentId); assert.equal(component.preconfiguredEntries[0].title.default, 'Example DEV');
  config.profile.channels.prod.cdnRoot = 'https://other.example.test/new/'; applyProfile(f.root, config, 'prod');
  assert.equal(JSON.parse(fs.readFileSync(path.join(f.root, 'config/write-manifests.json'))).cdnBasePath, 'https://other.example.test/new/');
});
test('recursive inventory hashes binary fonts; embedded DEV bytes must match exactly', t => {
  const f = fixture(t), p = packageFixture(f, 'dev'); assert.equal(collectAssets(p.assets).length, 2);
  assert(inspectPackage(p.file, p.assets, loadConfig(f.root), 'dev').ok);
  write(path.join(p.assets, 'fonts/font.woff2'), Buffer.from([1, 2])); assert.throws(() => inspectPackage(p.file, p.assets, loadConfig(f.root), 'dev'), /mismatched embedded/);
});
test('PROD retains exact identity and uses its declared CDN even outside the original tenant CDN', t => {
  const f = fixture(t), p = packageFixture(f, 'prod'); assert(inspectPackage(p.file, p.assets, loadConfig(f.root), 'prod').ok);
  const bad = packageFixture(f, 'prod', { solutionId: crypto.randomUUID() }); assert.throws(() => inspectPackage(bad.file, bad.assets, loadConfig(f.root), 'prod'), /solution identity/);
});
test('both channels reject omitted and false package flags with embedded assets or CDN hosting', t => {
  for (const channel of ['dev', 'prod']) for (const assetMode of (channel === 'prod' ? ['cdn'] : ['embedded', 'cdn'])) {
    const f = fixture(t);
    f.profile.channels[channel].assetMode = assetMode;
    write(path.join(f.root, 'delivery/environments/default.json'), f.profile);
    const config = loadConfig(f.root);
    for (const deploymentAttribute of ['', ' SkipFeatureDeployment="false"', ' SkipFeatureDeployment="0"']) {
      const p = packageFixture(f, channel, { deploymentAttribute });
      assert.throws(() => inspectPackage(p.file, p.assets, config, channel), /tenant-wide eligibility/);
    }
    for (const deploymentAttribute of [' SkipFeatureDeployment="true"', ' SkipFeatureDeployment="1"']) {
      const p = packageFixture(f, channel, { deploymentAttribute });
      assert.equal(inspectPackage(p.file, p.assets, config, channel).skipFeatureDeployment, true);
    }
  }
});

test('DEV all-sites eligibility survives staging with legacy PROD source', t => {
  for (const value of [undefined, true]) for (const assetMode of ['embedded', 'cdn']) {
    const f = fixture(t);
    f.profile.channels.dev.skipFeatureDeployment = value;
    f.profile.channels.dev.assetMode = assetMode;
    write(path.join(f.root, 'delivery/environments/default.json'), f.profile);
    const file = path.join(f.root, 'config/package-solution.json');
    const solution = JSON.parse(fs.readFileSync(file));
    solution.solution.skipFeatureDeployment = false;
    write(file, solution);
    const config = loadConfig(f.root);
    assert.equal(config.skipFeatureDeployment.prod, true);
    applyProfile(f.root, config, 'dev');
    const staged = JSON.parse(fs.readFileSync(file));
    assert.equal(staged.solution.skipFeatureDeployment, true);
    assert.equal(staged.solution.includeClientSideAssets, assetMode === 'embedded');
    assert.equal(staged.solution.id, f.ids.dev.solutionId);
    const valid = packageFixture(f, 'dev');
    assert.equal(inspectPackage(valid.file, valid.assets, config, 'dev').skipFeatureDeployment, true);
  }
});

test('an explicit false DEV setting fails before source or staging is changed', t => {
  const f = fixture(t);
  f.profile.channels.dev.skipFeatureDeployment = false;
  write(path.join(f.root, 'delivery/environments/default.json'), f.profile);
  const file = path.join(f.root, 'config/package-solution.json'), before = fs.readFileSync(file);
  assert.throws(() => loadConfig(f.root), /DEV must support adding the app to all sites/);
  assert.deepEqual(fs.readFileSync(file), before);
});

test('deployment eligibility is boolean, not a truthy string', t => {
  for (const value of ['true', 'false', 1, null]) {
    const f = fixture(t);
    f.profile.channels.dev.skipFeatureDeployment = value;
    write(path.join(f.root, 'delivery/environments/default.json'), f.profile);
    assert.throws(() => loadConfig(f.root), /must be a boolean/);
  }
});

test('PROD enables all-sites eligibility from legacy source and preserves identities', t => {
  const f = fixture(t);
  const file = path.join(f.root, 'config/package-solution.json');
  const solution = JSON.parse(fs.readFileSync(file));
  solution.solution.skipFeatureDeployment = false;
  write(file, solution);
  const config = loadConfig(f.root);
  assert.equal(config.skipFeatureDeployment.prod, true);
  applyProfile(f.root, config, 'prod');
  assert.equal(JSON.parse(fs.readFileSync(file)).solution.skipFeatureDeployment, true);
  assert.equal(JSON.parse(fs.readFileSync(file)).solution.id, f.ids.prod.solutionId);
  assert.equal(JSON.parse(fs.readFileSync(path.join(f.root,f.app.componentManifest))).id, f.ids.prod.componentId);
  const wrong = packageFixture(f, 'prod', {deploymentAttribute: ' SkipFeatureDeployment="false"'});
  assert.throws(() => inspectPackage(wrong.file, wrong.assets, config, 'prod'), /tenant-wide eligibility/);
});
test('DEV and PROD cannot share a packaging lock', t => {
  const f = fixture(t), unlock = acquireLock(f.root); assert.throws(() => acquireLock(f.root), /Another delivery/); unlock(); acquireLock(f.root)();
});

function handoff(root, id) {
  const dir = path.join(root, 'handoff-' + id), bytes = Buffer.from(id); write(path.join(dir, 'app.sppkg'), bytes);
  const m = { schemaVersion: 1, appVersion: '1.2.3', profile: 'default', buildId: id, packageFile: 'app.sppkg', files: [{ path: 'app.sppkg', sha256: hash(bytes) }] };
  write(path.join(dir, 'release-manifest.json'), m);
  write(path.join(dir, 'SHA256SUMS.txt'), `${hash(bytes)}  app.sppkg\n${hash(fs.readFileSync(path.join(dir, 'release-manifest.json')))}  release-manifest.json\n`); return dir;
}

test('one package carries all components with distinct DEV IDs and unchanged PROD IDs', t => {
  const f = fixture(t), manifest = 'src/Health.manifest.json';
  f.app.additionalComponents = [{ key: 'health', manifest, displayName: 'App Health' }];
  for (const channel of ['dev', 'prod']) f.ids[channel].additionalComponentIds = { health: crypto.randomUUID() };
  write(path.join(f.root, manifest), { id: f.ids.prod.additionalComponentIds.health, supportedHosts: ['SharePointWebPart'], preconfiguredEntries: [{ title: { default: 'App Health' } }] });
  write(path.join(f.root, 'delivery/app.json'), f.app); write(path.join(f.root, 'delivery/identities.json'), f.ids);
  const config = loadConfig(f.root);
  const extra = channel => ['feature/WebPart_health.xml', `<ClientSideComponent ComponentManifest="${JSON.stringify({ id: f.ids[channel].additionalComponentIds.health, version: '1.2.3', supportedHosts: ['SharePointWebPart'], loaderConfig: { internalModuleBaseUrls: [channel === 'dev' ? 'https://example/SPCLIENTSIDEASSETLIBRARY/' : f.profile.channels.prod.cdnRoot], scriptResources: { main: { type: 'path', path: 'bundle.js' } } } }).replaceAll('"', '&quot;')}"/>`];
  for (const channel of ['dev', 'prod']) {
    const p = packageFixture(f, channel, { extraEntries: [extra(channel)] });
    assert(inspectPackage(p.file, p.assets, config, channel).ok);
  }
  const wrong = packageFixture(f, 'dev', { extraEntries: [extra('prod')] });
  assert.throws(() => inspectPackage(wrong.file, wrong.assets, config, 'dev'), /identity\/version/);
  const missing = packageFixture(f, 'dev');
  assert.throws(() => inspectPackage(missing.file, missing.assets, config, 'dev'), /number of web-part/);
  applyProfile(f.root, config, 'dev');
  const health = JSON.parse(fs.readFileSync(path.join(f.root, manifest)));
  assert.equal(health.id, f.ids.dev.additionalComponentIds.health);
  assert.equal(health.preconfiguredEntries[0].title.default, 'App Health DEV');
  applyProfile(f.root, config, 'prod');
  assert.equal(JSON.parse(fs.readFileSync(path.join(f.root, manifest))).id, f.ids.prod.additionalComponentIds.health);
});

test('additional component IDs and post-build hooks cannot escape the reviewed descriptor', t => {
  const f = fixture(t);
  f.ids.dev.additionalComponentIds = { unknown: crypto.randomUUID() };
  write(path.join(f.root, 'delivery/identities.json'), f.ids);
  assert.throws(() => loadConfig(f.root), /must match descriptors/);
  delete f.ids.dev.additionalComponentIds; write(path.join(f.root, 'delivery/identities.json'), f.ids);
  f.app.afterBuildScripts = ['absent']; write(path.join(f.root, 'delivery/app.json'), f.app);
  assert.throws(() => loadConfig(f.root), /post-build script/);
  delete f.app.afterBuildScripts; write(path.join(f.root, 'delivery/app.json'), f.app);
  write(path.join(f.root, 'config/config.json'), { bundles: { extra: { components: [{ manifest: './src/Untracked.manifest.json' }] } } });
  assert.throws(() => loadConfig(f.root), /Every bundled component/);
});
test('failed verification leaves latest intact; two valid builds retain distinct archives', t => {
  const f = fixture(t), cfg = loadConfig(f.root), first = publish(f.root, handoff(f.root, 'first'), cfg, 'prod', 'first');
  const bad = handoff(f.root, 'bad'); write(path.join(bad, 'app.sppkg'), 'wrong'); assert.throws(() => publish(f.root, bad, cfg, 'prod', 'bad'), /changed/);
  assert.equal(verifyBuild(first.latest).buildId, 'first'); const second = publish(f.root, handoff(f.root, 'second'), cfg, 'prod', 'second');
  assert.equal(verifyBuild(second.latest).buildId, 'second'); assert.equal(verifyBuild(first.retained).buildId, 'first');
});
test('Windows-style rename failure restores last successful alias and retains new build', t => {
  const f = fixture(t), cfg = loadConfig(f.root), first = publish(f.root, handoff(f.root, 'first'), cfg, 'dev', 'first');
  const second = handoff(f.root, 'second'), rename = fs.renameSync;
  try { fs.renameSync = (a, b) => { if (a.includes('.next-')) throw Object.assign(new Error('file locked'), { code: 'EPERM' }); return rename(a, b); };
    assert.throws(() => publish(f.root, second, cfg, 'dev', 'second'), /locked/);
  } finally { fs.renameSync = rename; }
  assert.equal(verifyBuild(first.latest).buildId, 'first'); assert(fs.existsSync(path.join(f.root, 'releases/dev/1.2.3/second')));
});
test('alternate CDN profile does not replace the default latest alias', t => {
  const f = fixture(t), cfg = loadConfig(f.root), first = publish(f.root, handoff(f.root, 'first'), cfg, 'prod', 'first');
  cfg.profile.id = 'alternate'; const second = publish(f.root, handoff(f.root, 'second'), cfg, 'prod', 'second');
  assert(second.latest.includes(path.join('profiles', 'alternate'))); assert.equal(verifyBuild(first.latest).buildId, 'first');
});

test('nested hosts stage their local library from source, never from the working checkout', t => {
  const f = fixture(t), host = path.join(f.root, 'spfx/host'); fs.mkdirSync(host, { recursive: true });
  fs.renameSync(path.join(f.root, 'config'), path.join(host, 'config'));
  fs.renameSync(path.join(f.root, 'src'), path.join(host, 'src'));
  f.app.projectRoot = 'spfx/host'; f.app.componentManifest = 'spfx/host/src/Example.manifest.json';
  f.app.stageScripts = ['build:library']; f.app.localPackages = [{ installRoot: 'spfx/host', name: '@example/library', sourceRoot: '.' }];
  write(path.join(f.root, 'delivery/app.json'), f.app);
  write(path.join(f.root, 'package.json'), { name: '@example/library', version: '1.2.3', scripts: { check: 'node check.cjs', 'build:library': 'node build.cjs' } });
  write(path.join(host, 'package.json'), { version: '1.2.3', dependencies: { '@example/library': 'file:../..' } });
  write(path.join(f.root, 'node_modules/tool/index.js'), 'tool');
  write(path.join(host, 'node_modules/@example/library/index.js'), 'stale working library');
  write(path.join(host, 'node_modules/@example/other/index.js'), 'other');
  write(path.join(host, 'node_modules/react/index.js'), 'react');
  const config = loadConfig(f.root), stage = path.join(f.root, 'isolated');
  fs.mkdirSync(path.join(stage, 'spfx/host'), { recursive: true });
  write(path.join(stage, 'index.js'), 'fresh staged library');
  stageDependencies(f.root, stage, config);
  assert.equal(fs.readFileSync(path.join(stage, 'spfx/host/node_modules/@example/library/index.js'), 'utf8'), 'fresh staged library');
  assert.equal(fs.readFileSync(path.join(stage, 'spfx/host/node_modules/react/index.js'), 'utf8'), 'react');
  assert.equal(fs.readFileSync(path.join(stage, 'spfx/host/node_modules/@example/other/index.js'), 'utf8'), 'other');
  applyProfile(f.root, config, 'dev');
  assert.equal(JSON.parse(fs.readFileSync(path.join(host, 'config/package-solution.json'))).solution.id, f.ids.dev.solutionId);
  assert(fs.existsSync(path.join(host, 'src/delivery/buildInfo.ts')));
  assert(!fs.existsSync(path.join(f.root, 'config')));
});

test('explicit solution version mapping preserves established catalog numbering', t => {
  const f = fixture(t); f.app.solutionVersion = '1.0.54.0'; write(path.join(f.root, 'delivery/app.json'), f.app);
  const file = path.join(f.root, 'config/package-solution.json'), solution = JSON.parse(fs.readFileSync(file));
  solution.solution.version = solution.solution.features[0].version = '1.0.54.0'; write(file, solution);
  assert.equal(loadConfig(f.root).solutionVersion, '1.0.54.0');
  delete f.app.solutionVersion; write(path.join(f.root, 'delivery/app.json'), f.app);
  assert.throws(() => loadConfig(f.root), /declared mapping/);
});

test('nested roots and local dependency mappings cannot escape the repository', t => {
  const f = fixture(t); f.app.projectRoot = '../elsewhere'; write(path.join(f.root, 'delivery/app.json'), f.app);
  assert.throws(() => loadConfig(f.root), /escapes/);
  f.app.projectRoot = '.'; f.app.localPackages = [{ installRoot: '.', name: '@example/lib', sourceRoot: '../outside' }]; write(path.join(f.root, 'delivery/app.json'), f.app);
  assert.throws(() => loadConfig(f.root), /escapes/);
});

test('CDN permits only declared exact Teams icon bytes and rejects embedded code or changed icons', t => {
  const f = fixture(t), png = Buffer.from([137,80,78,71,13,10,26,10,1,2,3]);
  f.app.teamsIcons = true; write(path.join(f.root, 'delivery/app.json'), f.app);
  const component = JSON.parse(fs.readFileSync(path.join(f.root, f.app.componentManifest))); component.supportedHosts = ['SharePointWebPart', 'TeamsTab']; write(path.join(f.root, f.app.componentManifest), component);
  const extraEntries = ['_color.png','_outline.png'].map(suffix => { write(path.join(f.root, 'teams/' + f.ids.prod.componentId + suffix), png); return ['ClientSideAssets/' + f.ids.prod.componentId + suffix, png]; });
  const config = loadConfig(f.root);
  let p = packageFixture(f, 'prod', { component: { supportedHosts: component.supportedHosts }, extraEntries });
  assert.equal(inspectPackage(p.file, p.assets, config, 'prod').packagingIcons.length, 2);
  p = packageFixture(f, 'prod', { component: { supportedHosts: component.supportedHosts }, extraEntries: [...extraEntries,['ClientSideAssets/hidden.js','alert(1)']] });
  assert.throws(() => inspectPackage(p.file, p.assets, config, 'prod'), /unapproved runtime/);
  p = packageFixture(f, 'prod', { component: { supportedHosts: component.supportedHosts }, extraEntries: [extraEntries[0],[extraEntries[1][0],Buffer.concat([png,Buffer.from([4])])]] });
  assert.throws(() => inspectPackage(p.file, p.assets, config, 'prod'), /changed Teams icon/);
  applyProfile(f.root, config, 'dev'); applyProfile(f.root, config, 'dev');
  assert(fs.existsSync(path.join(f.root,'teams/' + f.ids.dev.componentId + '_color.png')));
  assert(!fs.existsSync(path.join(f.root,'teams/' + f.ids.prod.componentId + '_color.png')));
});

 test('explicit false PROD profile is rejected before staging', t => { const f=fixture(t); f.profile.channels.prod.skipFeatureDeployment=false; write(path.join(f.root,'delivery/environments/default.json'),f.profile); assert.throws(()=>loadConfig(f.root),/PROD must support/); });
