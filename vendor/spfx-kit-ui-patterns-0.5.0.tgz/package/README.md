# @spfx-kit/ui-patterns

Shared React 17 compositions for SPFx apps — the app header, nav rail, record row, notice, lightbox and the other
patterns documented in the SPFx Kit Lab under **UI Library › Patterns**. Each pattern composes public
[`@spfx-kit/ui-profile`](../ui-profile) primitives; ui-profile itself stays a faithful copy of shadcn Base Nova and is
never redesigned here.

```tsx
import '@spfx-kit/ui-profile/styles.css';
import '@spfx-kit/ui-patterns/styles.css';
import { useLightbox } from '@spfx-kit/ui-patterns/preview-lightbox';
```

## Package layout

| Path                            | What it is                                                                          |
| ------------------------------- | ----------------------------------------------------------------------------------- |
| `src/<pattern-id>/index.ts`     | The pattern's public entry point, exported as `@spfx-kit/ui-patterns/<pattern-id>`. |
| `src/<pattern-id>/*.tsx`        | Implementation.                                                                     |
| `src/<pattern-id>/styles.css`   | The pattern's styles (optional).                                                    |
| `src/<pattern-id>/*.test.ts(x)` | Unit tests (Vitest, happy-dom).                                                     |
| `src/_internal/`                | Shared helpers (see below) and the tone prelude `tones.css`. Not exported.          |
| `scripts/build.mjs`             | Builds every discovered pattern and aggregates `dist/styles.css`.                   |

`<pattern-id>` is the kebab-case id of the pattern's UI Library page without the `pattern-` prefix (`nav-rail`,
`app-header`, `status-badge`, …). Patterns are discovered from the folder names: `package.json` uses one wildcard
export (`"./*"`), so adding a pattern never edits `package.json` or a shared barrel. `@spfx-kit/ui-patterns/_internal`
is blocked in `exports`.

## Build and outputs

`npm --workspace @spfx-kit/ui-patterns run build` type-checks with TypeScript 5.3 and 5.8 (the SPFx consumer
contracts ui-profile also pins), then emits:

- `dist/esm/<pattern-id>/` — ES modules (`import`)
- `dist/cjs/<pattern-id>/` — CommonJS (`require`)
- `dist/types/<pattern-id>/` — declarations (also mapped through `typesVersions` for `moduleResolution: node`)
- `dist/styles.css` — every pattern's `styles.css`, validated and concatenated

The root `npm run build` runs it after ui-profile's build (`build:profile`, then `build:theme`, then
`build:patterns`), because this package's `tsc` needs ui-profile's `dist` and its prepared Base UI types
(`.prepared/`). The UI Library's dev host and the tests consume the package **from source** (a Vite / Vitest alias and
a `tsconfig` path map `@spfx-kit/ui-patterns/<id>` to `src/<id>/index.ts`; the dev host also serves every
`src/*/styles.css` from source, `apps/ui-library/host/ui-patterns-source-styles.ts`), so pattern work never needs a
rebuild to show up there. A clone of this repository in the spfx-kit Lab uses the built package instead, which
`npm run lab:prepare` builds.

## Conventions

### Dependencies

- Import only public ui-profile entry points: `@spfx-kit/ui-profile` and `@spfx-kit/ui-profile/<component>` for a
  component listed in `packages/ui-profile/catalog.json`. Never import `normalized/`, `owned/`, `dist/`, `.prepared/`
  or `@base-ui/react` directly.
- Other allowed imports: `react`, `react-dom`, `lucide-react` (icons, same version as ui-profile).
- **A pattern never imports a sibling pattern.** When a composition needs another one (a record row showing a status
  badge, an app header with a search field), take it as a slot (`ReactNode` prop) or a render prop, and show the
  combination in the Lab example. Shared logic goes in `src/_internal/`.
- Relative imports use an explicit `.js` extension (`./notice.js`), so the ESM output resolves in Node and bundlers.
- `tests/ui-patterns-package.test.ts` enforces all of the above.

### Styling

- One optional `src/<pattern-id>/styles.css` per pattern. Components never import CSS; apps import
  `@spfx-kit/ui-patterns/styles.css` once, after `@spfx-kit/ui-profile/styles.css`.
- Every selector starts with `:where([data-spfx-ui-scope])` (the attribute SpfxUiHost puts on its app root **and** its
  portal host, so portalled content is covered; `:where()` adds no specificity) and includes the pattern's class
  prefix `.spfx-uip-<pattern-id>` — BEM-style parts are `.spfx-uip-<pattern-id>__<part>`, states are `data-*`
  attributes. The build fails otherwise.
- Colors come from ui-profile tokens only: `var(--spfx-ui-color-*)` (background, foreground, card, popover, primary,
  secondary, muted, accent, destructive, border, input, ring and their `-foreground` pairs). Plain black/white
  (`#fff`, `rgb(0 0 0 / 0.8)`) is allowed for scrims, shadows and on-scrim text. Radii use `--spfx-ui-radius-{sm,md,lg,xl}`,
  fonts `--spfx-ui-font-heading` / `--spfx-ui-font-mono`. Pattern-local custom properties are named
  `--spfx-uip-<pattern-id>-*`.
- Status colours come **only** from the shared tone variables (below); never define a success/warning/info colour
  in a pattern.
- Prefer composing ui-profile components and their `className` hooks over re-styling them; override a primitive's
  look only where the pattern's documented anatomy requires it, scoped to the pattern class.
- Light and dark: never hard-code a theme; tokens flip with the host theme. Check both in the Lab.
- Must work at phone width (≥ 320px) without horizontal page scroll.

### Tone variables

ui-profile has no success, warning or info colours, so the package ships one tone prelude,
`src/_internal/tones.css`, included first in `dist/styles.css` (and loaded by the Lab). It defines, under the host
scope and re-tuned for `[data-spfx-ui-theme='dark']`:

| Variable                        | Use                                                     |
| ------------------------------- | ------------------------------------------------------- |
| `--spfx-uip-tone-<tone>-bg`     | Tinted surface (badge, notice, step)                    |
| `--spfx-uip-tone-<tone>-fg`     | Text and icons on `-bg`; WCAG AA (≥ 4.5:1) against it   |
| `--spfx-uip-tone-<tone>-border` | Hairline border on `-bg`                                |
| `--spfx-uip-tone-<tone>-solid`  | Full-strength tone for dots, bars, fills — not for text |

`<tone>` is `neutral | info | success | warning | danger` (the `PatternTone` type). Hues: neutral → `secondary`,
info → `primary`, danger → `destructive` (ui-profile tokens, so they follow the host theme); success → green and
warning → amber (fixed OKLCH). Surfaces and text are `color-mix(in oklab, …)` of the hue into the host background /
foreground. `tests/ui-patterns-tones.test.ts` evaluates the file against every Lab theme preset in light and dark
and fails if any fg/bg pair drops below 4.5:1. Under `forced-colors: active` every tone maps to `Canvas` /
`CanvasText`. `toneVariables(tone)` in `_internal` returns the `var(…)` strings for inline styles.

The prelude is the only exemption from the pattern CSS rules: it may declare only `--spfx-uip-tone-*` properties
under the host scope (checked by `validateTonePrelude` in `scripts/build.mjs`).

### Shared helpers (`src/_internal`)

Import relatively (`import { … } from '../_internal/index.js'`):

| Export                                                 | What it is                                                                      |
| ------------------------------------------------------ | ------------------------------------------------------------------------------- |
| `initials(name, locale?)`                              | Avatar initials; handles "Last, First", parentheticals, locale upper-casing     |
| `useReducedMotion()` / `prefersReducedMotion(window?)` | `prefers-reduced-motion`, safe outside the browser                              |
| `patternMotion`                                        | Easing curves, durations and entrance scale (see Motion)                        |
| `PatternTone`, `patternTones`, `toneVariables(tone)`   | Tone type, list, and `var(--spfx-uip-tone-…)` strings                           |
| `PatternPerson`                                        | `{ id?; name; email?; imageUrl? }` — the person shape every pattern accepts     |
| `VisuallyHidden` / `visuallyHiddenStyle`               | Screen-reader-only text with an inline style (no CSS needed)                    |
| `useDebouncedCallback(fn, ms)`                         | Stable debounced function with `cancel()` / `flush()`; cancels on unmount       |
| `useElementWidth()`                                    | `[ref, width]` from ResizeObserver; measures once and stops where it is missing |

### Portals and IDs

- Render overlays with ui-profile's portalled primitives (Dialog, Popover, DropdownMenu, …); they portal into the
  SpfxUiHost portal host automatically. Never `createPortal` to `document.body`.
- Every DOM id comes from `useSpfxUiId(seed)` / `useSpfxUiDerivedId(parentId, part)` (from `@spfx-kit/ui-profile`),
  so ids are unique per SPFx root and stable. Seeds are `spfx-uip-<pattern-id>:<purpose>`. Components that need ids
  (e.g. ui-profile `DialogContent`) must receive them.

### Accessibility

- Follow the page's **Accessibility** section (roles, labelling, keyboard map) exactly; it is the contract.
- Visible focus rings (`--spfx-ui-color-ring`, 2px), 24px minimum hit targets, AA contrast in both themes.
- Active state: `aria-current="page"` for routes, `aria-current="true"` for the selected record or view; never
  `aria-pressed` in navigation.
- Never convey state by color alone; icons are `aria-hidden` unless they are the only label.

### Motion

Follow Emil Kowalski's guidance in `~/.claude/skills/emil-design-eng/SKILL.md`, `~/.claude/skills/animate/SKILL.md`
(+ `RECIPES.md`) and `~/.claude/skills/review-animations/STANDARDS.md`:

- Decide whether it should animate at all: nothing that is keyboard-initiated or happens tens/hundreds of times a day.
- Only `transform` and `opacity` (plus `clip-path`); never `scale(0)` — start at ≥ 0.9 with opacity 0.
- Curves and durations come from `src/_internal/motion.ts` (`patternMotion`): strong ease-out
  `cubic-bezier(0.23, 1, 0.32, 1)` for enter/exit, ≤ 300ms for UI; never `ease-in`.
- Popovers scale from their trigger (`var(--transform-origin)`); modals stay centered unless anchored to a trigger.
- CSS transitions (interruptible) over keyframes for anything that can be re-triggered.
- Reduced motion ships with the animation: use `useReducedMotion()` / `prefersReducedMotion()` and keep opacity,
  drop movement.
- Document the choices in the page's **Motion** table (decision, value, why).

## Contributing

See [CONTRIBUTING.md](./CONTRIBUTING.md) for exactly which files a pattern merge request adds or edits.
