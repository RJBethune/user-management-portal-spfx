# Geist Mono variable, Latin subset

One premade file copied unchanged from [@fontsource-variable/geist-mono 5.3.0](https://registry.npmjs.org/@fontsource-variable/geist-mono/-/geist-mono-5.3.0.tgz), sourced by [Fontsource](https://fontsource.org/fonts/geist-mono) from [Google Fonts](https://github.com/google/fonts/tree/main/ofl/geistmono) (Google Fonts `v6`) and the [Geist project](https://github.com/vercel/geist-font).

It is the upright variable font with the full weight axis (100–900), so every weight the theme uses (400 text, 500 chart values, 600/700 app identifiers) comes from one file. Only the Latin subset ships. Latin Extended, Cyrillic, Vietnamese and symbols fall back to the stack's system monospace fonts, and italic is synthesized by the browser. The `unicode-range` means a page downloads the file only when it renders monospace Latin text.

One file, **23,128 bytes**. Public family `Geist Mono Variable`, loaded by `fonts/geist-mono.css`. The asset is local, with no runtime CDN request.

SIL Open Font License 1.1 is copied from the same package into `LICENSE.txt`.

| Asset                                | Bytes | SHA-256                                                            |
| ------------------------------------ | ----: | ------------------------------------------------------------------ |
| `geist-mono-latin-wght-normal.woff2` | 23128 | `684ad5b531f81d43c1e8c7038262d5db7cdc1f68006e04d6c7769efa8d33c8cc` |
