# Inter variable subsets

Premade files copied unchanged from [@fontsource-variable/inter 5.3.0](https://registry.npmjs.org/@fontsource-variable/inter/-/inter-5.3.0.tgz), sourced by [Fontsource](https://fontsource.org/fonts/inter) from [Google Fonts](https://github.com/google/fonts/tree/main/ofl/inter) and the [Inter project](https://github.com/rsms/inter). Internal font version: `4.001;git-66647c0bb`. The directory name is retained for compatibility; these are not the previous author-release 4.1 binaries.

Upright and italic retain weight 100–900 and optical size 14–32. Latin, Latin Extended, and Vietnamese preserve accented names including Nguyễn. Greek, Cyrillic, and other scripts use application fallback fonts; full original script coverage is not preserved.

Six files total **463,916 bytes**, previously **740,216 bytes** (37.3% reduction). Upstream Unicode ranges allow browsers to load only required subsets. Public family `InterVariable` and `fonts/inter.css` are unchanged. Assets are local, with no runtime CDN request.

SIL Open Font License 1.1 is copied from the same package into `LICENSE.txt`.

| Asset                                |  Bytes | SHA-256                                                            |
| ------------------------------------ | -----: | ------------------------------------------------------------------ |
| `inter-vietnamese-opsz-normal.woff2` |  15268 | `935ab355938e6cd9b5fa39f2c3250ee16f3b08807c65dc4162356b50dbc8c7a2` |
| `inter-latin-ext-opsz-normal.woff2`  | 133336 | `5e6d4fe9d9f4bff8b2a2469d25ab19576bb85331e22c6ed51398e16f95d56a9c` |
| `inter-latin-opsz-normal.woff2`      |  72920 | `2c295d99e26dcf357d4d01bcf270fd6924b600c9a13dd8c363ef114f4c6976fa` |
| `inter-vietnamese-opsz-italic.woff2` |  16216 | `d102ea2c86a59e30a0c647a30791e251bf6701492a50549d1cdcf8a643fbbc98` |
| `inter-latin-ext-opsz-italic.woff2`  | 146460 | `cd92c8740f77f482bcd39e831fa7b1445589e9203cc9edb39fd49435d8976257` |
| `inter-latin-opsz-italic.woff2`      |  79716 | `c58f9d530baa7e96355f444502eca739d5eefa0f328f3d635b73648373214629` |
