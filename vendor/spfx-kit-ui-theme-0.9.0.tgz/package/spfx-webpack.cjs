'use strict';
const path = require('node:path');
const marker = Symbol.for('spfx-kit.ui-theme.global-css-rule');
/** Preserve the package's owned selectors through SPFx's CSS-module pipeline. */
module.exports = function configureSpfxUiThemeCss(configuration) {
  const rules = configuration?.module?.rules;
  if (!Array.isArray(rules)) throw new Error('SPFx webpack configuration does not expose module.rules.');
  const cssPath = path.normalize(path.join(__dirname, 'styles.css'));
  if (rules.some((rule) => rule && rule[marker] === cssPath)) return configuration;
  const usesLoader = (rule, modules) =>
    (Array.isArray(rule?.use) ? rule.use : [rule?.use]).some(
      (entry) =>
        entry &&
        typeof entry === 'object' &&
        String(entry.loader || '').includes('@microsoft/sp-css-loader') &&
        Boolean(entry.options?.generateCssClassName) === modules
    );
  const moduleRule = rules.find((rule) => usesLoader(rule, true));
  const globalRule = rules.find((rule) => usesLoader(rule, false));
  if (!moduleRule || !globalRule) throw new Error('Could not find the SPFx module and global CSS loader rules.');
  const matches = (resource) => path.normalize(String(resource || '').split('?', 1)[0]) === cssPath;
  const append = (current, value) => (!current ? value : Array.isArray(current) ? [...current, value] : [current, value]);
  const dedicated = { ...globalRule, test: matches, exclude: undefined, include: undefined, [marker]: cssPath };
  moduleRule.exclude = append(moduleRule.exclude, matches);
  globalRule.exclude = append(globalRule.exclude, matches);
  rules.splice(rules.indexOf(globalRule) + 1, 0, dedicated);
  return configuration;
};
