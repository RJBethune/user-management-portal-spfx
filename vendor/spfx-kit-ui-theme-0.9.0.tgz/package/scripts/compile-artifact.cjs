#!/usr/bin/env node
const fs = require('node:fs');
const { compileThemeArtifact } = require('../dist/compiler.js');
const [input, output] = process.argv.slice(2);
if (!input || !output) throw new Error('Usage: compile-artifact artifact-v1.json artifact-v2.json');
fs.writeFileSync(output, JSON.stringify(compileThemeArtifact(JSON.parse(fs.readFileSync(input, 'utf8'))), null, 2) + '\n');
