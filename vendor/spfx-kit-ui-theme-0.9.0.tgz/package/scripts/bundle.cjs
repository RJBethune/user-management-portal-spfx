#!/usr/bin/env node
// Build-time only. No runtime repository or credential dependency.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { parseThemeArtifact } = require('../dist/artifact-contract.js');
const { parseCompiledThemeArtifact } = require('../dist/compiled-artifact.js');
const [input, output] = process.argv.slice(2);
if (!input || !output) throw new Error('Usage: spfx-theme-bundle artifact.json output-directory');
const value = JSON.parse(fs.readFileSync(input, 'utf8'));
const artifact = value.version === 2 ? parseCompiledThemeArtifact(value) : parseThemeArtifact(value);
const fonts = new Set([
  artifact.document.preferences.font,
  artifact.document.preferences.fontHeading,
  artifact.document.preferences.fontMono
]);
const system = new Set([
  'inherit',
  'System Sans',
  'System Serif',
  'System Mono',
  'Arial',
  'Segoe UI',
  'Helvetica Neue',
  'Times New Roman',
  'Courier New',
  'OCR'
]);
const packaged = new Set(['Inter', 'Geist Mono']);
for (const font of fonts)
  if (!packaged.has(font) && !system.has(font))
    throw new Error(`Font ${font} needs a registered local font asset before packaging.`);
if (fs.existsSync(output) && fs.readdirSync(output).length)
  throw new Error('Output directory must be empty to avoid stale assets.');
fs.mkdirSync(output, { recursive: true });
fs.writeFileSync(path.join(output, 'theme.json'), JSON.stringify(artifact, null, 2) + '\n');
fs.copyFileSync(path.join(__dirname, '../styles.css'), path.join(output, 'styles.css'));
let css = '';
if (fonts.has('Inter')) {
  fs.cpSync(path.join(__dirname, '../fonts/inter-4.1'), path.join(output, 'fonts/inter-4.1'), { recursive: true });
  css = fs.readFileSync(path.join(__dirname, '../fonts/inter.css'), 'utf8').replaceAll('./inter-4.1/', './fonts/inter-4.1/');
}
if (fonts.has('Geist Mono')) {
  fs.cpSync(path.join(__dirname, '../fonts/geist-mono'), path.join(output, 'fonts/geist-mono'), { recursive: true });
  css +=
    (css ? '\n' : '') +
    fs.readFileSync(path.join(__dirname, '../fonts/geist-mono.css'), 'utf8').replaceAll('./geist-mono/', './fonts/geist-mono/');
}
fs.writeFileSync(path.join(output, 'fonts.css'), css);
const files = [];
function inventory(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const file = path.join(dir, entry.name);
    if (entry.isDirectory()) inventory(file);
    else if (entry.name !== 'manifest.json')
      files.push({
        path: path.relative(output, file).split(path.sep).join('/'),
        sha256: crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')
      });
  }
}
inventory(output);
fs.writeFileSync(
  path.join(output, 'manifest.json'),
  JSON.stringify({ kind: 'spfx-kit-theme-assets', version: 1, compatibility: artifact.compatibility, files }, null, 2) + '\n'
);
