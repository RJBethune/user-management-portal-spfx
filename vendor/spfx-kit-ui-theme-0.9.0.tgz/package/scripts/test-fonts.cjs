const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const css = fs.readFileSync(path.join(root, 'fonts/inter.css'), 'utf8');
const urls = [...css.matchAll(/url\(([^)]+)\)/g)].map((match) => match[1].replace(/['"]/g, ''));
assert.equal(urls.length, 6);
assert.equal(new Set(urls).size, 6);
let bytes = 0;
for (const url of urls) {
  const data = fs.readFileSync(path.resolve(root, 'fonts', url));
  assert.equal(data.subarray(0, 4).toString(), 'wOF2');
  bytes += data.length;
}
assert.equal(bytes, 463916);
assert.equal((css.match(/font-style: italic/g) || []).length, 3);
assert.equal((css.match(/font-weight: 100 900/g) || []).length, 6);
assert.equal((css.match(/unicode-range:/g) || []).length, 6);
for (const script of ['latin-', 'latin-ext-', 'vietnamese-']) assert.ok(urls.some((url) => url.includes(script)));
const mono = fs.readFileSync(path.join(root, 'fonts/geist-mono.css'), 'utf8');
const monoUrls = [...mono.matchAll(/url\(([^)]+)\)/g)].map((match) => match[1].replace(/['"]/g, ''));
assert.deepEqual(monoUrls, ['./geist-mono/geist-mono-latin-wght-normal.woff2']);
const monoData = fs.readFileSync(path.resolve(root, 'fonts', monoUrls[0]));
assert.equal(monoData.subarray(0, 4).toString(), 'wOF2');
assert.equal(monoData.length, 23128);
assert.match(mono, /font-family: 'Geist Mono Variable'/);
assert.match(mono, /font-weight: 100 900/);
assert.ok(fs.existsSync(path.join(root, 'fonts/geist-mono/LICENSE.txt')));
// Metric-matched fallbacks: local() sources only, and every face overrides all four metrics.
const fallbackFaces = [...(css + mono).matchAll(/@font-face\s*{([^}]*)}/g)]
  .map((match) => match[1])
  .filter((body) => /Fallback/.test(body));
assert.equal(fallbackFaces.length, 7);
for (const body of fallbackFaces) {
  assert.match(body, /src: local\(/);
  assert.doesNotMatch(body, /url\(/);
  for (const descriptor of ['size-adjust', 'ascent-override', 'descent-override', 'line-gap-override'])
    assert.match(body, new RegExp(`${descriptor}: \\d+(\\.\\d+)?%;`));
}
for (const family of ['InterVariable Fallback Segoe UI', 'InterVariable Fallback Arial'])
  assert.ok(css.includes(`font-family: '${family}'`));
for (const family of ['Geist Mono Fallback Consolas', 'Geist Mono Fallback Menlo', 'Geist Mono Fallback Courier New'])
  assert.ok(mono.includes(`font-family: '${family}'`));
console.log(
  'Six Inter subset assets, the Geist Mono Latin asset, CSS references and seven metric-matched fallback faces verified.'
);
