import { THEME_FONT_FAMILIES } from './uiLibraryThemingFonts';
export const UI_LIBRARY_THEME_DOCUMENT_KIND = 'spfx-kit-ui-library-theme';
export const UI_LIBRARY_THEME_DOCUMENT_VERSION = 1;
const documentKeys = ['kind', 'version', 'id', 'name', 'preferences'];
const preferenceKeys = [
    'style',
    'baseColor',
    'theme',
    'chartColor',
    'font',
    'fontHeading',
    'fontMono',
    'iconLibrary',
    'radius',
    'cornerShape',
    'menuColor',
    'menuAppearance',
    'menuAccent'
];
const styles = new Set(['Vega', 'Nova', 'Maia', 'Lyra', 'Mira', 'Luma']);
const baseColors = new Set(['Neutral', 'Stone', 'Zinc', 'Mauve', 'Olive', 'Mist', 'Taupe']);
const chromaticColors = new Set([
    'Amber',
    'Blue',
    'Cyan',
    'Emerald',
    'Fuchsia',
    'Green',
    'Indigo',
    'Lime',
    'Orange',
    'Pink',
    'Purple',
    'Red',
    'Rose',
    'Sky',
    'Teal',
    'Violet',
    'Yellow'
]);
const fontNames = new Set(Object.keys(THEME_FONT_FAMILIES));
const iconLibraries = new Set(['Lucide', 'Tabler Icons', 'HugeIcons', 'Phosphor Icons', 'Remix Icon']);
const radii = new Set(['Default', 'None', 'Small', 'Medium', 'Large']);
const cornerShapes = new Set(['Default', 'Squircle']);
const menuColors = new Set(['Default', 'Inverted']);
const menuAppearances = new Set(['Solid', 'Translucent']);
const menuAccents = new Set(['Subtle', 'Bold']);
export const UI_LIBRARY_THEME_DOCUMENT_ID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
export class UiLibraryThemeDocumentError extends Error {
}
export function createUiLibraryThemeDocument(input) {
    return parseUiLibraryThemeDocument({
        kind: UI_LIBRARY_THEME_DOCUMENT_KIND,
        version: UI_LIBRARY_THEME_DOCUMENT_VERSION,
        id: input.id,
        name: input.name,
        preferences: input.preferences
    });
}
export function parseUiLibraryThemeDocument(value) {
    if (!isRecord(value) || !hasExactKeys(value, documentKeys)) {
        throw new UiLibraryThemeDocumentError('Theme document must contain only kind, version, id, name, and preferences.');
    }
    if (value.kind !== UI_LIBRARY_THEME_DOCUMENT_KIND || value.version !== UI_LIBRARY_THEME_DOCUMENT_VERSION) {
        throw new UiLibraryThemeDocumentError('Unsupported theme document kind or version.');
    }
    const id = typeof value.id === 'string' ? value.id.trim() : '';
    if (!UI_LIBRARY_THEME_DOCUMENT_ID_PATTERN.test(id) || id !== value.id) {
        throw new UiLibraryThemeDocumentError('Theme id must be a canonical lowercase UUID.');
    }
    const name = typeof value.name === 'string' ? value.name.trim() : '';
    if (!name || name.length > 128 || name !== value.name) {
        throw new UiLibraryThemeDocumentError('Theme name must be trimmed and contain 1-128 characters.');
    }
    if (!isRecord(value.preferences) || !hasExactKeys(value.preferences, preferenceKeys)) {
        throw new UiLibraryThemeDocumentError('Theme preferences contain missing or unsupported fields.');
    }
    for (const key of preferenceKeys) {
        if (typeof value.preferences[key] !== 'string') {
            throw new UiLibraryThemeDocumentError(`Theme preference ${key} must be a string.`);
        }
    }
    const preferences = value.preferences;
    validatePreferences(preferences);
    return {
        kind: UI_LIBRARY_THEME_DOCUMENT_KIND,
        version: UI_LIBRARY_THEME_DOCUMENT_VERSION,
        id,
        name,
        preferences
    };
}
function validatePreferences(preferences) {
    const availableColors = new Set([preferences.baseColor, ...chromaticColors]);
    const supported = styles.has(preferences.style) &&
        baseColors.has(preferences.baseColor) &&
        availableColors.has(preferences.theme) &&
        availableColors.has(preferences.chartColor) &&
        fontNames.has(preferences.font) &&
        (preferences.fontHeading === 'inherit' || fontNames.has(preferences.fontHeading)) &&
        fontNames.has(preferences.fontMono) &&
        iconLibraries.has(preferences.iconLibrary) &&
        radii.has(preferences.radius) &&
        cornerShapes.has(preferences.cornerShape) &&
        menuColors.has(preferences.menuColor) &&
        menuAppearances.has(preferences.menuAppearance) &&
        menuAccents.has(preferences.menuAccent);
    if (!supported)
        throw new UiLibraryThemeDocumentError('Theme preferences contain an unsupported value.');
    if (preferences.fontHeading === preferences.font) {
        throw new UiLibraryThemeDocumentError('Theme heading font must use inherit when it matches the body font.');
    }
    if (preferences.menuAppearance === 'Translucent' && preferences.menuAccent !== 'Subtle') {
        throw new UiLibraryThemeDocumentError('Translucent menus require the Subtle menu accent.');
    }
}
export function serializeUiLibraryThemeDocument(document) {
    return `${JSON.stringify(parseUiLibraryThemeDocument(document), null, 2)}\n`;
}
function isRecord(value) {
    return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}
function hasExactKeys(value, expected) {
    const actual = Object.keys(value).sort();
    const sortedExpected = [...expected].sort();
    return actual.length === sortedExpected.length && actual.every((key, index) => key === sortedExpected[index]);
}
