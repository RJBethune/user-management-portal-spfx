import { parseUiLibraryThemeDocument } from './document';
export function parseThemeArtifact(value, expected) {
    const artifact = value;
    if (!artifact ||
        artifact.kind !== 'spfx-kit-theme-artifact' ||
        artifact.version !== 1 ||
        artifact.compilerVersion !== '0.1.0' ||
        !artifact.compatibility ||
        typeof artifact.compatibility.profileId !== 'string' ||
        !artifact.compatibility.profileId ||
        !/^[a-f0-9]{64}$/.test(artifact.compatibility.profileDigest) ||
        !artifact.provenance ||
        !/^(?:[a-f0-9]{40}|[a-f0-9]{64})$/.test(artifact.provenance.revision)) {
        throw new Error('Invalid or unsupported theme artifact.');
    }
    if (expected &&
        (artifact.compatibility.profileId !== expected.profileId || artifact.compatibility.profileDigest !== expected.profileDigest)) {
        throw new Error('Theme artifact does not match the installed component profile.');
    }
    return {
        kind: artifact.kind,
        version: 1,
        compilerVersion: '0.1.0',
        compatibility: { ...artifact.compatibility },
        provenance: { ...artifact.provenance },
        document: parseUiLibraryThemeDocument(artifact.document)
    };
}
