import type { SpfxUiHost, SpfxUiThemeTokens } from '@spfx-kit/ui-profile';
import type { UiLibraryPreviewTheme } from './theme';
/** Apply the same selected profile to controls and their portaled menus. */
export declare function applyCompiledThemeSelection(host: SpfxUiHost, previewTheme: UiLibraryPreviewTheme, invertedTokens: SpfxUiThemeTokens): void;
export declare function applyCompiledTheme(host: SpfxUiHost, previewTheme: UiLibraryPreviewTheme, invertedTokens: SpfxUiThemeTokens): void;
export declare function applyUiLibraryPreviewCssVariables(host: SpfxUiHost, cssVariables: Readonly<Record<string, string>>): void;
export declare function restoreLabUiTheme(host: SpfxUiHost, tokens: SpfxUiThemeTokens): void;
