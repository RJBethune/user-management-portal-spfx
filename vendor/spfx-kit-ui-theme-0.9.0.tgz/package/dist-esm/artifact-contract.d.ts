import { type UiLibraryThemeDocument } from './document';
export interface ThemeCompatibility {
    profileId: string;
    /** Immutable component CSS/profile digest, not an update channel. */
    profileDigest: string;
}
export interface ThemeArtifact {
    kind: 'spfx-kit-theme-artifact';
    version: 1;
    compilerVersion: '0.1.0';
    compatibility: ThemeCompatibility;
    provenance: {
        revision: string;
    };
    document: UiLibraryThemeDocument;
}
export declare function parseThemeArtifact(value: unknown, expected?: ThemeCompatibility): ThemeArtifact;
