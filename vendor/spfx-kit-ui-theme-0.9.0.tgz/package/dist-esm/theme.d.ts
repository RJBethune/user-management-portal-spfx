import { type SpfxUiHost, type SpfxUiThemeTokens } from '@spfx-kit/ui-profile';
import { UI_LIBRARY_BASE_COLOR_NAMES, UI_LIBRARY_CHROMATIC_COLOR_NAMES, UI_LIBRARY_THEME_NAMES, type UiLibraryBaseColorName, type UiLibraryThemeValues, type UiLibraryThemeName } from './ui-library-theme-data';
export declare const BASE_NOVA_FONT_FAMILY = "\"Inter Variable\", -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", \"Noto Sans\", Arial, sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\"";
export { UI_LIBRARY_BASE_COLOR_NAMES, UI_LIBRARY_CHROMATIC_COLOR_NAMES, UI_LIBRARY_THEME_NAMES };
export type { UiLibraryBaseColorName, UiLibraryThemeName };
export declare const UI_LIBRARY_ICON_LIBRARY_NAMES: readonly ["Lucide", "Tabler Icons", "HugeIcons", "Phosphor Icons", "Remix Icon"];
export declare const UI_LIBRARY_STYLE_NAMES: readonly ["Vega", "Nova", "Maia", "Lyra", "Mira", "Luma"];
export declare const UI_LIBRARY_RADIUS_NAMES: readonly ["Default", "None", "Small", "Medium", "Large"];
export declare const UI_LIBRARY_CORNER_SHAPE_NAMES: readonly ["Default", "Squircle"];
export declare const UI_LIBRARY_MENU_COLOR_NAMES: readonly ["Default", "Inverted"];
export declare const UI_LIBRARY_MENU_APPEARANCE_NAMES: readonly ["Solid", "Translucent"];
export declare const UI_LIBRARY_MENU_ACCENT_NAMES: readonly ["Subtle", "Bold"];
export declare const UI_LIBRARY_THEME_MODES: readonly ["light", "dark"];
export type UiLibraryIconLibraryName = (typeof UI_LIBRARY_ICON_LIBRARY_NAMES)[number];
export type UiLibraryStyleName = (typeof UI_LIBRARY_STYLE_NAMES)[number];
export type UiLibraryRadiusName = (typeof UI_LIBRARY_RADIUS_NAMES)[number];
export type UiLibraryCornerShapeName = (typeof UI_LIBRARY_CORNER_SHAPE_NAMES)[number];
export type UiLibraryMenuColorName = (typeof UI_LIBRARY_MENU_COLOR_NAMES)[number];
export type UiLibraryMenuAppearanceName = (typeof UI_LIBRARY_MENU_APPEARANCE_NAMES)[number];
export type UiLibraryMenuAccentName = (typeof UI_LIBRARY_MENU_ACCENT_NAMES)[number];
export type UiLibraryThemeMode = (typeof UI_LIBRARY_THEME_MODES)[number];
export type UiLibraryChartColors = readonly [string, string, string, string, string];
export declare const uiLibraryFontFamilies: Readonly<Record<string, string>>;
export interface UiLibraryBaseSurface {
    border: string;
    muted: string;
    foreground: string;
}
export declare const uiLibraryAccentColors: Readonly<Record<string, string>>;
export declare const uiLibraryBaseSurfaces: Readonly<Record<string, UiLibraryBaseSurface>>;
export interface UiLibraryPreviewThemeSelection {
    style: string;
    baseColor: string;
    theme: string;
    chartColor: string;
    font: string;
    fontHeading: string;
    fontMono: string;
    iconLibrary: string;
    radius: string;
    cornerShape: string;
    menuColor: string;
    menuAppearance: string;
    menuAccent: string;
}
export interface UiLibraryNormalizedPreviewThemeSelection {
    style: UiLibraryStyleName;
    baseColor: UiLibraryBaseColorName;
    theme: UiLibraryThemeName;
    chartColor: UiLibraryThemeName;
    font: string;
    fontHeading: string;
    fontMono: string;
    iconLibrary: UiLibraryIconLibraryName;
    radius: UiLibraryRadiusName;
    cornerShape: UiLibraryCornerShapeName;
    menuColor: UiLibraryMenuColorName;
    menuAppearance: UiLibraryMenuAppearanceName;
    menuAccent: UiLibraryMenuAccentName;
}
export declare const DEFAULT_UI_LIBRARY_PREVIEW_THEME_NAME = "Svelte";
/**
 * Fallback for axes missing from previously saved selections. Saved data predates
 * the Svelte default, so its omitted values keep their original meaning.
 */
export declare const LEGACY_UI_LIBRARY_PREVIEW_THEME_FALLBACK: UiLibraryNormalizedPreviewThemeSelection;
export declare const DEFAULT_UI_LIBRARY_PREVIEW_THEME_SELECTION: UiLibraryNormalizedPreviewThemeSelection;
export interface UiLibraryPreviewTheme {
    mode: UiLibraryThemeMode;
    selection: UiLibraryNormalizedPreviewThemeSelection;
    tokens: SpfxUiThemeTokens;
    cssVariables: Readonly<Record<string, string>>;
    fontBody: string;
    fontHeading: string;
    fontMono: string;
    chartColors: UiLibraryChartColors;
    /** @deprecated Prefer chartColors. This aliases the selected palette's chart-4 value. */
    chartColor: string;
}
export interface UiLibraryRegistryTheme {
    name: string;
    selection: UiLibraryNormalizedPreviewThemeSelection;
    cssVars: Readonly<{
        light: UiLibraryThemeValues;
        dark: UiLibraryThemeValues;
    }>;
}
export declare function getUiLibraryThemeNamesForBaseColor(baseColor: UiLibraryBaseColorName): readonly UiLibraryThemeName[];
export declare function normalizeUiLibraryPreviewThemeSelection(selection: Partial<UiLibraryPreviewThemeSelection>, defaults?: UiLibraryNormalizedPreviewThemeSelection): UiLibraryNormalizedPreviewThemeSelection;
/**
 * Mirrors shadcn/ui's buildRegistryTheme merge order at the pinned Create
 * registry revision. Dark values intentionally omit radius and inherit it from
 * the light/root rule when the preview resolves the active mode.
 */
export declare function buildUiLibraryRegistryTheme(selection: Partial<UiLibraryPreviewThemeSelection>): UiLibraryRegistryTheme;
export declare function createBaseNovaUiThemeTokens(mode?: UiLibraryThemeMode): SpfxUiThemeTokens;
export declare function createUiLibraryPreviewTheme(selection: Partial<UiLibraryPreviewThemeSelection>, mode?: UiLibraryThemeMode): UiLibraryPreviewTheme;
export declare function createUiLibraryInvertedMenuThemeTokens(selection: Partial<UiLibraryPreviewThemeSelection>, activeMode: UiLibraryThemeMode): SpfxUiThemeTokens;
export declare function applyUiLibraryPreviewTheme(host: SpfxUiHost, tokens: SpfxUiThemeTokens): void;
export { applyUiLibraryPreviewCssVariables, restoreLabUiTheme } from './runtime-theme';
export declare function applyUiLibraryThemeSelection(host: SpfxUiHost, previewTheme: UiLibraryPreviewTheme): void;
export declare function applyUiLibraryTheme(host: SpfxUiHost, previewTheme: UiLibraryPreviewTheme): void;
