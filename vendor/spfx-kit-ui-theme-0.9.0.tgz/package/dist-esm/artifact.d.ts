import { type SpfxUiHost } from '@spfx-kit/ui-profile';
import type { UiLibraryThemeDocument } from './document';
export { parseThemeArtifact } from './artifact-contract';
export type { ThemeArtifact, ThemeCompatibility } from './artifact-contract';
import { type ThemeArtifact, type ThemeCompatibility } from './artifact-contract';
export declare function createThemeArtifact(document: UiLibraryThemeDocument, options: ThemeCompatibility & {
    revision: string;
}): ThemeArtifact;
export declare function applyThemeArtifact(host: SpfxUiHost, artifact: ThemeArtifact, mode: 'light' | 'dark', compatibility: ThemeCompatibility): void;
export interface PinnedThemeOptions {
    url: string;
    /** SHA-256 of the exact UTF-8 JSON file. */
    sha256: string;
    fallback: ThemeArtifact;
    compatibility: ThemeCompatibility;
    signal?: AbortSignal;
    timeoutMs?: number;
    fetch?: typeof fetch;
}
/** Resolve before applying: failed delivery never mutates the currently styled host. */
export declare function resolvePinnedTheme(options: PinnedThemeOptions): Promise<{
    artifact: ThemeArtifact;
    source: 'cdn' | 'bundled';
}>;
