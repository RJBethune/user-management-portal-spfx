export interface ThemeFontOption {
    label: string;
    value: string;
}
export interface ThemeFontOptionGroup {
    label: string;
    options: readonly ThemeFontOption[];
}
export declare const THEME_FONT_GROUPS: readonly ThemeFontOptionGroup[];
export declare const THEME_MONO_FONT_GROUPS: readonly ThemeFontOptionGroup[];
export declare const THEME_ALL_FONT_GROUPS: readonly ThemeFontOptionGroup[];
export declare const THEME_FONT_FAMILIES: Readonly<Record<string, string>>;
export declare function getThemeFontValue(name: string): string;
