export * from './index';
import { parseThemeArtifact } from './artifact-contract';
import { createUiLibraryPreviewTheme } from './theme';
import { parseCompiledThemeArtifact } from './compiled-artifact';
/** Compile at packaging/editor time; no preference subset is imposed. */
export function compileThemeArtifact(value) {
    const artifact = parseThemeArtifact(value);
    return parseCompiledThemeArtifact({
        ...artifact,
        version: 2,
        compiled: {
            light: createUiLibraryPreviewTheme(artifact.document.preferences, 'light'),
            dark: createUiLibraryPreviewTheme(artifact.document.preferences, 'dark')
        }
    });
}
