export declare const UI_LIBRARY_THEME_DOCUMENT_KIND: "spfx-kit-ui-library-theme";
export declare const UI_LIBRARY_THEME_DOCUMENT_VERSION: 1;
export declare const UI_LIBRARY_THEME_DOCUMENT_ID_PATTERN: RegExp;
export interface UiLibraryThemeDocument {
    kind: typeof UI_LIBRARY_THEME_DOCUMENT_KIND;
    version: typeof UI_LIBRARY_THEME_DOCUMENT_VERSION;
    id: string;
    name: string;
    preferences: UiLibraryThemeDocumentPreferences;
}
export interface UiLibraryThemeDocumentPreferences {
    style: 'Vega' | 'Nova' | 'Maia' | 'Lyra' | 'Mira' | 'Luma';
    baseColor: 'Neutral' | 'Stone' | 'Zinc' | 'Mauve' | 'Olive' | 'Mist' | 'Taupe';
    theme: UiLibraryThemeDocumentPreferences['baseColor'] | 'Amber' | 'Blue' | 'Cyan' | 'Emerald' | 'Fuchsia' | 'Green' | 'Indigo' | 'Lime' | 'Orange' | 'Pink' | 'Purple' | 'Red' | 'Rose' | 'Sky' | 'Teal' | 'Violet' | 'Yellow';
    chartColor: UiLibraryThemeDocumentPreferences['theme'];
    font: string;
    fontHeading: string;
    fontMono: string;
    iconLibrary: 'Lucide' | 'Tabler Icons' | 'HugeIcons' | 'Phosphor Icons' | 'Remix Icon';
    radius: 'Default' | 'None' | 'Small' | 'Medium' | 'Large';
    cornerShape: 'Default' | 'Squircle';
    menuColor: 'Default' | 'Inverted';
    menuAppearance: 'Solid' | 'Translucent';
    menuAccent: 'Subtle' | 'Bold';
}
export interface UiLibraryRemoteTheme {
    document: UiLibraryThemeDocument;
    revision: string;
}
export declare class UiLibraryThemeDocumentError extends Error {
}
export declare function createUiLibraryThemeDocument(input: {
    id: string;
    name: string;
    preferences: UiLibraryThemeDocumentPreferences;
}): UiLibraryThemeDocument;
export declare function parseUiLibraryThemeDocument(value: unknown): UiLibraryThemeDocument;
export declare function serializeUiLibraryThemeDocument(document: UiLibraryThemeDocument): string;
