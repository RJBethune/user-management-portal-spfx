import { isSpfxUiStyleShipped } from '@spfx-kit/ui-profile';
import { parseThemeArtifact } from './artifact-contract';
import { applyCompiledThemeSelection } from './runtime-theme';
const tokenKeys = [
    'colorBackground',
    'colorForeground',
    'colorCard',
    'colorCardForeground',
    'colorPopover',
    'colorPopoverForeground',
    'colorPrimary',
    'colorPrimaryForeground',
    'colorSecondary',
    'colorSecondaryForeground',
    'colorMuted',
    'colorMutedForeground',
    'colorAccent',
    'colorAccentForeground',
    'colorDestructive',
    'colorBorder',
    'colorInput',
    'colorRing',
    'radiusSm',
    'radiusMd',
    'radiusLg',
    'radiusXl',
    'fontHeading',
    'fontMono'
];
function cssValue(value) {
    // Control characters are rejected on purpose: compiled values are written into inline styles.
    if (typeof value !== 'string' ||
        !value.trim() ||
        value.length > 2048 ||
        // eslint-disable-next-line no-control-regex
        /[;{}<>\x00-\x1f]|(?:url|expression)\s*\(|@import/i.test(value))
        throw new Error('Invalid compiled CSS value.');
    return value;
}
function parseSnapshot(value, mode, artifact) {
    const snapshot = value;
    if (!snapshot ||
        snapshot.mode !== mode ||
        !snapshot.tokens ||
        snapshot.tokens.mode !== mode ||
        !snapshot.selection ||
        Object.keys(artifact.document.preferences).some((key) => snapshot.selection[key] !==
            artifact.document.preferences[key])) {
        throw new Error('Compiled theme selection or mode mismatch.');
    }
    const tokens = { mode };
    for (const key of tokenKeys)
        tokens[key] = cssValue(snapshot.tokens[key]);
    if (!snapshot.cssVariables ||
        typeof snapshot.cssVariables !== 'object' ||
        Array.isArray(snapshot.cssVariables) ||
        Object.keys(snapshot.cssVariables).length > 128)
        throw new Error('Invalid compiled CSS variables.');
    const cssVariables = {};
    for (const [name, value] of Object.entries(snapshot.cssVariables)) {
        if (!/^--[a-z][a-z0-9-]{0,100}$/.test(name))
            throw new Error('Invalid compiled CSS variable name.');
        cssVariables[name] = cssValue(value);
    }
    if (!Array.isArray(snapshot.chartColors) || snapshot.chartColors.length !== 5)
        throw new Error('Invalid compiled chart colors.');
    const chartColors = snapshot.chartColors.map(cssValue);
    return {
        mode,
        selection: { ...artifact.document.preferences },
        tokens,
        cssVariables,
        fontBody: cssValue(snapshot.fontBody),
        fontHeading: cssValue(snapshot.fontHeading),
        fontMono: cssValue(snapshot.fontMono),
        chartColors,
        chartColor: chartColors[3]
    };
}
export function parseCompiledThemeArtifact(value, expected) {
    const input = value;
    if (!input || input.version !== 2 || !input.compiled)
        throw new Error('Expected compiled theme artifact version 2.');
    const artifact = parseThemeArtifact({ ...input, version: 1 }, expected);
    return {
        ...artifact,
        version: 2,
        compiled: {
            light: parseSnapshot(input.compiled.light, 'light', artifact),
            dark: parseSnapshot(input.compiled.dark, 'dark', artifact)
        }
    };
}
export function applyCompiledThemeArtifact(host, value, mode, compatibility) {
    const artifact = parseCompiledThemeArtifact(value, compatibility);
    if (host.profileId !== compatibility.profileId)
        throw new Error('Theme host profile differs from artifact profile.');
    applyCompiledThemeSelection(host, artifact.compiled[mode], artifact.compiled[mode === 'light' ? 'dark' : 'light'].tokens);
}
export async function resolvePinnedCompiledTheme(options) {
    const fallback = parseCompiledThemeArtifact(options.fallback, options.compatibility);
    const controller = new AbortController();
    const abort = () => controller.abort();
    options.signal?.addEventListener('abort', abort, { once: true });
    if (options.signal?.aborted)
        controller.abort();
    const timer = setTimeout(abort, Math.min(Math.max(options.timeoutMs ?? 5000, 1), 30000));
    try {
        const url = new URL(options.url);
        if ((url.protocol !== 'https:' && !(url.protocol === 'http:' && ['127.0.0.1', 'localhost'].includes(url.hostname))) ||
            url.username ||
            url.password ||
            !/^[a-f0-9]{64}$/.test(options.sha256))
            throw new Error('Invalid theme pin.');
        const response = await (options.fetch ?? fetch)(url.href, {
            signal: controller.signal,
            credentials: 'omit',
            redirect: 'error'
        });
        if (!response.ok)
            throw new Error('Theme unavailable.');
        const raw = await response.text();
        if (raw.length > 65536)
            throw new Error('Theme exceeds maximum size.');
        const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(raw));
        if (Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, '0')).join('') !== options.sha256)
            throw new Error('Theme integrity mismatch.');
        const value = JSON.parse(raw);
        const legacy = value?.version === 1 ? parseThemeArtifact(value, options.compatibility) : undefined;
        const artifact = parseCompiledThemeArtifact(legacy && options.compileLegacy ? await options.compileLegacy(legacy) : value, options.compatibility);
        if (legacy && JSON.stringify(artifact.document) !== JSON.stringify(legacy.document))
            throw new Error('Legacy adapter changed the document.');
        const assets = ['font', 'fontHeading', 'fontMono', 'iconLibrary'];
        if (assets.some((key) => artifact.document.preferences[key] !== fallback.document.preferences[key]))
            throw new Error('Theme requires different bundled assets.');
        // A trimmed bundle omits unshipped style recipes: a theme naming one needs a package update too.
        if (!isSpfxUiStyleShipped(String(artifact.document.preferences.style).toLowerCase()))
            throw new Error('Theme requires a style this bundle does not ship.');
        if (controller.signal.aborted)
            throw new Error('Theme request aborted.');
        return { artifact, source: 'cdn' };
    }
    catch {
        return { artifact: fallback, source: 'bundled' };
    }
    finally {
        clearTimeout(timer);
        options.signal?.removeEventListener('abort', abort);
    }
}
