import { type SpfxUiHost } from '@spfx-kit/ui-profile';
import { type ThemeArtifact, type ThemeCompatibility } from './artifact-contract';
import type { UiLibraryPreviewTheme } from './theme';
/** Opt-in build output. V1 documents remain supported by the compiler entry. */
export interface CompiledThemeArtifact extends Omit<ThemeArtifact, 'version'> {
    version: 2;
    compiled: {
        light: UiLibraryPreviewTheme;
        dark: UiLibraryPreviewTheme;
    };
}
export declare function parseCompiledThemeArtifact(value: unknown, expected?: ThemeCompatibility): CompiledThemeArtifact;
export declare function applyCompiledThemeArtifact(host: SpfxUiHost, value: CompiledThemeArtifact, mode: 'light' | 'dark', compatibility: ThemeCompatibility): void;
export interface PinnedCompiledThemeOptions {
    url: string;
    sha256: string;
    fallback: CompiledThemeArtifact;
    compatibility: ThemeCompatibility;
    signal?: AbortSignal;
    timeoutMs?: number;
    fetch?: typeof fetch;
    /** Explicit, optionally lazy adapter preserves legacy V1 remote document support. */
    compileLegacy?: (artifact: ThemeArtifact) => CompiledThemeArtifact | Promise<CompiledThemeArtifact>;
}
export declare function resolvePinnedCompiledTheme(options: PinnedCompiledThemeOptions): Promise<{
    artifact: CompiledThemeArtifact;
    source: 'cdn' | 'bundled';
}>;
