const fontOptions = (...values) => values.map((value) => ({ label: value, value }));
export const THEME_FONT_GROUPS = [
    {
        label: 'Sans',
        options: fontOptions('System Sans', 'Arial', 'Open Sans', 'Segoe UI', 'Helvetica Neue', 'Inter', 'Geist', 'DM Sans')
    },
    {
        label: 'Serif',
        options: fontOptions('System Serif', 'Times New Roman', 'EB Garamond', 'DM Serif Display', 'Playfair Display', 'Noto Serif', 'Merriweather')
    }
];
export const THEME_MONO_FONT_GROUPS = [
    {
        label: 'Mono',
        options: fontOptions('System Mono', 'Courier New', 'IBM Plex Mono', 'OCR', 'DM Mono', 'Geist Mono')
    }
];
export const THEME_ALL_FONT_GROUPS = [...THEME_FONT_GROUPS, ...THEME_MONO_FONT_GROUPS];
export const THEME_FONT_FAMILIES = {
    'System Sans': 'ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    Arial: 'Arial, "Helvetica Neue", Helvetica, sans-serif',
    'Open Sans': '"Open Sans Variable", "Open Sans", Arial, sans-serif',
    'Segoe UI': '"Segoe UI", SegoeUI, Roboto, "Helvetica Neue", Arial, sans-serif',
    'Helvetica Neue': '"Helvetica Neue", Helvetica, Arial, sans-serif',
    Inter: 'InterVariable, Inter, "InterVariable Fallback Segoe UI", "InterVariable Fallback Arial", "Segoe UI", sans-serif',
    Geist: '"Geist Variable", Geist, "Segoe UI", sans-serif',
    'DM Sans': '"DM Sans Variable", "DM Sans", "Segoe UI", sans-serif',
    'System Serif': 'ui-serif, Georgia, Cambria, "Times New Roman", serif',
    'Times New Roman': '"Times New Roman", Times, serif',
    'EB Garamond': '"EB Garamond Variable", "EB Garamond", Georgia, serif',
    'DM Serif Display': '"DM Serif Display", Georgia, serif',
    'Playfair Display': '"Playfair Display Variable", "Playfair Display", Georgia, serif',
    'Noto Serif': '"Noto Serif Variable", "Noto Serif", Georgia, serif',
    Merriweather: '"Merriweather Variable", Merriweather, Georgia, serif',
    'System Mono': 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace',
    'Courier New': '"Courier New", Courier, monospace',
    'IBM Plex Mono': '"IBM Plex Mono", ui-monospace, monospace',
    OCR: '"OCR A Std", "OCR A Extended", "OCR B Std", ui-monospace, monospace',
    'DM Mono': '"DM Mono", ui-monospace, monospace',
    'Geist Mono': '"Geist Mono Variable", "Geist Mono", "Geist Mono Fallback Consolas", "Geist Mono Fallback Menlo", "Geist Mono Fallback Courier New", ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace'
};
export function getThemeFontValue(name) {
    return name
        .toLocaleLowerCase()
        .replace(/[^a-z0-9]+/gu, '-')
        .replace(/^-|-$/gu, '');
}
