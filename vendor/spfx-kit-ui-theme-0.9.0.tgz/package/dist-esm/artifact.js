import { isSpfxUiStyleShipped } from '@spfx-kit/ui-profile';
import { createUiLibraryPreviewTheme, applyUiLibraryThemeSelection } from './theme';
export { parseThemeArtifact } from './artifact-contract';
import { parseThemeArtifact } from './artifact-contract';
export function createThemeArtifact(document, options) {
    return parseThemeArtifact({
        kind: 'spfx-kit-theme-artifact',
        version: 1,
        compilerVersion: '0.1.0',
        compatibility: { profileId: options.profileId, profileDigest: options.profileDigest },
        provenance: { revision: options.revision },
        document
    });
}
export function applyThemeArtifact(host, artifact, mode, compatibility) {
    const validated = parseThemeArtifact(artifact, compatibility);
    if (host.profileId !== compatibility.profileId)
        throw new Error('Theme host profile differs from artifact profile.');
    applyUiLibraryThemeSelection(host, createUiLibraryPreviewTheme(validated.document.preferences, mode));
}
/** Resolve before applying: failed delivery never mutates the currently styled host. */
export async function resolvePinnedTheme(options) {
    const fallback = parseThemeArtifact(options.fallback, options.compatibility);
    const controller = new AbortController();
    const abort = () => controller.abort();
    options.signal?.addEventListener('abort', abort, { once: true });
    if (options.signal?.aborted)
        controller.abort();
    const timeout = setTimeout(abort, Math.min(Math.max(options.timeoutMs ?? 5000, 1), 30000));
    try {
        const url = new URL(options.url);
        if (url.protocol !== 'https:' && !(url.protocol === 'http:' && ['127.0.0.1', 'localhost'].includes(url.hostname)))
            throw new Error('Theme CDN requires HTTPS.');
        if (url.username || url.password || !/^[a-f0-9]{64}$/.test(options.sha256))
            throw new Error('Invalid theme pin.');
        const response = await (options.fetch ?? fetch)(url.href, {
            signal: controller.signal,
            credentials: 'omit',
            redirect: 'error'
        });
        if (!response.ok)
            throw new Error('Theme unavailable.');
        const raw = await response.text();
        if (raw.length > 65536)
            throw new Error('Theme exceeds maximum size.');
        const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(raw));
        const hash = Array.from(new Uint8Array(bytes), (byte) => byte.toString(16).padStart(2, '0')).join('');
        if (hash !== options.sha256)
            throw new Error('Theme integrity mismatch.');
        const artifact = parseThemeArtifact(JSON.parse(raw), options.compatibility);
        // A pin can vary settings only within the bundled asset set. Additional
        // fonts/icon implementations require a component/theme package update.
        const keys = ['font', 'fontHeading', 'fontMono', 'iconLibrary'];
        if (keys.some((key) => artifact.document.preferences[key] !== fallback.document.preferences[key]))
            throw new Error('Theme requires different bundled assets.');
        // A trimmed bundle omits unshipped style recipes: a theme naming one needs a package update too.
        if (!isSpfxUiStyleShipped(String(artifact.document.preferences.style).toLowerCase()))
            throw new Error('Theme requires a style this bundle does not ship.');
        return { artifact, source: 'cdn' };
    }
    catch {
        return { artifact: fallback, source: 'bundled' };
    }
    finally {
        clearTimeout(timeout);
        options.signal?.removeEventListener('abort', abort);
    }
}
