import { clearSharePointSvelteLayer } from './sharepoint-svelte-layer';
import { SPFX_UI_DEFAULT_STYLE, SPFX_UI_DEFAULT_MENU_APPEARANCE, SPFX_UI_DEFAULT_MENU_COLOR } from '@spfx-kit/ui-profile';
const chartTokenNames = ['--chart-1', '--chart-2', '--chart-3', '--chart-4', '--chart-5'];
const previewThemeVariableNames = new WeakMap();
/** Apply the same selected profile to controls and their portaled menus. */
export function applyCompiledThemeSelection(host, previewTheme, invertedTokens) {
    const { selection } = previewTheme;
    applyCompiledTheme(host, previewTheme, invertedTokens);
    for (const surface of [host.appRoot, host.portalHost]) {
        surface.dataset.shadcnPreviewBaseColor = selection.baseColor.toLocaleLowerCase();
        surface.dataset.shadcnPreviewMenuColor = selection.menuColor.toLocaleLowerCase();
        surface.dataset.shadcnPreviewMenuAppearance = selection.menuAppearance.toLocaleLowerCase();
        surface.dataset.shadcnPreviewMenuAccent = selection.menuAccent.toLocaleLowerCase();
        surface.dataset.shadcnPreviewIconLibrary = selection.iconLibrary === 'HugeIcons' ? 'hugeicons' : 'lucide';
    }
}
export function applyCompiledTheme(host, previewTheme, invertedTokens) {
    const { selection } = previewTheme;
    // Applying a style always starts from plain Svelte: a SharePoint layer is reapplied after it.
    clearSharePointSvelteLayer(host);
    for (const surface of [host.appRoot, host.portalHost])
        surface.setAttribute('data-spfx-ui-theme-package', '1');
    host.applyTheme(previewTheme.tokens);
    host.applyStyle(selection.style.toLocaleLowerCase());
    host.applyMenuAppearance(selection.menuAppearance.toLocaleLowerCase());
    host.applyInvertedMenuTheme(invertedTokens);
    host.applyMenuColor(selection.menuColor.toLocaleLowerCase());
    applyUiLibraryPreviewCssVariables(host, previewTheme.cssVariables);
    for (const surface of [host.appRoot, host.portalHost]) {
        surface.style.setProperty('--ui-library-theming-font-body', previewTheme.fontBody);
        surface.style.fontFamily = 'var(--ui-library-theming-font-body)';
    }
}
export function applyUiLibraryPreviewCssVariables(host, cssVariables) {
    const names = previewThemeVariableNames.get(host) ?? new Set();
    previewThemeVariableNames.set(host, names);
    for (const surface of [host.appRoot, host.portalHost]) {
        for (const [name, value] of Object.entries(cssVariables)) {
            surface.style.setProperty(name, value);
            names.add(name);
        }
    }
}
export function restoreLabUiTheme(host, tokens) {
    clearSharePointSvelteLayer(host);
    host.applyTheme(tokens);
    host.applyStyle(SPFX_UI_DEFAULT_STYLE);
    host.applyMenuAppearance(SPFX_UI_DEFAULT_MENU_APPEARANCE);
    host.applyInvertedMenuTheme(tokens);
    host.applyMenuColor(SPFX_UI_DEFAULT_MENU_COLOR);
    for (const surface of [host.appRoot, host.portalHost]) {
        for (const tokenName of previewThemeVariableNames.get(host) ?? [])
            surface.style.removeProperty(tokenName);
        for (const tokenName of chartTokenNames)
            surface.style.removeProperty(tokenName);
        surface.style.removeProperty('--ui-library-theming-font-body');
        surface.style.removeProperty('font-family');
        surface.removeAttribute('data-spfx-ui-theme-package');
        delete surface.dataset.shadcnPreviewBaseColor;
        delete surface.dataset.shadcnPreviewMenuColor;
        delete surface.dataset.shadcnPreviewMenuAppearance;
        delete surface.dataset.shadcnPreviewMenuAccent;
        delete surface.dataset.shadcnPreviewIconLibrary;
    }
    previewThemeVariableNames.delete(host);
}
