export * from './index';
import { type ThemeArtifact } from './artifact-contract';
import { type CompiledThemeArtifact } from './compiled-artifact';
/** Compile at packaging/editor time; no preference subset is imposed. */
export declare function compileThemeArtifact(value: ThemeArtifact): CompiledThemeArtifact;
