import { mapSharePointTheme } from '@spfx-kit/ui-profile';
/**
 * The SharePoint theme over Svelte.
 *
 * Every Kit app builds on the Svelte style document (Luma). An app's SharePoint
 * theme is the thinnest data-only mapping on top of it: the site's palette and
 * font, Fluent-like corners and 32px control density. It is Kit tokens plus a few
 * CSS custom properties, never per-component CSS. Light and Dark stay plain Svelte.
 */
/** SharePoint's default type stack (Fluent's `fontFamilyBase`), used when the site sets no font. */
export const SHAREPOINT_FONT_STACK = '"Segoe UI", "Segoe UI Web (West European)", -apple-system, BlinkMacSystemFont, Roboto, "Helvetica Neue", sans-serif';
/** Fluent's control height. Luma's controls are nine spacing units (36px) tall. */
export const SHAREPOINT_CONTROL_HEIGHT_PX = 32;
const LUMA_CONTROL_HEIGHT_UNITS = 9;
/** Fluent's corner radius for buttons, fields, selects, tabs, badges and menu items. */
export const SHAREPOINT_CONTROL_RADIUS = '4px';
/** Fluent's dialog surface width. Luma sizes dialogs only with `--skui-container-md`. */
export const SHAREPOINT_DIALOG_WIDTH = '600px';
/** CSS custom property carrying SharePoint's 3:1 `inputBorder` stroke for app stylesheets. */
export const SHAREPOINT_INPUT_BORDER_VARIABLE = '--spfx-ui-sharepoint-input-border';
function parseColor(color) {
    const value = color.trim();
    const hex = value.replace(/^#/u, '');
    if (value.startsWith('#') && /^[\da-f]{3}$/iu.test(hex))
        return hex.split('').map((c) => parseInt(c + c, 16));
    if (value.startsWith('#') && /^[\da-f]{6}$/iu.test(hex))
        return [0, 2, 4].map((i) => parseInt(hex.slice(i, i + 2), 16));
    const match = /^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/iu.exec(value);
    return match ? match.slice(1, 4).map(Number) : undefined;
}
function toHex(rgb) {
    return `#${rgb
        .map((c) => Math.round(Math.min(255, Math.max(0, c)))
        .toString(16)
        .padStart(2, '0'))
        .join('')}`;
}
function luminance(rgb) {
    const [r, g, b] = rgb.map((value) => {
        const c = value / 255;
        return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
    });
    return r * 0.2126 + g * 0.7152 + b * 0.0722;
}
function contrast(a, b) {
    const [high, low] = [luminance(a), luminance(b)].sort((x, y) => y - x);
    return (high + 0.05) / (low + 0.05);
}
/** `amount` of `foreground` over `background`, in hex when both parse, else as CSS `color-mix`. */
function mix(background, foreground, amount) {
    const from = parseColor(background);
    const to = parseColor(foreground);
    if (!from || !to)
        return `color-mix(in srgb, ${foreground} ${Math.round(amount * 100)}%, ${background})`;
    return toHex(from.map((c, i) => c + (to[i] - c) * amount));
}
const WHITE = [255, 255, 255];
const BLACK = [0, 0, 0];
/**
 * Move `color` toward black or white until it reaches `ratio` on every background.
 * The first background picks the direction. Unparseable colours pass through.
 */
function readable(color, background, ratio = 4.5) {
    const base = parseColor(color);
    const surfaces = (typeof background === 'string' ? [background] : background).map(parseColor);
    if (!base || surfaces.length === 0 || surfaces.some((surface) => !surface))
        return color;
    const parsed = surfaces;
    const target = contrast(WHITE, parsed[0]) >= contrast(BLACK, parsed[0]) ? WHITE : BLACK;
    for (let step = 0; step <= 20; step++) {
        const candidate = base.map((c, i) => c + (target[i] - c) * (step / 20));
        if (parsed.every((surface) => contrast(candidate, surface) >= ratio))
            return step === 0 ? color : toHex(candidate);
    }
    return toHex(target);
}
function onColor(background) {
    const surface = parseColor(background);
    if (!surface)
        return '#ffffff';
    return contrast(WHITE, surface) >= contrast(BLACK, surface) ? '#ffffff' : '#000000';
}
function isTokens(source) {
    return typeof source.colorBackground === 'string' && 'mode' in source;
}
function isResolved(source) {
    return source?.kind === 'spfx-kit-sharepoint-site-theme';
}
// mapSharePointTheme prefixes the site font with the Kit's Inter; SharePoint itself uses the site font.
const MAPPED_FONT_PREFIX = /^\s*"Inter Variable"\s*,\s*/u;
function inputFillFor(background, foreground, mode) {
    return mix(background, foreground, mode === 'dark' ? 0.15 : 0.1);
}
/**
 * Complete a (possibly partial) SPFx theme so `mapSharePointTheme` has every slot,
 * with muted text at 4.5:1 and the input stroke at 3:1 on the site surface.
 */
function completeSharePointTheme(source) {
    const p = source.palette ?? {};
    const s = source.semanticColors ?? {};
    const supplied = s.bodyBackground || p.white;
    const suppliedRgb = supplied ? parseColor(supplied) : undefined;
    const dark = source.isInverted ?? (suppliedRgb ? luminance(suppliedRgb) < 0.18 : false);
    const background = supplied || (dark ? '#292929' : '#ffffff');
    const foreground = s.bodyText || p.neutralPrimary || (dark ? '#ffffff' : '#242424');
    const brand = p.themePrimary || '#0078d4'; // SharePoint's default theme accent
    const onBrand = onColor(brand);
    const muted = readable(p.neutralSecondary || mix(background, foreground, 0.7), background);
    const divider = s.bodyDivider || p.neutralLight || mix(background, foreground, 0.12);
    const inputBorder = readable(s.inputBorder || p.neutralSecondary || mix(background, foreground, 0.55), background, 3);
    const standout = p.neutralLighter || mix(background, foreground, 0.04);
    const accent = s.buttonBackgroundHovered || p.themeLighter || mix(background, brand, 0.12);
    const buttonBackground = s.buttonBackground || standout;
    const destructive = p.redDark || (dark ? '#f1707b' : '#a4262c'); // SharePoint's default redDark
    const primaryText = s.primaryButtonText;
    const primaryRgb = parseColor(brand);
    const primaryTextRgb = primaryText ? parseColor(primaryText) : undefined;
    return {
        isInverted: dark,
        palette: {
            white: background,
            neutralPrimary: foreground,
            neutralSecondary: muted,
            neutralLight: divider,
            neutralLighter: standout,
            neutralLighterAlt: p.neutralLighterAlt || standout,
            themePrimary: brand,
            themeDarkAlt: readable(p.themeDarkAlt || brand, accent),
            themeLighter: accent,
            redDark: destructive
        },
        semanticColors: {
            bodyBackground: background,
            bodyText: foreground,
            bodyDivider: divider,
            buttonBackground,
            buttonBackgroundHovered: accent,
            buttonText: readable(s.buttonText || foreground, buttonBackground),
            buttonTextHovered: readable(s.buttonTextHovered || p.themeDarkAlt || foreground, accent),
            disabledBackground: s.disabledBackground || standout,
            // The Kit maps disabledText to muted text; keep it readable for body copy.
            disabledText: muted,
            errorText: readable(s.errorText || destructive, background),
            focusBorder: s.focusBorder || (primaryRgb && contrast(primaryRgb, parseColor(background) ?? WHITE) >= 3 ? brand : foreground),
            inputBorder,
            primaryButtonText: primaryText && (!primaryRgb || !primaryTextRgb || contrast(primaryTextRgb, primaryRgb) >= 4.5) ? primaryText : onBrand
        },
        fonts: source.fonts
    };
}
/**
 * Resolve a SharePoint site theme for the layer. Accepts the SPFx theme object
 * (partial palettes are completed and contrast-checked) or `mapSharePointTheme`
 * output. A theme with no palette and no semantic colours resolves without a
 * palette, so the layer keeps the Svelte colours.
 */
export function resolveSharePointSiteTheme(source) {
    if (isResolved(source))
        return source;
    if (isTokens(source)) {
        const siteFont = source.fontHeading.replace(MAPPED_FONT_PREFIX, '').trim();
        return {
            kind: 'spfx-kit-sharepoint-site-theme',
            mode: source.mode,
            palette: source,
            inputFill: inputFillFor(source.colorBackground, source.colorForeground, source.mode),
            inputBorder: source.colorInput,
            fontFamily: siteFont || SHAREPOINT_FONT_STACK
        };
    }
    const fontFamily = source.fonts?.medium?.fontFamily?.trim() || SHAREPOINT_FONT_STACK;
    if (!source.palette && !source.semanticColors) {
        return { kind: 'spfx-kit-sharepoint-site-theme', mode: source.isInverted ? 'dark' : 'light', fontFamily };
    }
    const completed = completeSharePointTheme(source);
    const palette = mapSharePointTheme(completed);
    return {
        kind: 'spfx-kit-sharepoint-site-theme',
        mode: palette.mode,
        palette,
        inputFill: inputFillFor(palette.colorBackground, palette.colorForeground, palette.mode),
        inputBorder: completed.semanticColors?.inputBorder,
        fontFamily
    };
}
/**
 * Svelte's colour roles: the shadcn CSS variables (`--primary`, `--muted-foreground`,
 * ...) that app styles and Kit components read next to the Kit tokens. The SharePoint
 * layer maps every one to the site palette. Svelte's chart colours are a data palette,
 * not a brand role, so they stay Svelte's.
 */
export const SVELTE_COLOR_ROLES = [
    'background',
    'foreground',
    'card',
    'card-foreground',
    'popover',
    'popover-foreground',
    'primary',
    'primary-foreground',
    'secondary',
    'secondary-foreground',
    'muted',
    'muted-foreground',
    'accent',
    'accent-foreground',
    'destructive',
    'border',
    'input',
    'ring',
    'sidebar',
    'sidebar-foreground',
    'sidebar-primary',
    'sidebar-primary-foreground',
    'sidebar-accent',
    'sidebar-accent-foreground',
    'sidebar-border',
    'sidebar-ring'
];
/** Kit colour tokens and the Svelte role each one carries. */
const TOKEN_ROLES = {
    colorBackground: 'background',
    colorForeground: 'foreground',
    colorCard: 'card',
    colorCardForeground: 'card-foreground',
    colorPopover: 'popover',
    colorPopoverForeground: 'popover-foreground',
    colorPrimary: 'primary',
    colorPrimaryForeground: 'primary-foreground',
    colorSecondary: 'secondary',
    colorSecondaryForeground: 'secondary-foreground',
    colorMuted: 'muted',
    colorMutedForeground: 'muted-foreground',
    colorAccent: 'accent',
    colorAccentForeground: 'accent-foreground',
    colorDestructive: 'destructive',
    colorBorder: 'border',
    colorInput: 'input',
    colorRing: 'ring'
};
/**
 * Every Svelte colour role from the site palette, with contrast guards: text roles
 * reach 4.5:1 on the surfaces they sit on (primary text on primary, muted text on
 * muted, card and page surfaces, destructive text on the page) and the focus ring
 * reaches 3:1 on the page. The sidebar takes the site's standout surface.
 */
function siteColorRoles(palette, inputFill) {
    const background = palette.colorBackground;
    const primary = palette.colorPrimary;
    const primaryForeground = readable(palette.colorPrimaryForeground, primary);
    const accent = palette.colorAccent;
    const accentForeground = readable(palette.colorAccentForeground, accent);
    const border = palette.colorBorder;
    const ring = readable(palette.colorRing, background, 3);
    const sidebar = palette.colorSecondary;
    return {
        background,
        foreground: readable(palette.colorForeground, [background, palette.colorCard, palette.colorMuted]),
        card: palette.colorCard,
        'card-foreground': readable(palette.colorCardForeground, palette.colorCard),
        popover: palette.colorPopover,
        'popover-foreground': readable(palette.colorPopoverForeground, palette.colorPopover),
        primary,
        'primary-foreground': primaryForeground,
        secondary: palette.colorSecondary,
        'secondary-foreground': readable(palette.colorSecondaryForeground, palette.colorSecondary),
        muted: palette.colorMuted,
        'muted-foreground': readable(palette.colorMutedForeground, [palette.colorMuted, background, palette.colorCard]),
        accent,
        'accent-foreground': accentForeground,
        destructive: readable(palette.colorDestructive, [background, palette.colorCard]),
        border,
        input: inputFill ?? palette.colorInput,
        ring,
        sidebar,
        'sidebar-foreground': readable(palette.colorForeground, sidebar),
        'sidebar-primary': primary,
        'sidebar-primary-foreground': primaryForeground,
        'sidebar-accent': accent,
        'sidebar-accent-foreground': accentForeground,
        'sidebar-border': border,
        'sidebar-ring': ring
    };
}
/**
 * The SharePoint theme as data over Svelte: token overrides and CSS custom
 * properties. Pass the SPFx theme object, `mapSharePointTheme` output, or a
 * resolved site theme; omit it for the structure only (font, corners, density,
 * dialog width) over the Svelte colours.
 *
 * - palette: the site's colours through `mapSharePointTheme`, on the Kit tokens and on
 *   every Svelte colour role (`--primary`, `--muted-foreground`, `--ring`, ...), with
 *   text at 4.5:1 on its surface and the focus ring at 3:1 on the page;
 * - font: the site's font for body and headings (Segoe UI by default);
 * - radius: Fluent's 2 / 4 / 8 px scale and 4px control corners (`radiusControl`)
 *   instead of Luma's squircles and pills;
 * - density: 32px controls, by scaling the Kit spacing unit by 8/9 so Luma's
 *   nine-unit (36px) controls become 32px;
 * - fields: Luma's `input` fill becomes the site surface with 10% of the site
 *   text (15% on dark sites); SharePoint's `inputBorder` stays a stroke, exposed
 *   as `--spfx-ui-sharepoint-input-border` for app stylesheets;
 * - dialogs: 600px wide through `--skui-container-md`.
 */
export function sharePointSvelteLayer(site) {
    const resolved = site ? resolveSharePointSiteTheme(site) : undefined;
    const font = resolved?.fontFamily ?? SHAREPOINT_FONT_STACK;
    const palette = {};
    const roleVariables = {};
    if (resolved?.palette) {
        const roles = siteColorRoles(resolved.palette, resolved.inputFill);
        palette.mode = resolved.palette.mode;
        for (const [token, role] of Object.entries(TOKEN_ROLES))
            palette[token] = roles[role];
        for (const role of SVELTE_COLOR_ROLES)
            roleVariables[`--${role}`] = roles[role];
    }
    const spacingRem = `calc(0.25rem * ${SHAREPOINT_CONTROL_HEIGHT_PX / 4} / ${LUMA_CONTROL_HEIGHT_UNITS})`;
    return {
        mode: resolved?.palette ? resolved.mode : undefined,
        tokens: {
            ...palette,
            radiusSm: '2px',
            radiusMd: '4px',
            radiusLg: '4px',
            radiusXl: '8px',
            radiusControl: SHAREPOINT_CONTROL_RADIUS,
            fontHeading: font
        },
        cssVariables: {
            ...roleVariables,
            '--skui-spacing': spacingRem,
            '--radius': '4px',
            '--ui-library-radius-base': '4px',
            '--ui-library-radius-pill': '4px',
            '--ui-library-radius-pill-compact': '4px',
            '--ui-library-luma-sidebar-radius-context': '4px',
            '--ui-library-corner-radius-factor': '1',
            '--ui-library-corner-shape': 'round',
            '--skui-radius-xs': '2px',
            '--skui-radius-2xl': '8px',
            '--skui-radius-3xl': '8px',
            '--skui-radius-4xl': '8px',
            '--font-sans': font,
            '--font-heading': font,
            '--ui-library-theming-font-body': font,
            '--skui-container-md': SHAREPOINT_DIALOG_WIDTH,
            ...(resolved?.inputBorder ? { [SHAREPOINT_INPUT_BORDER_VARIABLE]: resolved.inputBorder } : {})
        }
    };
}
const layerVariableNames = new WeakMap();
/**
 * Apply a SharePoint layer after the Svelte style (`applyThemeArtifact` or
 * `applyCompiledThemeArtifact` in `layer.mode`). `base` is the Svelte tokens for
 * that mode, for example `artifact.compiled[mode].tokens`. Applying a style again
 * clears the layer, so Light and Dark are plain Svelte.
 */
export function applySharePointSvelteLayer(host, base, layer) {
    if (layer.mode && layer.mode !== base.mode) {
        throw new Error(`Apply the Svelte style in the site's ${layer.mode} mode before its SharePoint layer.`);
    }
    host.applyTheme({ ...base, ...layer.tokens, fontMono: base.fontMono });
    const names = layerVariableNames.get(host) ?? new Set();
    layerVariableNames.set(host, names);
    for (const surface of [host.appRoot, host.portalHost]) {
        for (const [name, value] of Object.entries(layer.cssVariables)) {
            surface.style.setProperty(name, value);
            names.add(name);
        }
    }
}
/** Remove the layer's CSS custom properties. Theme application calls this before applying a style. */
export function clearSharePointSvelteLayer(host) {
    const names = layerVariableNames.get(host);
    if (!names)
        return;
    for (const surface of [host.appRoot, host.portalHost])
        for (const name of names)
            surface.style.removeProperty(name);
    layerVariableNames.delete(host);
}
