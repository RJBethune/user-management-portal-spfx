# SPFx Kit theme artifacts

Compile the same saved style in the Lab and deployed SPFx apps. The package owns the shared selection compiler, scoped geometry/menu CSS, and Inter and Geist Mono assets. It has no runtime GitLab dependency.

```ts
import { createThemeArtifact, applyThemeArtifact, resolvePinnedTheme } from '@spfx-kit/ui-theme';
import '@spfx-kit/ui-theme/styles.css';
import '@spfx-kit/ui-theme/fonts/inter.css';
import '@spfx-kit/ui-theme/fonts/geist-mono.css';

const compatibility = { profileId, profileDigest }; // installed component profile + SHA-256
const bundled = createThemeArtifact(savedDocument, { ...compatibility, revision });
applyThemeArtifact(host, bundled, 'light', compatibility);
const result = await resolvePinnedTheme({ url, sha256, fallback: bundled, compatibility });
applyThemeArtifact(host, result.artifact, 'light', compatibility);
```

The host owns both app and portal surfaces. Existing Lab imports are compatibility re-exports; `compileTheme` and `applyCompiledTheme` are neutral public names for the shared compiler/applicator.

`spfx-theme-bundle artifact.json output-directory` emits JSON, scoped CSS, fonts CSS, the local Inter and Geist Mono files the style selects with their licenses, plus a SHA-256 asset manifest. Relative font URLs work when staged together on the existing CDN or imported through the SPFx webpack asset pipeline. Only system families, packaged Inter and packaged Geist Mono are currently emitted; unsupported downloadable fonts fail the build instead of silently substituting fonts. System fonts retain fallback stacks and are not copied.

Pin artifact JSON by exact SHA-256 and its component-profile digest. A failed request, invalid document, mismatched digest, incompatible font/icon choice, or a style the bundle does not ship (`isSpfxUiStyleShipped` is false after the UI profile's `styles` trimming) returns the validated embedded fallback without touching the host. Requests omit credentials, reject redirects, and time out. The initial CDN settings path deliberately uses the installed font/icon asset set; adding assets requires a package update. The output directory is also suitable for an immutable CDN deployment of the whole style bundle, but loading arbitrary remote CSS/font updates dynamically is not enabled by this API.

Managed update channels are not followed automatically. A future explicit channel resolver must resolve to an immutable digest, validate compatibility, and stage all required assets before applying. Never use a mutable latest URL as an integrity pin. No script or runtime credential belongs in a theme artifact.

## Fonts

The Svelte style uses Inter for text and Geist Mono for code. Import both font
stylesheets once per app, next to `styles.css`. Each is a set of `@font-face`
rules pointing at local woff2 files, so an SPFx build emits the fonts as separate
web-part assets and a page downloads a file only when it renders text in that
font and Unicode range.

- `fonts/inter.css`: Inter subsets (Latin, Latin Extended, Vietnamese; upright
  and italic), 463,916 bytes in six files. See `fonts/inter-4.1/SOURCE.md`.
- `fonts/geist-mono.css`: one Geist Mono variable file, Latin upright, weights
  100–900, 23,128 bytes. Other scripts use the stack's system monospace fonts
  and italic is synthesized. See `fonts/geist-mono/SOURCE.md`.

Both fonts are SIL OFL 1.1; each directory keeps its `LICENSE.txt`.

### Font fallbacks

Both stylesheets use `font-display: swap`, so text first renders in a fallback
and swaps when the woff2 arrives. Without help the fallback (Segoe UI on
Windows) is about 8% narrower than Inter, so text re-wraps on the swap and
content moves. Each stylesheet therefore also defines metric-matched fallback
families from local system fonts, and the theme's stacks list them right after
the web font:

| Family                            | Local font (first found)                    | size-adjust       | ascent / descent           |
| --------------------------------- | ------------------------------------------- | ----------------- | -------------------------- |
| `InterVariable Fallback Segoe UI` | Segoe UI (100–549), Segoe UI Bold (550–900) | 108.63% / 103.18% | Inter's 0.970 / 0.241      |
| `InterVariable Fallback Arial`    | Arial, Liberation Sans, Arimo (and Bold)    | 106.63% / 101.08% | Inter's 0.970 / 0.241      |
| `Geist Mono Fallback Consolas`    | Consolas                                    | 109.13%           | Geist Mono's 1.005 / 0.295 |
| `Geist Mono Fallback Menlo`       | Menlo                                       | 99.66%            | Geist Mono's 1.005 / 0.295 |
| `Geist Mono Fallback Courier New` | Courier New                                 | 99.98%            | Geist Mono's 1.005 / 0.295 |

- Inter stack: `InterVariable, Inter, "InterVariable Fallback Segoe UI", "InterVariable Fallback Arial", "Segoe UI", sans-serif`.
  A locally installed Inter still wins over the fallbacks.
- Widths were measured in Chromium against Inter 4.1 at 14px (the Kit's body
  size; Inter's optical size is 14 at and below it). Regular faces match
  Inter 400, bold faces match Inter 600. At 12–16px the fallback's width is
  within about 1% of Inter's for every weight, and line boxes
  (`line-height: normal`) have the same height. The ascent is set to 0.970
  rather than Inter's exact 0.96875 so it clears the rounding boundary Inter
  sits on at 16px. Consolas is not installed on the build machine; its value
  comes from its published advance (1126/2048), and the ascent and descent
  overrides do not depend on its own metrics.
- Apps built before this change carry the old stack in their theme artifact;
  rebuild the artifact to pick up the fallback names. An app that imports the
  fonts CSS without them loses nothing.

**Measured reflow.** The measurement script runs on spfx-kit's CLS gate, so it
stays in spfx-kit: `node scripts/ui-theme/measure-font-fallbacks.mjs`
in an spfx-kit checkout (it measures the installed release) runs a typical Kit screen through the gate with the
woff2 files held back for 1.5 s. On a machine without Inter installed, the swap's layout shift at
390px went from 0.0211 to 0 (Segoe UI) and from 0.0203 to 0 (Arial); at 1280px
it went from 0.0002 to 0. In NEXUS (preview Lab, Light theme, six views,
emulated swap), the summed swap shift went from 0.0291 to 0.0031 at 1280px and
from 0.1285 to 0.0131 at 390px with Segoe UI, and from 0.0320 to 0.0034 and
0.0309 to 0.0161 with Arial. Admin Getting started, the worst view in the
layout-shift audit, went to 0.0000 or 0.0001. Metric matching lowers the average
reflow but cannot promise zero: a row of short links that sits exactly at a
wrap point can still wrap differently (NEXUS Reports at 390px with Arial,
0.0029 before and 0.0158 after).

## Control radius

Luma rounds interactive controls as pills. This stylesheet restates several of
those radii for the Lab and kit apps, and each one reads the UI profile's
optional `SpfxUiThemeTokens.radiusControl` token (`--spfx-ui-radius-control`)
first, with the existing pill value as the fallback. When the token is unset,
Luma looks exactly as before. When an app's theme layer sets it (for example
`radiusControl: '4px'` for a SharePoint look), it also replaces the radius of
these Luma controls:

- buttons, button group text, input groups and their buttons, including the
  compact `xs` input group buttons
- inputs, select and native select triggers, combobox chips, OTP groups,
  toggles, badges, key hints in input groups, and input groups with block or
  textarea addons
- joined outline toggle groups
- dropdown menu items (including checkbox and radio items) and select items

Menu surfaces, cards, dialogs, sidebars and other Maia, Vega or Nova rules keep
their own radii. Theme documents and artifacts do not carry the token: it
belongs to the app's theme layer, and `applyThemeArtifact` clears it each time
it applies a style, so set it after applying the artifact. The SharePoint preset
below sets it to `4px`.

## Paragraph wrapping

`styles.css` gives paragraphs inside Kit app roots and portal hosts
(`[data-spfx-ui-root]`, `[data-spfx-ui-portal-host]`) pretty line breaking,
`text-wrap-style: pretty`, so they end with fewer short last lines. The rule has zero
specificity and sits in the `spfx-kit-ui-theme-defaults` cascade layer. Any
unlayered rule, and any layer declared after it, wins, so an app's own
`text-wrap` on a paragraph is kept. It sets only the wrap style, not the wrap mode,
so `nowrap` or truncation inherited from a container still applies. Headings and
other text are unchanged. Browsers without `text-wrap-style` ignore it.

## SharePoint theme over Svelte

Every app and site builds on the shared Svelte style document (Luma). An app's
**SharePoint theme** is the thinnest data-only mapping over Svelte, so the app
keeps the look of its Fluent roots while taking the site's theme. **Light** and
**Dark** are plain Svelte. The preset is token overrides and CSS custom
properties only, never per-component CSS:

- **Palette:** the site's colours through the UI profile's `mapSharePointTheme`.
  A partial SPFx palette is completed first, with muted text at 4.5:1, the
  input stroke at 3:1 and primary button text at 4.5:1. The palette goes on the
  Kit tokens and on every Svelte colour role (`SVELTE_COLOR_ROLES`: `--background`,
  `--primary`, `--primary-foreground`, `--muted-foreground`, `--accent`, `--ring`,
  the `--sidebar-*` roles and the rest), because app styles and Kit components
  read those too. Each text role reaches 4.5:1 on the surfaces it sits on, and
  the focus ring reaches 3:1 on the page. The sidebar takes the site's standout
  surface. Svelte's chart colours are a data palette, not a brand role, so they
  stay Svelte's.
- **Font:** the site's font family for body and headings, or SharePoint's
  Segoe UI stack. Svelte's mono font (Geist Mono) is kept.
- **Radius:** Fluent's 2, 4 and 8 px scale, and 4px control corners through
  `radiusControl` instead of Luma's pills.
- **Density:** 32px controls. The Kit spacing unit is scaled by 8/9, so Luma's
  nine-unit (36px) controls become 32px and spacing tightens in proportion.
- **Fields:** Luma fills fields and checkboxes with `input`. The preset sets it
  to the site surface mixed with 10% of the site text (15% on dark sites).
  SharePoint's `inputBorder` stays a stroke, exposed to app stylesheets as
  `--spfx-ui-sharepoint-input-border`.
- **Dialogs:** 600px wide, Fluent's dialog width, through `--skui-container-md`.

Luma has no token for a 32px tab height or bold dialog titles, so the preset
leaves them alone.

```ts
import type { IReadonlyTheme } from '@microsoft/sp-component-base';
import {
  applyCompiledThemeArtifact,
  applySharePointSvelteLayer,
  resolveSharePointSiteTheme,
  sharePointSvelteLayer
} from '@spfx-kit/ui-theme/runtime';

function applyAppTheme(choice: 'sharepoint' | 'light' | 'dark', siteTheme?: IReadonlyTheme): void {
  if (choice !== 'sharepoint' || !siteTheme) {
    applyCompiledThemeArtifact(host, svelte, choice === 'dark' ? 'dark' : 'light', compatibility);
    return;
  }
  const site = resolveSharePointSiteTheme(siteTheme); // or mapSharePointTheme(...) output
  applyCompiledThemeArtifact(host, svelte, site.mode, compatibility);
  applySharePointSvelteLayer(host, svelte.compiled[site.mode].tokens, sharePointSvelteLayer(site));
}
```

`sharePointSvelteLayer(site)` returns `{ mode, tokens, cssVariables }`. Merge
`tokens` over the Svelte tokens for `mode` and set `cssVariables` on the app root
and portal host, or let `applySharePointSvelteLayer` do both. It refuses Svelte
tokens compiled for the other mode. With no site palette the layer keeps the
Svelte colours and maps only font, corners, density and dialog width. Applying a
style again (`applyThemeArtifact`, `applyCompiledThemeArtifact`) or
`resetThemeArtifact` clears the layer, so switching to Light or Dark needs no
extra step. The same exports are on the root entry for the full compiler path,
where the base tokens are `compileTheme(artifact.document.preferences, mode).tokens`.

In the Lab, **Theming → SharePoint (over Svelte)** previews the preset over the
selected style with the Lab's mock SharePoint palette in the current mode.

## SPFx build integration

Compose the global CSS adapter after the component-profile adapter in your webpack patch:

```js
const configureProfile = require('@spfx-kit/ui-profile/spfx-webpack');
const configureTheme = require('@spfx-kit/ui-theme/spfx-webpack.cjs');
module.exports = (config) => configureTheme(configureProfile(config));
```

The adapter excludes only this package's exact stylesheet from CSS Modules and uses the existing SPFx global loader chain. It does not change app CSS-module behavior. Without this step SPFx hashes the shared class selectors, so they no longer match Kit components.

## Opt-in compiled runtime

Existing root imports and version-1 artifacts retain their full runtime compiler behavior.
For a lean consumer, compile the same saved document during packaging:

```sh
node node_modules/@spfx-kit/ui-theme/scripts/compile-artifact.cjs theme-v1.json theme-v2.json
```

Import `parseCompiledThemeArtifact`, `applyCompiledThemeArtifact`, and
`resolvePinnedCompiledTheme` from `@spfx-kit/ui-theme/runtime`. Version 2 includes
validated light and dark snapshots, including the opposite mode used for inverted
menus. Read `artifact.compiled[mode]` for compatibility bridges such as Fluent.
The runtime dependency graph excludes the palette/catalog and compiler modules.
SharePoint mapping stays with the UI host; this does not replace or restrict it.

Remote version-2 artifacts still require an immutable digest, matching profile,
and the same bundled font/icon asset set. To continue accepting arbitrary
version-1 remote preferences, explicitly pass an adapter:

```ts
compileLegacy: async (artifact) => (await import('@spfx-kit/ui-theme/compiler')).compileThemeArtifact(artifact);
```

This preserves legacy support without loading the compiler on the embedded path.
The compiler still ships in an async chunk when that adapter is included, so
initial-load savings do not necessarily reduce total package bytes. Without an
adapter a V1 response fails closed to the validated bundled V2 artifact; opting
into a V2-only endpoint must be deliberate. Saved document content is unchanged.
